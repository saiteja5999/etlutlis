package com.cvshealth.dep.etlutils.medcost;

public class Rows {
	private String rxFillNbr= "";
	private String antRefillDueDt = "";
	private String oppurtunityID = "";
	private String opptActionID = "";
	private String fillDt = "";
	private String CustFamNbr = "";
	private String CustMbrNbr= "";
	private String rxcDrID = "";
	private String rxcPatientID = "";
	private String rxcPrecID = "";
	private String conTrackType = "";
	private String dispNdc = "";
	private String drugGcnNbr = "";
	private String drugGpiF="";
	private String drugGpiE= "";
	private String rxchannelType= "";
	private String rxActionCD="";
	private String srcCD= "";
	private String phoneNbr="";
	private String pgmType= "";
	private String opptChannelTxt ="";
	private String VisittCD= "";
	private String daySupplyQty="";
	private String rxExpDt= "";
	private String actOpptInd="";
	
	private String regTgtDt="";
	private String trainRsnCd="";
	private String deliveryStartTime= "";
	private String deliveryPriorityNbr="";
	private String verbiageCD= "";
	private String deliveryMethod ="";
	private String multiScriptOpptInd= "";
	private String prescriberCrgSwapInd="";
	private String readyFillEnrCD= "";
	private String wildChar="";
	private String srcOpptCrtDt="";
	private String scriptsOppt= "";
	private String rxMsgSrcCD="";
	private String rxMsgCD="";
	private String rxMsgType="";
	private String opptMsgSrcCD="";
	private String opptSrcCD="";
	private String opptMsgType="";
	private String opptMsgCD="";
	private String rxNbr ="";
	private String storeNbr="";
	private String subPgmCD="";
	private String pgmCD="";
	private String condefSeqNbr="";
	private String  requestID="";
	
	private String createTs="";
	

	public String getCreateTs() {
		return createTs;
	}
	public void setCreateTs(String createTs) {
		this.createTs = createTs;
	}
	
	public String getRequestID() {
		return requestID;
	}
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}
	
	public String getRxFillNbr() {
		return rxFillNbr;
	}
	public void setRxFillNbr(String rxFillNbr) {
		this.rxFillNbr = rxFillNbr;
	}
	public String getAntRefillDueDt() {
		return antRefillDueDt;
	}
	public void setAntRefillDueDt(String antRefillDueDt) {
		this.antRefillDueDt = antRefillDueDt;
	}
	public String getOppurtunityID() {
		return oppurtunityID;
	}
	public void setOppurtunityID(String oppurtunityID) {
		this.oppurtunityID = oppurtunityID;
	}
	public String getOpptActionID() {
		return opptActionID;
	}
	public void setOpptActionID(String opptActionID) {
		this.opptActionID = opptActionID;
	}
	public String getFillDt() {
		return fillDt;
	}
	public void setFillDt(String fillDt) {
		this.fillDt = fillDt;
	}
	public String getCustFamNbr() {
		return CustFamNbr;
	}
	public void setCustFamNbr(String custFamNbr) {
		CustFamNbr = custFamNbr;
	}
	public String getCustMbrNbr() {
		return CustMbrNbr;
	}
	public void setCustMbrNbr(String custMbrNbr) {
		CustMbrNbr = custMbrNbr;
	}
	public String getRxcDrID() {
		return rxcDrID;
	}
	public void setRxcDrID(String rxcDrID) {
		this.rxcDrID = rxcDrID;
	}
	public String getRxcPatientID() {
		return rxcPatientID;
	}
	public void setRxcPatientID(String rxcPatientID) {
		this.rxcPatientID = rxcPatientID;
	}
	public String getRxcPrecID() {
		return rxcPrecID;
	}
	public void setRxcPrecID(String rxcPrecID) {
		this.rxcPrecID = rxcPrecID;
	}
	public String getConTrackType() {
		return conTrackType;
	}
	public void setConTrackType(String conTrackType) {
		this.conTrackType = conTrackType;
	}
	public String getDispNdc() {
		return dispNdc;
	}
	public void setDispNdc(String dispNdc) {
		this.dispNdc = dispNdc;
	}
	public String getDrugGcnNbr() {
		return drugGcnNbr;
	}
	public void setDrugGcnNbr(String drugGcnNbr) {
		this.drugGcnNbr = drugGcnNbr;
	}
	public String getDrugGpiF() {
		return drugGpiF;
	}
	public void setDrugGpiF(String drugGpiF) {
		this.drugGpiF = drugGpiF;
	}
	public String getDrugGpiE() {
		return drugGpiE;
	}
	public void setDrugGpiE(String drugGpiE) {
		this.drugGpiE = drugGpiE;
	}
	public String getRxchannelType() {
		return rxchannelType;
	}
	public void setRxchannelType(String rxchannelType) {
		this.rxchannelType = rxchannelType;
	}
	public String getRxActionCD() {
		return rxActionCD;
	}
	public void setRxActionCD(String rxActionCD) {
		this.rxActionCD = rxActionCD;
	}
	public String getSrcCD() {
		return srcCD;
	}
	public void setSrcCD(String srcCD) {
		this.srcCD = srcCD;
	}
	public String getPhoneNbr() {
		return phoneNbr;
	}
	public void setPhoneNbr(String phoneNbr) {
		this.phoneNbr = phoneNbr;
	}
	public String getPgmType() {
		return pgmType;
	}
	public void setPgmType(String pgmType) {
		this.pgmType = pgmType;
	}
	public String getOpptChannelTxt() {
		return opptChannelTxt;
	}
	public void setOpptChannelTxt(String opptChannelTxt) {
		this.opptChannelTxt = opptChannelTxt;
	}
	public String getVisittCD() {
		return VisittCD;
	}
	public void setVisittCD(String visittCD) {
		VisittCD = visittCD;
	}
	public String getDaySupplyQty() {
		return daySupplyQty;
	}
	public void setDaySupplyQty(String daySupplyQty) {
		this.daySupplyQty = daySupplyQty;
	}
	public String getRxExpDt() {
		return rxExpDt;
	}
	public void setRxExpDt(String rxExpDt) {
		this.rxExpDt = rxExpDt;
	}
	public String getActOpptInd() {
		return actOpptInd;
	}
	public void setActOpptInd(String actOpptInd) {
		this.actOpptInd = actOpptInd;
	}
	public String getRegTgtDt() {
		return regTgtDt;
	}
	public void setRegTgtDt(String regTgtDt) {
		this.regTgtDt = regTgtDt;
	}
	public String getTrainRsnCd() {
		return trainRsnCd;
	}
	public void setTrainRsnCd(String trainRsnCd) {
		this.trainRsnCd = trainRsnCd;
	}
	public String getDeliveryStartTime() {
		return deliveryStartTime;
	}
	public void setDeliveryStartTime(String deliveryStartTime) {
		this.deliveryStartTime = deliveryStartTime;
	}
	public String getDeliveryPriorityNbr() {
		return deliveryPriorityNbr;
	}
	public void setDeliveryPriorityNbr(String deliveryPriorityNbr) {
		this.deliveryPriorityNbr = deliveryPriorityNbr;
	}
	public String getVerbiageCD() {
		return verbiageCD;
	}
	public void setVerbiageCD(String verbiageCD) {
		this.verbiageCD = verbiageCD;
	}
	public String getDeliveryMethod() {
		return deliveryMethod;
	}
	public void setDeliveryMethod(String deliveryMethod) {
		this.deliveryMethod = deliveryMethod;
	}
	public String getMultiScriptOpptInd() {
		return multiScriptOpptInd;
	}
	public void setMultiScriptOpptInd(String multiScriptOpptInd) {
		this.multiScriptOpptInd = multiScriptOpptInd;
	}
	public String getPrescriberCrgSwapInd() {
		return prescriberCrgSwapInd;
	}
	public void setPrescriberCrgSwapInd(String prescriberCrgSwapInd) {
		this.prescriberCrgSwapInd = prescriberCrgSwapInd;
	}
	public String getReadyFillEnrCD() {
		return readyFillEnrCD;
	}
	public void setReadyFillEnrCD(String readyFillEnrCD) {
		this.readyFillEnrCD = readyFillEnrCD;
	}
	public String getWildChar() {
		return wildChar;
	}
	public void setWildChar(String wildChar) {
		this.wildChar = wildChar;
	}
	public String getSrcOpptCrtDt() {
		return srcOpptCrtDt;
	}
	public void setSrcOpptCrtDt(String srcOpptCrtDt) {
		this.srcOpptCrtDt = srcOpptCrtDt;
	}
	public String getScriptsOppt() {
		return scriptsOppt;
	}
	public void setScriptsOppt(String scriptsOppt) {
		this.scriptsOppt = scriptsOppt;
	}
	public String getRxMsgSrcCD() {
		return rxMsgSrcCD;
	}
	public void setRxMsgSrcCD(String rxMsgSrcCD) {
		this.rxMsgSrcCD = rxMsgSrcCD;
	}
	public String getRxMsgCD() {
		return rxMsgCD;
	}
	public void setRxMsgCD(String rxMsgCD) {
		this.rxMsgCD = rxMsgCD;
	}
	public String getRxMsgType() {
		return rxMsgType;
	}
	public void setRxMsgType(String rxMsgType) {
		this.rxMsgType = rxMsgType;
	}
	public String getOpptMsgSrcCD() {
		return opptMsgSrcCD;
	}
	public void setOpptMsgSrcCD(String opptMsgSrcCD) {
		this.opptMsgSrcCD = opptMsgSrcCD;
	}
	public String getOpptSrcCD() {
		return opptSrcCD;
	}
	public void setOpptSrcCD(String opptSrcCD) {
		this.opptSrcCD = opptSrcCD;
	}
	public String getOpptMsgType() {
		return opptMsgType;
	}
	public void setOpptMsgType(String opptMsgType) {
		this.opptMsgType = opptMsgType;
	}
	public String getOpptMsgCD() {
		return opptMsgCD;
	}
	public void setOpptMsgCD(String opptMsgCd) {
		this.opptMsgCD = opptMsgCd;
	}
	public String getRxNbr() {
		return rxNbr;
	}
	public void setRxNbr(String rxNbr) {
		this.rxNbr = rxNbr;
	}
	public String getStoreNbr() {
		return storeNbr;
	}
	public void setStoreNbr(String storeNbr) {
		this.storeNbr = storeNbr;
	}
	public String getSubPgmCD() {
		return subPgmCD;
	}
	public void setSubPgmCD(String subPgmCD) {
		this.subPgmCD = subPgmCD;
	}
	public String getPgmCD() {
		return pgmCD;
	}
	public void setPgmCD(String pgmCD) {
		this.pgmCD = pgmCD;
	}
	public String getCondefSeqNbr() {
		return condefSeqNbr;
	}
	public void setCondefSeqNbr(String condefSeqNbr) {
		this.condefSeqNbr = condefSeqNbr;
	}
	@Override
	public String toString() {
		return "Rows [rxFillNbr=" + rxFillNbr + ", antRefillDueDt="
				+ antRefillDueDt + ", oppurtunityID=" + oppurtunityID
				+ ", opptActionID=" + opptActionID + ", fillDt="
				+ fillDt + ", CustFamNbr=" + CustFamNbr
				+ ", CustMbrNbr=" + CustMbrNbr + ", rxcDrID=" + rxcDrID
				+ ", rxcPatientID=" + rxcPatientID + ", rxcPrecID="
				+ rxcPrecID + ", conTrackType=" + conTrackType
				+ ", dispNdc=" + dispNdc + ", drugGcnNbr=" + drugGcnNbr
				+ ", drugGpiF=" + drugGpiF + ", drugGpiE=" + drugGpiE
				+ ", rxchannelType=" + rxchannelType + ", rxActionCD="
				+ rxActionCD + ", srcCD=" + srcCD + ", phoneNbr="
				+ phoneNbr + ", pgmType=" + pgmType
				+ ", opptChannelTxt=" + opptChannelTxt + ", VisittCD="
				+ VisittCD + ", daySupplyQty=" + daySupplyQty
				+ ", rxExpDt=" + rxExpDt + ", actOpptInd=" + actOpptInd
				+ ", regTgtDt=" + regTgtDt + ", trainRsnCd="
				+ trainRsnCd + ", deliveryStartTime="
				+ deliveryStartTime + ", deliveryPriorityNbr="
				+ deliveryPriorityNbr + ", verbiageCD=" + verbiageCD
				+ ", deliveryMethod=" + deliveryMethod
				+ ", multiScriptOpptInd=" + multiScriptOpptInd
				+ ", prescriberCrgSwapInd=" + prescriberCrgSwapInd
				+ ", readyFillEnrCD=" + readyFillEnrCD + ", wildChar="
				+ wildChar + ", srcOpptCrtDt=" + srcOpptCrtDt
				+ ", scriptsOppt=" + scriptsOppt + ", rxMsgSrcCD="
				+ rxMsgSrcCD + ", rxMsgCD=" + rxMsgCD + ", rxMsgType="
				+ rxMsgType + ", opptMsgSrcCD=" + opptMsgSrcCD
				+ ", opptSrcCD=" + opptSrcCD + ", opptMsgType="
				+ opptMsgType + ", opptMsgCD=" + opptMsgCD + ", rxNbr="
				+ rxNbr + ", storeNbr=" + storeNbr + ", subPgmCD="
				+ subPgmCD + ", pgmCD=" + pgmCD + ", condefSeqNbr="
				+ condefSeqNbr + ", requestID=" + requestID
				+ ", createTs=" + createTs + "]";
	}
}
