package com.cvshealth.dep.etlutils.mcs;

import java.text.ParseException;
import java.util.Date;



public class Test {
	
	public static void main(String args[]) {
		
		String line ="1|RxCLAIM|RxCLAIM|INGENIORX|INGENIORX|8469|C03ACC31138|C03GRP31138|C03MBR31138||||ECCM Print |Paper ClaimsPrint Anthem Medicaid Prescriber|Letter|400 Massachusetts Test, CITY, DC, 20001|P.O. Box 52065, Phoenix, AZ, 85072|Paper Claims Print Anthem Medicaid Prescriber|04-10-2019 11:52:10 AM|COMPLETED|||||build.log|N||||||||";
		
		String[] arrOfStr = line.split("\\|", -1);
		String dateStr = arrOfStr[25];
		System.out.println(line);		/*Date date = null;
		try {
			/date = srcDf.parse(dateStr);
		} catch (ParseException e) {
			//log.error("Date Format in COMMDELIVERYDATE field is incorrect, it should in MM-dd-yyyy hh:mm:ss a format");
			throw new Exception(e.toString());
		}*/
	}

}
