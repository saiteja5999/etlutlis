package com.cvshealth.dep.etlutils.generic;

import java.util.ArrayList;
import java.util.List;


import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;






import org.json.*;
import org.apache.commons.logging.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class GenericRequestBuilder implements RequestBuilder {
	private RequestMetaData requestMetaData;

	public GenericRequestBuilder(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	
	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		
				
		

		/* final int CRERATETIMESTAMP_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CRERATETIMESTAMP_POSITION").trim());*/
		
	/*	final int MEMBERID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERID_POSITION").trim());
		final int MEMBERTYPE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERTYPE_POSITION").trim());
	/*	final int STORENUMBER_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "STORENUMBER_POSITION").trim());
		final int RXNUMBER_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "RXNUMBER_POSITION").trim());
		final int CAMPAIGN_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CAMPAIGN_POSITION").trim());
		final int CHANNELTYPE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "CHANNELTYPE_POSITION").trim());
		final int CHANNELID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "CHANNELID_POSITION").trim());
		final int OPPORTUNITYID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "OPPORTUNITYID_POSITION").trim());
		final int XIDFLAG_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "XIDFLAG_POSITION").trim());
		/*final int DEVICETYPE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "DEVICETYPE_POSITION").trim());
		final int CONTACTTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CONTACTTYPE_POSITION").trim());
		final int CAMPAIGNID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CAMPAIGNID_POSITION").trim());
		//final int EVENTID_POSITION = Integer.parseInt(Utility
			//	.getProperty(folder, finalProduct, "EVENTID_POSITION").trim());
		final int EVENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EVENTNAME_POSITION").trim());
		
		final int LINEOFBUSINESS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LINEOFBUSINESS_POSITION").trim());
		final int TEMPLATETYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "TEMPLATETYPE_POSITION").trim());
		final int SUBJECT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SUBJECT_POSITION").trim());
		final int CAMPAIGNCOLUMN_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CAMPAIGNCOLUMN_POSITION").trim());
		final int DEEPLINKURL_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DEEPLINKURL_POSITION").trim());
		final int 		ACTIONFLAG_POSITION = Integer.parseInt(Utility
						.getProperty(folder, finalProduct, "ACTIONFLAG_POSITION").trim());
		final int PROGRAMNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PROGRAMNAME_POSITION").trim());
		
		final int EXTERNALCAMPAIGNID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EXTERNALCAMPAIGNID_POSITION").trim());
		
		final int FROMEMAIL_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FROMEMAIL_POSITION").trim());
		
		final int CAMPAIGNNM_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CAMPAIGNNM_POSITION").trim());*/

		
		final int DATA_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DATA_POSITION").trim());
	

		String reqString = null;
		String recordType = null;

		ObjectMapper objectMapper = null;
		GenericRequest jsonRequest = new GenericRequest();

		RequestPayloadData requestPayloadData = null;

       //   Data data = null;
		

		
		/*
		 * if (null != recordType && recordType.equalsIgnoreCase("T")) {
		 * reqString = "EOF"; } else {
		 */
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		requestPayloadData = new RequestPayloadData();
		
		  requestMetaData = new RequestMetaData();
		  requestMetaData.setAppName("CVS_APP");
		  requestMetaData.setLineOfBusiness("RETAIL");
		 
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		//data = new Data();
		
	
				
			
			
			
			
	

		// Populate Data
		//data.setCreateTimestamp(reqParamArray[CRERATETIMESTAMP_POSITION].trim());
	/*	data.setLineOfBusiness(reqParamArray[LINEOFBUSINESS_POSITION].trim());
		data.setTemplateType(reqParamArray[TEMPLATETYPE_POSITION].trim());
		data.setSubject(reqParamArray[SUBJECT_POSITION].trim());
		data.setMemberID(reqParamArray[MEMBERID_POSITION].trim());
		data.setMemberType(reqParamArray[MEMBERTYPE_POSITION].trim());
		//data.setCampaignColumn(reqParamArray[CAMPAIGNCOLUMN_POSITION].trim());
		data.setDeepLinkUrl(reqParamArray[DEEPLINKURL_POSITION].trim());
	//	data.setStoreNumber(reqParamArray[STORENUMBER_POSITION].trim());
		//data.setRxNumber(reqParamArray[RXNUMBER_POSITION].trim());
		data.setCampaign(reqParamArray[CAMPAIGN_POSITION].trim());
		data.setChannelType(reqParamArray[CHANNELTYPE_POSITION].trim());
		data.setChannelID(reqParamArray[CHANNELID_POSITION].trim());
		data.setOpportunityID(reqParamArray[OPPORTUNITYID_POSITION].trim());
		data.setXidFlag(reqParamArray[XIDFLAG_POSITION].trim());
	//	data.setDeviceType(reqParamArray[DEVICETYPE_POSITION].trim());
		//data.setContactType(reqParamArray[CONTACTTYPE_POSITION].trim());
		data.setCampaignID(reqParamArray[CAMPAIGNID_POSITION].trim());
		//data.setEventID(reqParamArray[EVENTID_POSITION].trim());
		data.setEventName(reqParamArray[EVENTNAME_POSITION].trim());
		data.setActionFlag(reqParamArray[ACTIONFLAG_POSITION].trim());
		data.setProgramName(reqParamArray[PROGRAMNAME_POSITION].trim());
		data.setExternalCampaignID(reqParamArray[EXTERNALCAMPAIGNID_POSITION].trim());
		data.setFromEmail(reqParamArray[FROMEMAIL_POSITION].trim());
		data.setCampaignNM(reqParamArray[CAMPAIGNNM_POSITION].trim());
		data.setCampaignColumn(reqParamArray[CAMPAIGNCOLUMN_POSITION].trim());*/
		
        
        	 

		requestPayloadData.setData(reqParamArray[DATA_POSITION].trim());

		
		//requestPayloadData.setData(data);
		
		jsonRequest.setRequestMetaData(requestMetaData);
		jsonRequest.setRequestPayloadData(requestPayloadData);

	//	JsonObject jsonObject =  new JsonParser().parse().getAsJsonObject();
	//	Gson g = new Gson();
		
		/*Gson g = new GsonBuilder()
        .disableHtmlEscaping()
        .setFieldNamingPolicy(FieldNamingPolicy.UPPER_CAMEL_CASE)
        .setPrettyPrinting()
        .serializeNulls()
        .create();
		g.toJson(jsonRequest);*/
		
		reqString= objectMapper.writeValueAsString(jsonRequest);
		
		

		
		String jsonFormattedString = reqString.replaceAll("\\\\", "").replace("\"{", "{").replace("}\"", "}");
	
		reqString =	jsonFormattedString;
	
		return reqString;
	}

}
