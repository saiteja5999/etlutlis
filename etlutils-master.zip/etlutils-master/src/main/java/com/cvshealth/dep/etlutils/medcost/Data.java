package com.cvshealth.dep.etlutils.medcost;

import java.util.List;


public class Data {
	
		private String activityTemplateID="";
		private String eventName="";
		private String actionType ="";
		private List<Rows> rows = null;
		public String getActivityTemplateID() {
			return activityTemplateID;
		}
		public List<Rows> getRows() {
			return rows;
		}
		public void setRows(List<Rows> rows) {
			this.rows = rows;
		}
		public void setActivityTemplateID(String activityTemplateID) {
			this.activityTemplateID = activityTemplateID;
		}
		public String getEventName() {
			return eventName;
		}
		public void setEventName(String eventName) {
			this.eventName = eventName;
		}
		public String getActionType() {
			return actionType;
		}
		public void setActionType(String actionType) {
			this.actionType = actionType;
		}
		
		
		
	}


