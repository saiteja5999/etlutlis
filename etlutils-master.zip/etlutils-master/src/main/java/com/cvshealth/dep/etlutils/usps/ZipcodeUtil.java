package com.cvshealth.dep.etlutils.usps;

import java.io.*;
import java.io.ObjectInputStream.GetField;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.utils.Utility;

/**
 * reqString maintains the time zone information
 *
 * @author z244836
 */
public class ZipcodeUtil {
	private final Logger infoLogger = Logger.getLogger("uspsinfo");
	private final Logger errorLogger = Logger.getLogger("uspserror");

	private Map<String, String> MAP_ZIP_OFFSET = null;
	private Map<String, String> EVENT_CODE = null;
	private final String EST = "-05";
	private final String EDT = "-04"; // Summer time
	private final String CONFIG = "config";
	private final String PROP_PREFIX = "etlutils_config";

	private boolean _IsDst = false;

	public ZipcodeUtil(String env) {
		try {
			String IS_DST_ON = ReadEtlutilCofigfProperties(env, "IS_DST_ON");
			System.out.println("IS_DST_ON: " + IS_DST_ON);
			boolean isDtsOn = "TRUE".equalsIgnoreCase(IS_DST_ON);
			this.MAP_ZIP_OFFSET = this.loadZipcodes(isDtsOn);
			this.EVENT_CODE = this.loadCode();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
			infoLogger
					.info("UspsProcessor | service.execute() | Error while converting record into KafkaRequest"
							+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e));
		}
	}

	public String getOffsetbyZip(String zipcode) {
		String result = _IsDst ? EDT : EST;
		if (MAP_ZIP_OFFSET.containsKey(zipcode)) {
			result = MAP_ZIP_OFFSET.get(zipcode);
		}
		return result;
	}

	public String getRxEventName(String eventcode) {
		String result = null;
		if (EVENT_CODE.containsKey(eventcode)) {
			result = EVENT_CODE.get(eventcode);
		}
		return result;
	}

	public Map<String, String> loadZipcodes(boolean isDts) throws Exception {
		_IsDst = isDts;
		Map<String, String> map = new HashMap<String, String>();
		InputStream in = null;
		if (_IsDst) {
			in = getClass().getResourceAsStream("/usps/zip_offset_dst.txt");
			System.out.println("Reading File " + "/usps/zip_offset_dst.txt");
		} else {
			in = getClass().getResourceAsStream("/usps/zip_offset_winter.txt");
			System.out.println("Reading File " + "/usps/zip_offset_winter.txt");
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(in));
		String line = reader.readLine();
		while (line != null && line.length() > 0) {
			String[] zipOffset = line.split("\\|");
			map.put(zipOffset[0], zipOffset[1]);
			line = reader.readLine();
		}
		return map;
	}

	public Map<String, String> loadCode() throws IOException

	{
		Map<String, String> propertyMap = new HashMap<String, String>();
		InputStream reader = null;

		// FileReader reader = new FileReader(
		// "/opt/digital/scripts/usps/eventcode_dev.properties");
		reader = getClass().getResourceAsStream("/usps/eventcode.txt");

		Properties p = new Properties();
		p.load(reader);
		Enumeration keys = p.propertyNames();
		while (keys.hasMoreElements()) {
			String key = (String) keys.nextElement();
			propertyMap.put(key, p.getProperty(key));
		}
		reader.close();
		return propertyMap;
	}

	private String buildPath(String env) {
		// return String.format("..%s%s%s%s_%s.properties", File.separator,
		// CONFIG, File.separator, PROP_PREFIX, env);

		String temp = ("/opt/digital/scripts/config/" + PROP_PREFIX + "_" + env + ".properties");

		return temp;
	}

	private String ReadEtlutilCofigfProperties(String env, String key)
			throws IOException {
		Properties properties = new Properties();
		String path = buildPath(env);
		// System.out.println(path);
		File file = new File(path);
		InputStream input = new FileInputStream(file);
		properties.load(input);
		return properties.getProperty(key);
	}
}
