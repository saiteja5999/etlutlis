package com.cvshealth.dep.etlutils.mcs;

public class RequestPayloadData {
	public String documentContent;

    public CommunicationMetaData communicationMetaData;

    public String getDocumentContent () {
        return documentContent;
    }

    public void setDocumentContent (String documentContent) {
        this.documentContent = documentContent;
    }

    public CommunicationMetaData getCommunicationMetaData () {
        return communicationMetaData;
    }

    public void setCommunicationMetaData (CommunicationMetaData communicationMetaData)
    {
        this.communicationMetaData = communicationMetaData;
    }

    @Override
    public String toString()
    {
        return "RequestPayloadData [documentContent = "+documentContent+", communicationMetaData = "+communicationMetaData+"]";
    }

}
