package com.cvshealth.dep.etlutils.common;

/**
 * JSON Response Code literature
 * 
 * @author CVS Health
 */
public interface Response {

	// Success scenarios
	public static final String STATUSCODE0000 = "0000";
	public static final String STATUSDESC0000 = "SUCCESS";

	// Failure scenarios
	public static final String STATUSCODE9999 = "9999";
	public static final String STATUSDESC9999 = "FAILURE";

}

