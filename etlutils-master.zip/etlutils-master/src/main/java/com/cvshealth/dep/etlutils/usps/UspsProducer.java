package com.cvshealth.dep.etlutils.usps;

import java.util.List;
import java.util.concurrent.BlockingQueue;

/**
 * UspsProducer is used to handle read the lines and pump to Queue Using Produce
 * and consume we have one producer and we can have several consumer
 * 
 * @author CVSHealth
 *
 */
public class UspsProducer implements Runnable {

	private BlockingQueue<String> queue;
	private List<String> lines;

	public UspsProducer(BlockingQueue<String> q, List<String> lines) {
		this.queue = q;
		this.lines = lines;
	}

	@Override
	public void run() {
		for (String line : lines) {
			try {
				System.out.println(line);
				queue.put(line);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Producer STOPPED.");
	}
}