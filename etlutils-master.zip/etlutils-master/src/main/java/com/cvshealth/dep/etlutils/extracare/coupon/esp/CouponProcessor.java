package com.cvshealth.dep.etlutils.extracare.coupon.esp;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import com.cvshealth.dep.etlutils.utils.ServiceClient;
import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.databind.ObjectMapper;

public class CouponProcessor implements Processor {
	private final String PRODUCT = "coupon";
	private String finalProduct = null;
	private final Logger infoLogger = Logger.getLogger("couponinfo");
	private final Logger errorLogger = Logger.getLogger("couponerror");
	private String feedFileName = "";
	private final String SRC_LOC_CD = "90042";
	private final String CATEGORY = "SavingsAndRewards";
	private final String MSG_SRC_CD = "M";
	private final String USER_ID = "MOBILE_ENT";
	private final String GRID = UUID.randomUUID().toString();

	protected CouponProcessor(String env, String fileName) {
		finalProduct = PRODUCT + "_" + env;
		feedFileName = fileName;
	}

	@Override
	public void processRecords(List<String> records) {
		ExecutorService service = null;

		try {
			final String dbpl_url = Utility.getProperty(PRODUCT, finalProduct,
					"DBPL.uri");

			int availCores = Utility.getAvailableCores();

			infoLogger
					.info("CouponProcessor | processRecords() | Avail CPU Cores:"
							+ availCores
							+ ", spawing threads as available cores for parallel execution");

			// service = Executors.newFixedThreadPool(availCores);
			service = Executors.newFixedThreadPool(1);
			int recCount = 0;

			// iterate for each record and process
			for (final String record : records) {

				// Spawn thread and process it async
				// service.execute(new Runnable() {
				String[] reqParamArray = null;
				String reqString = null;
				String etlPayload = null;
				CouponRequestBuilder requestBuilder = null;
				CouponRequest serviceRequest = null;
				recCount = recCount + 1;
				// @Override
				// public void run() {
				try {

					// Marshall the record into JSON Request
					reqParamArray = record.split(Utility.getProperty(PRODUCT,
							finalProduct, "field.delimiter"));
					//
					requestBuilder = new CouponRequestBuilder();
					serviceRequest = requestBuilder.couponDBPLRequest(
							reqParamArray, reqString, PRODUCT);
					if (null != serviceRequest) {
						ObjectMapper mapper = new ObjectMapper();

						String couponJson = mapper
								.writeValueAsString(serviceRequest);

						Map<String, Object> headers = new HashMap<String, Object>();
						headers.put("src_loc_cd", SRC_LOC_CD);
						headers.put("cat", CATEGORY);
						headers.put("msg_src_cd", MSG_SRC_CD);
						headers.put("grid", GRID);
						headers.put("user_id", USER_ID);

						String responseString = ServiceClient
								.postDataWithHeaders(dbpl_url, couponJson,
										headers);
						infoLogger
								.info("CouponProcessor | service.execute() | BulCoupon service executed"
										+ responseString);

						if (recCount > 15) {
							recCount = 0;
							Thread.sleep(1000);
						}
					}

				} catch (Exception e) {
					infoLogger
							.info("CouponProcessor | service.execute() | Error while converting record into JSONRequest"
									+ e.getMessage());
					errorLogger
							.error("CouponProcessor | service.execute() | Service Request : "
									+ record
									+ " | Error : "
									+ Utility.getStrackTrace(e));
				}

			}
		} catch (Exception e) {
			infoLogger
					.info("CouponProcessor | processRecords() | Error in processing records | "
							+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e));
		} finally {
			if (null != service) {
				service.shutdown();
				try {
					if (!service.awaitTermination(30, TimeUnit.MINUTES)) {
						errorLogger
								.info("CouponProcessor | processRecords() | Threads did not complete all the tasks in 30 minutes. For stopping the Job");
						service.shutdownNow();
					}
				} catch (Exception e) {
					errorLogger.error(Utility.getStrackTrace(e));
				}
			}
		}
	}
}
