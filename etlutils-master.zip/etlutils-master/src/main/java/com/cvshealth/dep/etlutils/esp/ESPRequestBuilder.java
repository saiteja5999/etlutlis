package com.cvshealth.dep.etlutils.esp;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.UUID;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.esp.ESPRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.esp.ESPRequest.RequestPayloadData.EmailPrefData;
import com.cvshealth.dep.etlutils.esp.ESPRequest.RequestPayloadData.GlobalOptData;
import com.cvshealth.dep.etlutils.esp.ESPRequest.RequestPayloadData.IdData;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Builds the ESP JSON request
 * 
 * @author CVSHealth
 */
public class ESPRequestBuilder implements RequestBuilder {
	private RequestMetaData requestMetaData;

	public ESPRequestBuilder(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	@SuppressWarnings("unchecked")
	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		final int RECORDTYPE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "RECORDTYPE_POSITION"));
		/*
		 * final int APPNAME_POSITION =
		 * Integer.parseInt(Utility.getProperty(finalProduct,
		 * "APPNAME_POSITION")); final int LINEOFBUSINESS_POSITION =
		 * Integer.parseInt(Utility.getProperty(finalProduct,
		 * "LINEOFBUSINESS_POSITION"));
		 */final int OPERATION_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "OPERATION_POSITION"));
		final int TIMESTAMP_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "TIMESTAMP_POSITION"));
		final int IDDATA_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "IDDATA_POSITION"));
		final int MEMBERID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERID_POSITION"));
		final int MEMBERTYPE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERTYPE_POSITION"));
		final int TXN_ORIGIN = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "TXN_ORIGIN"));
		final int CHANNELID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CHANNELID_POSITION"));
		final int CHANNELTYPE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CHANNELTYPE_POSITION"));
		final int FIRSTNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "FIRSTNAME_POSITION"));
		final int LASTNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "LASTNAME_POSITION"));
		final int BDATE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "BDATE_POSITION"));
		final int ADDR1_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "ADDR1_POSITION"));
		final int ADDR2_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "ADDR2_POSITION"));
		final int CITY_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "CITY_POSITION"));
		final int STATE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "STATE_POSITION"));
		final int POSTALCD_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "POSTALCD_POSITION"));
		final int GLOBALOPTDATA_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "GLOBALOPTDATA_POSITION"));
		final int EMAILPREFDATA_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EMAILPREFDATA_POSITION"));
		final int LAST_INDEX_POSITION = 20;

		String reqString = null;
		String recordType = null;
		String idDataString = null;
		String globalOptDataString = null;
		String emailPrefDataString = null;

		List<IdData> idDataList = null;
		List<GlobalOptData> globalOptDataList = null;
		List<EmailPrefData> emailPrefDataList = null;

		ObjectMapper objectMapper = null;
		ESPRequest jsonRequest = new ESPRequest();

		ESPRequest.RequestPayloadData requestPayloadData = null;

		ESPRequest.RequestPayloadData.Data data = null;
		ESPRequest.RequestPayloadData.ProfileData profileData = null;
		ESPRequest.RequestPayloadData.GlobalOptData globalOptData = null;

		recordType = reqParamArray[RECORDTYPE_POSITION].trim();

		/*
		 * if (null != recordType && recordType.equalsIgnoreCase("T")) {
		 * reqString = "EOF"; } else {
		 */
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		requestPayloadData = new ESPRequest.RequestPayloadData();
		/*
		 * requestMetaData = new ESPRequest.RequestMetaData();
		 * requestMetaData.setAppName(reqParamArray[APPNAME_POSITION]);
		 * requestMetaData.setLineOfBusiness(reqParamArray[
		 * LINEOFBUSINESS_POSITION]);
		 */
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		data = new ESPRequest.RequestPayloadData.Data();
		profileData = new ESPRequest.RequestPayloadData.ProfileData();

		// Populate Data
		data.setMemberID(reqParamArray[MEMBERID_POSITION].trim());
		data.setMemberType(reqParamArray[MEMBERTYPE_POSITION].trim());
		data.setTransactionOrigin(reqParamArray[TXN_ORIGIN].trim());
		data.setChannelID(reqParamArray[CHANNELID_POSITION].trim());
		data.setChannelType(reqParamArray[CHANNELTYPE_POSITION].trim());

		// Populate ProfileData
		profileData.setFirstName(reqParamArray[FIRSTNAME_POSITION].trim());
		profileData.setLastName(reqParamArray[LASTNAME_POSITION].trim());
		profileData.setBirthDate(reqParamArray[BDATE_POSITION].trim());
		profileData.setAddress1(reqParamArray[ADDR1_POSITION].trim());
		profileData.setAddress2(reqParamArray[ADDR2_POSITION].trim());
		profileData.setCity(reqParamArray[CITY_POSITION].trim());
		profileData.setState(reqParamArray[STATE_POSITION].trim());
		profileData.setPostalCode(reqParamArray[POSTALCD_POSITION].trim());

		idDataString = reqParamArray[IDDATA_POSITION].trim();
		globalOptDataString = reqParamArray[GLOBALOPTDATA_POSITION].trim();

		// Populate idDataList
		if (!idDataString.isEmpty()) {
			idDataList = new ArrayList<IdData>();
			idDataList = objectMapper.readValue(idDataString, List.class);
		}

		// Populate globalOptDataList
		if (!globalOptDataString.isEmpty()) {
			globalOptDataList = new ArrayList<GlobalOptData>();
			Map<String, String> globalMap = objectMapper.readValue(
					globalOptDataString,
					new TypeReference<Map<String, String>>() {
					});
			for (Entry<String, String> entry : globalMap.entrySet()) {
				globalOptData = new ESPRequest.RequestPayloadData.GlobalOptData();
				globalOptData.setKey(entry.getKey());
				globalOptData.setValue(entry.getValue());
				globalOptDataList.add(globalOptData);
			}
		}
		// Populate emailPrefDataList
		if (reqParamArray.length == LAST_INDEX_POSITION) {
			emailPrefDataString = reqParamArray[EMAILPREFDATA_POSITION].trim();
			if (!emailPrefDataString.isEmpty()) {
				emailPrefDataList = new ArrayList<EmailPrefData>();
				emailPrefDataList = objectMapper.readValue(emailPrefDataString,
						List.class);
			}
		}
		requestPayloadData.setOperation(reqParamArray[OPERATION_POSITION]
				.trim());
		requestPayloadData.setTimestamp(reqParamArray[TIMESTAMP_POSITION]
				.trim());
		requestPayloadData.setData(data);
		requestPayloadData.setProfile_data(profileData);
		requestPayloadData.setId_data(idDataList);
		requestPayloadData.setGlobal_opt_data(globalOptDataList);
		requestPayloadData.setEmail_pref_data(emailPrefDataList);
		jsonRequest.setRequestMetaData(requestMetaData);
		jsonRequest.setRequestPayloadData(requestPayloadData);

		reqString = objectMapper.writeValueAsString(jsonRequest);

		// }
		return reqString;
	}

}
