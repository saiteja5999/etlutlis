package com.cvshealth.dep.etlutils.paperless;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.common.JSONResponse;
import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.common.Response;

import com.cvshealth.dep.etlutils.paperless.PaperlessMain;
import com.cvshealth.dep.etlutils.paperless.PaperlessProcessor;
import com.cvshealth.dep.etlutils.utils.JSONBuilder;
import com.cvshealth.dep.etlutils.utils.Main;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PaperlessMain extends Main {

	private static List<String> records = null;

	private static Path inputFilePath = null;
	private static JSONResponse jsonResponse = null;
	private static Processor processor = null;

	private static final Charset CHARSET = Charset.forName("UTF-8");
	private static final Logger infoLogger = Logger.getLogger("paperlessinfo");
	private static final Logger errorLogger = Logger.getLogger("paperlesserror");
	

	public static void main(String[] args) {

		String env = null;
		String fileFeed = null;
		Date startDate = null;
		Date endDate = null;
		ObjectMapper objectMapper = null;

		try {
			startDate = new Date();
String logMsg = "PaperlessMain JOB started @ "+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss").format(new Date());
			infoLogger.info(logMsg);
			jsonResponse = new JSONResponse();
			objectMapper = new ObjectMapper();

			// Get the input file location
			if (args.length == 0 || null == args[0] || "".equals(args[0])
					|| null == args[1] || "".equals(args[1])) {
				jsonResponse = JSONBuilder
						.getJSONResponse(Response.STATUSCODE9999,
								Response.STATUSDESC9999,
								"Input file is empty or invalid / Execution environment is empty or invalid");
				infoLogger
						.info("PaperlessMain | Input file is empty or invalid / Execution environment is empty or invalid");
				errorLogger
						.error(objectMapper.writeValueAsString(jsonResponse));
				endDate = new Date();
			} else {
				env = args[0];
				fileFeed = args[1];

				infoLogger.info("PaperlessMain | env=" + env + " | fileFeed="
						+ fileFeed);
				infoLogger.info("PaperlessMain | Parsing fileFeed...");
				// Parse the input file to ensure the file exists
				inputFilePath = Paths.get(fileFeed);
				if (null == inputFilePath || !inputFilePath.toFile().isFile()) {
					jsonResponse = JSONBuilder.getJSONResponse(
							Response.STATUSCODE9999, Response.STATUSDESC9999,
							"Input file " + fileFeed
									+ " is invalid or does not exists");
					infoLogger.info("PaperlessMain | Input file " + fileFeed
							+ " is invalid or does not exists");
					errorLogger.error(objectMapper
							.writeValueAsString(jsonResponse));
					endDate = new Date();
				} else {
					// Read one record one by one from file. Transform it to
					// JSON object and put it in Kafka
					records = Files.readAllLines(inputFilePath, CHARSET);
					infoLogger.info("PaperlessMain | No of records in file found : "
							+ records.size());

					processor = new PaperlessProcessor(env, inputFilePath
							.getFileName().toString());
					infoLogger.info("PaperlessMain | Processing records...");
					processor.processRecords(records);
					jsonResponse = JSONBuilder.getJSONResponse(
							Response.STATUSCODE0000, Response.STATUSDESC0000,
							"");
					infoLogger.info(objectMapper
							.writeValueAsString(jsonResponse));
					endDate = new Date();
				}
			}
		} catch (Exception e) {
			jsonResponse = JSONBuilder.getJSONResponse(Response.STATUSCODE9999,
					Response.STATUSDESC9999,
					"Exception executing PaperlessMain Job | " + e.getMessage());
			try {
				infoLogger.info("Exception executing PaperlessMain Job | "
						+ e.getMessage());
				errorLogger
						.error(objectMapper.writeValueAsString(jsonResponse));
				endDate = new Date();
			} catch (JsonProcessingException e1) {
				errorLogger.error(Utility.getStrackTrace(e1));
			}
		}
		infoLogger.info("PaperlessMain JOB ended @ "
				+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
						.format(new Date()));
		infoLogger.info("PaperlessMain JOB took "
				+ (TimeUnit.SECONDS.toSeconds(endDate.getTime()
						- startDate.getTime())) + " ms");
	}
}
