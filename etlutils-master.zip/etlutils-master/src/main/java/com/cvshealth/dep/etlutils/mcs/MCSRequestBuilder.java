package com.cvshealth.dep.etlutils.mcs;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;

import org.apache.commons.io.FileUtils;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.mcs.MCSRequest;
import com.cvshealth.dep.etlutils.mcs.MCSRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.mcs.MCSRequest.RequestPayloadData.CommunicationMetaData;
import com.cvshealth.dep.etlutils.paperless.PaperlessRequest;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MCSRequestBuilder implements RequestBuilder {
	private RequestMetaData requestMetaData;

	public MCSRequestBuilder(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		
		final int COMMID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMID_POSITION").trim());
		final int MEMBERSOURCEID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "MEMBERSOURCEID_POSITION").trim());
		final int MEMBERSOURCE_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "MEMBERSOURCE_POSITION").trim());
		final int CLIENTCODE_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLIENTCODE_POSITION").trim());
		final int CLIENTID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLIENTID_POSITION").trim());
		final int CARRIERID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CARRIERID_POSITION").trim());
		final int ACCOUNTID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "ACCOUNTID_POSITION").trim());
		final int GROUPID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "GROUPID_POSITION").trim());
		final int MEMBERID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "MEMBERID_POSITION").trim());
		final int CONTRACTID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CONTRACTID_POSITION").trim());
		final int PBID_POSITION = Integer.parseInt(Utility.getProperty(folder,finalProduct, "PBID_POSITION").trim());
		final int LINEOFBUSINESS_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "LINEOFBUSINESS_POSITION").trim());
		final int COMMSOURCESYSTEM_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMSOURCESYSTEM_POSITION").trim());
		final int COMMNAME_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMNAME_POSITION").trim());
		final int COMMDELIVERYCHANNEL_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct,"COMMDELIVERYCHANNEL_POSITION").trim());
		final int COMMCONTACTINFO_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMCONTACTINFO_POSITION").trim());
		final int COMMSENDERINFO_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMSENDERINFO_POSITION").trim());
		final int COMMSUBJECT_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMSUBJECT_POSITION").trim());
		final int COMMDELIVERYDATE_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMDELIVERYDATE_POSITION").trim());
		final int COMMDELIVERYSTATUS_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct,"COMMDELIVERYSTATUS_POSITION").trim());
		final int COMMOUTCOME_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMOUTCOME_POSITION").trim());
		final int COMMFIRSTATTEMPT_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMFIRSTATTEMPT_POSITION").trim());
		final int COMMFINALATTEMPT_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMFINALATTEMPT_POSITION").trim());
		final int TEMPLATEID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "TEMPLATEID_POSITION").trim());
		final int COMMDOCNM_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMDOCNM_POSITION").trim());
		final int COMMDOCIND_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "COMMDOCIND_POSITION").trim());
		final int CLTPLATFORMCODE_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTPLATFORMCODE_POSITION").trim());
		final int CLTDIVISON_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTDIVISON_POSITION").trim());
		final int CLTMASTERGROUP_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTMASTERGROUP_POSITION").trim());
		final int CLTPLANTYPE_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTPLANTYPE_POSITION").trim());
		final int CLTGROUP_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTGROUP_POSITION").trim());
		final int CLTFAMILYID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTFAMILYID_POSITION").trim());
		final int CLTDEPENDENTCODE_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTDEPENDENTCODE_POSITION").trim());
		final int CLTMEMEBERDOB_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CLTMEMEBERDOB_POSITION").trim());
		final String ENV = Utility.getProperty(folder, finalProduct, "ENV");
		String fileName= MCSProcessor.getFeedFileName();

		String reqString = null;
		ObjectMapper objectMapper = null;
		MCSRequest jsonRequest = new MCSRequest();
		MCSRequest.RequestPayloadData requestPayloadData = null;
		MCSRequest.RequestPayloadData.CommunicationMetaData communicationMetaData = null;
		String date = new SimpleDateFormat("MMyyyy").format(new Date());
		String encodedDocumentContent = "";
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		requestMetaData = new MCSRequest.RequestMetaData();
		requestMetaData.setAppName("MCS");
		requestMetaData.setLineOfBusiness("MCS");
		requestMetaData.setConversationID(UUID.randomUUID().toString());
		requestMetaData.setEnv(ENV);
		requestPayloadData = new MCSRequest.RequestPayloadData();
		requestMetaData.setConversationID(UUID.randomUUID().toString());
		communicationMetaData = new MCSRequest.RequestPayloadData.CommunicationMetaData();
		communicationMetaData.setCommId(reqParamArray[COMMID_POSITION].trim());
		communicationMetaData.setMemberSourceId(reqParamArray[MEMBERSOURCEID_POSITION].trim());
		communicationMetaData.setMemberSource(reqParamArray[MEMBERSOURCE_POSITION].trim());
		communicationMetaData.setClientCode(reqParamArray[CLIENTCODE_POSITION].trim());
		communicationMetaData.setClientId(reqParamArray[CLIENTID_POSITION].trim());
		communicationMetaData.setCarrierId(reqParamArray[CARRIERID_POSITION].trim());
		communicationMetaData.setAccountId(reqParamArray[ACCOUNTID_POSITION].trim());
		communicationMetaData.setGroupId(reqParamArray[GROUPID_POSITION].trim());
		communicationMetaData.setMemberId(reqParamArray[MEMBERID_POSITION].trim());
		communicationMetaData.setContractID(reqParamArray[CONTRACTID_POSITION].trim());
		communicationMetaData.setPbpID(reqParamArray[PBID_POSITION].trim());
		communicationMetaData.setCommLOB(reqParamArray[LINEOFBUSINESS_POSITION].trim());
		communicationMetaData.setCommSourceSystem(reqParamArray[COMMSOURCESYSTEM_POSITION].trim());
		communicationMetaData.setCommName(reqParamArray[COMMNAME_POSITION].trim());
		communicationMetaData.setCommDeliveryChannel(reqParamArray[COMMDELIVERYCHANNEL_POSITION].trim());
		communicationMetaData.setCommContactInfo(reqParamArray[COMMCONTACTINFO_POSITION].trim());
		communicationMetaData.setCommSenderInfo(reqParamArray[COMMSENDERINFO_POSITION].trim());
		communicationMetaData.setCommSubject(reqParamArray[COMMSUBJECT_POSITION].trim());
		communicationMetaData.setCommDeliveryDate(reqParamArray[COMMDELIVERYDATE_POSITION].trim());
		communicationMetaData.setCommDeliveryStatus(reqParamArray[COMMDELIVERYSTATUS_POSITION].trim());
		communicationMetaData.setCommOutcome(reqParamArray[COMMOUTCOME_POSITION].trim());
		communicationMetaData.setCommFirstAttempt(reqParamArray[COMMFIRSTATTEMPT_POSITION]	.trim());
		communicationMetaData.setCommFinalAttempt(reqParamArray[COMMFINALATTEMPT_POSITION].trim());
		communicationMetaData.setDocTemplID(reqParamArray[TEMPLATEID_POSITION].trim());
		communicationMetaData.setCommDocNm(reqParamArray[COMMDOCNM_POSITION].trim());
		communicationMetaData.setCommDocInd(reqParamArray[COMMDOCIND_POSITION].trim());
		communicationMetaData.setCltPlatformCD(reqParamArray[CLTPLATFORMCODE_POSITION].trim());
		communicationMetaData.setCltDivision(reqParamArray[CLTDIVISON_POSITION].trim());
		communicationMetaData.setClstMasterGroup(reqParamArray[CLTMASTERGROUP_POSITION].trim());
		communicationMetaData.setCltPlanType(reqParamArray[CLTPLANTYPE_POSITION].trim());
		communicationMetaData.setCltGroup(reqParamArray[CLTGROUP_POSITION].trim());
		communicationMetaData.setCltFamilyID(reqParamArray[CLTFAMILYID_POSITION].trim());
		communicationMetaData.setCltDependentCD(reqParamArray[CLTDEPENDENTCODE_POSITION].trim());
		communicationMetaData.setCltDOB(reqParamArray[CLTMEMEBERDOB_POSITION].trim());
		communicationMetaData.setCommDlvryMnYr(date);
		communicationMetaData.setCommDocType("");//setting as empty as this field is not being used.
		communicationMetaData.setCommDocId("");
		communicationMetaData.setLoadDate("");
		communicationMetaData.setFileName(fileName);
		communicationMetaData.setRcsSource("ETL");//static value
		if ((reqParamArray[COMMDOCIND_POSITION]!=null) &&!(reqParamArray[COMMDOCIND_POSITION].equalsIgnoreCase("Y"))) {
			communicationMetaData.setCommDocInd("N");
		} else {
			//communicationMetaData.setCommDocInd(reqParamArray[COMMDOCIND_POSITION].trim());
			communicationMetaData.setCommDocInd("Y");
		}

		if (!(reqParamArray[COMMID_POSITION].contains("UPDATE-"))) {

			requestPayloadData.setCommunicationMetaData(communicationMetaData);
			requestMetaData.setOperationName("communicationInsert");
		
			if ((reqParamArray[COMMDOCIND_POSITION].equalsIgnoreCase("Y"))) {
				encodedDocumentContent = McsMain.encodeInputFile(communicationMetaData.getCommDocNm());
				requestPayloadData.setDocumentContent(encodedDocumentContent);
				requestPayloadData.setCommunicationMetaData(communicationMetaData);
				requestMetaData.setOperationName("communicationInsert");
}
		}
		 else {

			 requestMetaData.setOperationName("commDispositionUpdate");
				
			CommunicationMetaData communicationMetaData1 = new CommunicationMetaData();
			communicationMetaData1.setCommSourceSystem(reqParamArray[COMMSOURCESYSTEM_POSITION].trim());
			communicationMetaData1.setCommDeliveryStatus(reqParamArray[COMMDELIVERYSTATUS_POSITION].trim());
			communicationMetaData1.setCommOutcome(reqParamArray[COMMOUTCOME_POSITION].trim());
			communicationMetaData1.setCommFirstAttempt(reqParamArray[COMMFIRSTATTEMPT_POSITION].trim());
			communicationMetaData1.setCommFinalAttempt(reqParamArray[COMMFINALATTEMPT_POSITION].trim());
			//communicationMetaData1.setCommId(reqParamArray[COMMID_POSITION].trim());
			communicationMetaData1.setCommId(reqParamArray[COMMID_POSITION].trim().replace("UPDATE-", "")); 
			requestPayloadData.setCommunicationMetaData(communicationMetaData1);
		}
		//requestPayloadData.setCommunicationMetaData(communicationMetaData);
		jsonRequest.setRequestMetaData(requestMetaData);
		jsonRequest.setRequestPayloadData(requestPayloadData);

		reqString = objectMapper.writeValueAsString(jsonRequest);

		return reqString;
	}

}
