package com.cvshealth.dep.etlutils.notification;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.utils.JSONBuilder;
import com.cvshealth.dep.etlutils.utils.Service;
import com.cvshealth.dep.etlutils.utils.Utility;

/**
 * Processes each record and marshalls it into an Kafka JSON request and puts
 * into Kafka Queue
 * 
 * @author CVSHealth
 */
public class NotificationProcessor implements Processor {

	private final String PRODUCT = "notification";
	private String finalProduct = null;
	private final Logger infoLogger = Logger.getLogger("notificationinfo");
	private final Logger errorLogger = Logger.getLogger("notificationerror");

	protected NotificationProcessor(String env) {
		finalProduct = PRODUCT + "_" + env;
	}

	@Override
	public void processRecords(List<String> records) {
		ExecutorService service = null;

		try {
			final String[] kafkaServers = Utility.getProperty(PRODUCT,
					finalProduct, "kafka.servers").split("\\,");
			final String kafkaURI = Utility.getProperty(PRODUCT, finalProduct,
					"kafka.uri");
			int availCores = Utility.getAvailableCores();

			infoLogger
					.info("NotificationProcessor | processRecords() | Avail CPU Cores:"
							+ availCores
							+ ", spawing threads as available cores for parallel execution");

			service = Executors.newFixedThreadPool(availCores);

			// iterate for each record and process
			for (final String record : records) {
				// Spawn thread and process it async
				service.execute(new Runnable() {
					String[] reqParamArray = null;
					String reqString = null;
					String etlPayload = null;
					NotificationRequestBuilder requestBuilder = null;

					@Override
					public void run() {
						try {
							reqParamArray = record.split(Utility.getProperty(
									PRODUCT, finalProduct, "field.delimiter"));
							requestBuilder = new NotificationRequestBuilder();
							reqString = requestBuilder.getRequest(
									reqParamArray, finalProduct, PRODUCT);

							etlPayload = JSONBuilder.getETLPayload(Utility
									.getProperty(PRODUCT, finalProduct,
											"product"), reqString);

							// Invoke the Service to push the message into Kafka
							String URL = "http://"
									+ kafkaServers[ThreadLocalRandom.current()
											.nextInt(0, kafkaServers.length)]
									+ ":4100" + kafkaURI;
							Service.post(URL, "etlutils", etlPayload);
						} catch (Exception e) {
							infoLogger
									.info("NotificationProcessor | service.execute() | Error while converting record into KafkaRequest"
											+ e.getMessage());
							errorLogger.error(Utility.getStrackTrace(e));
						}
					}
				});
			}

		} catch (Exception e) {
			infoLogger
					.info("NotificationProcessor | processRecords() | Error in processing records | "
							+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e));
		} finally {
			if (null != service) {
				service.shutdown();
				try {
					service.awaitTermination(30, TimeUnit.MINUTES);
				} catch (Exception e) {
					errorLogger.error(Utility.getStrackTrace(e));
				}
			}
		}
	}
}
