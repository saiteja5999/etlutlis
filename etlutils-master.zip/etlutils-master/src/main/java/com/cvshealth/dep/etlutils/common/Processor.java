package com.cvshealth.dep.etlutils.common;

import java.util.List;

/**
 * Processor interface.
 * 
 * @author CVSHealth
 */
public interface Processor {
	public void processRecords(List<String> records) throws Exception;
}
