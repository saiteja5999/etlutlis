package com.cvshealth.dep.etlutils.generic;

public class RequestMetaData {
	private String appName = "";
	private String lineOfBusiness = "";
	private String conversationID = "";
	private String operationName="";

	


	

	
	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName
	 *            the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * @return the lineOfBusiness
	 */
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	/**
	 * @param lineOfBusiness
	 *            the lineOfBusiness to set
	 */
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	/**
	 * @return the conversationID
	 */
	public String getConversationID() {
		return conversationID;
	}

	/**
	 * @param conversationID
	 *            the conversationID to set
	 */
	public void setConversationID(String conversationID) {
		this.conversationID = conversationID;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	@Override
	public String toString() {
		return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
				+ lineOfBusiness + ", conversationID=" + conversationID
				+ ", operationName=" + operationName + "]";
	}

	
	
}


