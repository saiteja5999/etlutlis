package com.cvshealth.dep.etlutils.utils;

import org.json.JSONObject;
import com.cvshealth.dep.etlutils.common.JSONResponse;

/**
 * Builder class to build the response back to etl job
 * 
 * @author CVS Health
 */
public class JSONBuilder {

	/**
	 * Generates an ETL Payload. This payload will be embedded inside the Kafka
	 * Payload
	 * 
	 * @param etlApp
	 * @param payload
	 * @return
	 * @throws Exception
	 */
	public static String getETLPayload(String etlApp, String payload)
			throws Exception {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("etlApp", etlApp);
		jsonObject.put("payload", payload);
		return jsonObject.toString();
	}

	/**
	 * Generates a JSON response
	 * 
	 * @param statusCode
	 * @param statusDesc
	 * @param data
	 * @return
	 */
	public static JSONResponse getJSONResponse(String statusCode,
			String statusDesc, String data) {
		JSONResponse jsonResponse = new JSONResponse();
		JSONResponse.ResponseMetaData responseMetaData = new JSONResponse.ResponseMetaData();
		JSONResponse.ResponsePayloadData responsePayloadData = new JSONResponse.ResponsePayloadData();

		responseMetaData.setStatusCode(statusCode);
		responseMetaData.setStatusDesc(statusDesc);
		responsePayloadData.setData(data);
		jsonResponse.setResponseMetaData(responseMetaData);
		jsonResponse.setResponsePayloadData(responsePayloadData);
		return jsonResponse;
	}
}
