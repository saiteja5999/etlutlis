package com.cvshealth.dep.etlutils.usps;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.common.JSONResponse;
import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.common.Response;
import com.cvshealth.dep.etlutils.securechat.SecurechatMain;
import com.cvshealth.dep.etlutils.utils.JSONBuilder;
import com.cvshealth.dep.etlutils.utils.Main;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * USPSMain is the engine which is triggered by the Informatica Job. The job
 * reads the filefeed and marshalls into json messages and is then call nodejs
 * for further processing
 * 
 * @author CVSHealth
 */
public class UspsMain extends Main {

	private static List<String> records = null;

	private static Path inputFilePath = null;
	private static JSONResponse jsonResponse = null;
	private static Processor processor = null;
	public final static String PRODUCT = "usps";
	private static final String APP_NAME = "uspsetlutils";

	private static final Charset CHARSET = Charset.forName("UTF-8");
	private static final Logger infoLogger = Logger.getLogger("uspsinfo");
	private static final Logger errorLogger = Logger.getLogger("uspserror");

	private static final Date START_TIME = null;
	private static int WorkNumber = 2;
	static Utility util = Utility.getInstance();

	public static void main(String[] args) {

		String env = null;
		String fileFeed = null;
		Date startDate = null;
		Date endDate = null;
		ObjectMapper objectMapper = null;
		String logUri = "";

		try {
			startDate = new Date();
			String logMsg = "USPS JOB started @ "
					+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
							.format(new Date());
			infoLogger.info(logMsg);
			jsonResponse = new JSONResponse();
			objectMapper = new ObjectMapper();

			// Get the input file location
			if (args.length == 0 || null == args[0] || "".equals(args[0])
					|| null == args[1] || "".equals(args[1])) {
				jsonResponse = JSONBuilder
						.getJSONResponse(Response.STATUSCODE9999,
								Response.STATUSDESC9999,
								"Input file is empty or invalid / Execution environment is empty or invalid");
				infoLogger
						.info("USPSMain | Input file is empty or invalid / Execution environment is empty or invalid");
				errorLogger
						.error(objectMapper.writeValueAsString(jsonResponse));
				System.out.println(objectMapper
						.writeValueAsString(jsonResponse));
				endDate = new Date();
			} else {
				env = args[0];
				fileFeed = args[1];
				String finalProduct = UspsMain.PRODUCT + "_" + env;
				logUri = Utility.getProperty(PRODUCT, finalProduct,
						"logger.uri");

				infoLogger.info("USPSMain | env=" + env + " | fileFeed="
						+ fileFeed);
				System.out.println("USPSMain | env=" + env + " | fileFeed="
						+ fileFeed);
				infoLogger.info("USPSMain | Parsing fileFeed...");
				logMsg = "USPSMain | Parsing fileFeed...";
				util.log(APP_NAME, logUri, "0000", "Success", logMsg,
						START_TIME, "");
				System.out.println("USPSMain | Parsing fileFeed...");
				// Parse the input file to ensure the file exists
				inputFilePath = Paths.get(fileFeed);
				if (null == inputFilePath || !inputFilePath.toFile().isFile()) {
					jsonResponse = JSONBuilder.getJSONResponse(
							Response.STATUSCODE9999, Response.STATUSDESC9999,
							"Input file " + fileFeed
									+ " is invalid or does not exists");
					infoLogger.info("USPSMain | Input file " + fileFeed
							+ " is invalid or does not exists");
					errorLogger.error(objectMapper
							.writeValueAsString(jsonResponse));
					logMsg = "USPSMain | Input file " + fileFeed
							+ " is invalid or does not exists";
					util.log(APP_NAME, logUri, "9999", "Error", "Job failed",
							START_TIME, logMsg);

					System.out.println(objectMapper
							.writeValueAsString(jsonResponse));
					endDate = new Date();
				} else {
					// Read one record one by one from file. Transform it to
					// JSON object and put it in Kafka
					records = Files.readAllLines(inputFilePath, CHARSET);
					infoLogger
							.info("USPSMain | Num of records in file found : "
									+ records.size());
					System.out
							.println("USPSMain | Num of records in file found : "
									+ records.size());
					logMsg = "USPSMain | Num of records in file found : "
							+ records.size();
					util.log(logMsg);
					String workerNumber = System.getenv("worknumber");
					if (workerNumber != null) {
						WorkNumber = Integer.parseInt(workerNumber);
					}
					logMsg = "USPSMain | Num of records in file found : "
							+ records.size();
					util.log(APP_NAME, logUri, "0000", "Success", logMsg,
							START_TIME, "");
					System.out.println("USPSMain | Num of consumer : "
							+ WorkNumber);

					processor = new UspsProcessor(env, WorkNumber);
					infoLogger.info("USPSMain | Processing records...");
					processor.processRecords(records);

					jsonResponse = JSONBuilder.getJSONResponse(
							Response.STATUSCODE0000, Response.STATUSDESC0000,
							"");
					infoLogger.info(objectMapper
							.writeValueAsString(jsonResponse));
					logMsg = objectMapper.writeValueAsString(jsonResponse);
					util.log(logMsg);
					// System.out.println(objectMapper.writeValueAsString(jsonResponse));
					endDate = new Date();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonResponse = JSONBuilder.getJSONResponse(Response.STATUSCODE9999,
					Response.STATUSDESC9999,
					"Exception executing UspsMain Job | " + e.getMessage());
			try {
				infoLogger.info("Exception executing UspsMain Job | "
						+ e.getMessage());
				errorLogger
						.error(objectMapper.writeValueAsString(jsonResponse));
				String logMsg = "Exception executing UspsMain Job | "
						+ e.getMessage();
				util.log(APP_NAME, logUri, "9999", "Error", "Job failed",
						endDate, logMsg);
				endDate = new Date();
			} catch (JsonProcessingException e1) {
				errorLogger.error(Utility.getStrackTrace(e1));
			}
		}
		infoLogger.info("USPSMain JOB ended @ "
				+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
						.format(new Date()));
		System.out.println("USPSMain JOB ended @ "
				+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
						.format(new Date()));
		String logMsg = "USPSMain JOB ended @ "
				+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
						.format(new Date());
		util.log(APP_NAME, logUri, "0000", "Success", logMsg, new Date(), "");
		infoLogger.info("USPSMain JOB took "
				+ (TimeUnit.SECONDS.toSeconds(endDate.getTime()
						- startDate.getTime())) + " ms");
	}
}
