package com.cvshealth.dep.etlutils.echc;

import java.io.Serializable;

public class EchcRequest implements Serializable {

	private static final long serialVersionUID = -4187537354799171017L;

	private RequestMetaData requestMetaData = null;
	private RequestPayloadData requestPayloadData = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "PaperlessJSONRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}

	/**
	 * @return the requestMetaData
	 */
	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	/**
	 * @param requestMetaData
	 *            the requestMetaData to set
	 */
	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	/**
	 * @return the requestPayloadData
	 */
	public RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}

	/**
	 * @param requestPayloadData
	 *            the requestPayloadData to set
	 */
	public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */
	public static class RequestMetaData {
		private String appName = "";
		private String lineOfBusiness = "ECCM";
		private String conversationID = "";
	

		

		/**
		 * @return the appName
		 */
		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		/**
		 * @return the conversationID
		 */
		public String getConversationID() {
			return conversationID;
		}

		/**
		 * @param conversationID
		 *            the conversationID to set
		 */
		public void setConversationID(String conversationID) {
			this.conversationID = conversationID;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", conversationID=" + conversationID
					+ "]";
		}
	}

	public static class RequestPayloadData {
		
		private Data data = null;
		
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		
		/**
		 * @return the data
		 */
		public Data getData() {
			return data;
		}

		/**
		 * @param data
		 *            the data to set
		 */
		public void setData(Data data) {
			this.data = data;
		}
		@Override
		public String toString() {
			return "RequestPayloadData [data=" + data + "]";
		}



		/**
		 * Data
		 * 
		 * @author CVSHealth
		 */
		public static class Data {
			private String appName= "";
			private String memberID = "";
			private String memberSource = "";
			private String clientID = "";
			private String clientCode = "";
			private String commMsgReqestID = "";
			private String commAlertID = "";
			private String commAlertName = "";
			private String commDeliveryChannel = "";
			private String commContentType = "";
			private String commContactInfo = "";
			private String commSenderInfo = "";
			private String commSubject = "";
			private String clientSet="";
			private String firstName= "";
			private String lastName= "";
			private String planName="";
			private String documentName= "";
			private String docTypeCode="";
			private String campaignID= "";
			private String fileID ="";
			private String longURL= "";
			private String lob="";
			private String externalID= "";
			private String contentID="";
			
			private String parentMessageID="";
			private String subTopicID="";
			private String folderType= "";
			private String senderName="";
			private String recipientName= "";
			private String deliveryStatus ="";
			private String formFields= "";
			private String effectiveDate="";
			private String expirationDate= "";
			private String sentDate="";
			private String receivedDate="";
			private String origin= "";
			private String eventName="";
			private String requestId="";
			private String alertSourceSystem="";
			private String vaultEnabled="";
			private String orderNumber="";
			private String logCHV="";
			//private String alertId="";
			//private String alertName="";
			private String middleName="";
			private String echcReqID="";
			private String addrTypeCD="";
			private String address1="";
			private String address2="";
			private String city="";
			private String state="";
			private String zipCode="";
			private String ZipSfx="";
			private String cardMailingDate="";
			private String MktgType="";
			private String MKTG_TYPE_END_DT="";
			private String qlBenficieryID="";
			private String PreferredClientName="";
			private String echcType="";
			private String MeddCommercial="";
			private String CarrierID="";
			private String AccountID="";
			private String GroupID="";
			//private String CommonContentType="";
			private String SecureMsgSenderName="";
			private String interactionID="";
			private String alertName="";
			private String alertID="";

			public String getAlertName() {
				return alertName;
			}
			public void setAlertName(String alertName) {
				this.alertName = alertName;
			}
			public String getAlertID() {
				return alertID;
			}
			public void setAlertID(String alertID) {
				this.alertID = alertID;
			}
			public String getInteractionID() {
				return interactionID;
			}
			public void setInteractionID(String interactionID) {
				this.interactionID = interactionID;
			}
			public String getMiddleName() {
				return middleName;
			}
			public void setMiddleName(String middleName) {
				this.middleName = middleName;
			}
			public String getEchcReqID() {
				return echcReqID;
			}
			public void setEchcReqID(String echcReqID) {
				this.echcReqID = echcReqID;
			}
			public String getAddrTypeCD() {
				return addrTypeCD;
			}
			public void setAddrTypeCD(String addrTypeCD) {
				this.addrTypeCD = addrTypeCD;
			}
			public String getAddress1() {
				return address1;
			}
			public void setAddress1(String address1) {
				this.address1 = address1;
			}
			public String getAddress2() {
				return address2;
			}
			public void setAddress2(String address2) {
				this.address2 = address2;
			}
			public String getCity() {
				return city;
			}
			public void setCity(String city) {
				this.city = city;
			}
			public String getState() {
				return state;
			}
			public void setState(String state) {
				this.state = state;
			}
			public String getZipCode() {
				return zipCode;
			}
			public void setZipCode(String zipCode) {
				this.zipCode = zipCode;
			}
			public String getZipSfx() {
				return ZipSfx;
			}
			public void setZipSfx(String zipSfx) {
				ZipSfx = zipSfx;
			}
			public String getCardMailingDate() {
				return cardMailingDate;
			}
			public void setCardMailingDate(String cardMailingDate) {
				this.cardMailingDate = cardMailingDate;
			}
			public String getMktgType() {
				return MktgType;
			}
			public void setMktgType(String mktgType) {
				MktgType = mktgType;
			}
			public String getMKTG_TYPE_END_DT() {
				return MKTG_TYPE_END_DT;
			}
			public void setMKTG_TYPE_END_DT(String mKTG_TYPE_END_DT) {
				MKTG_TYPE_END_DT = mKTG_TYPE_END_DT;
			}
			public String getQlBenficieryID() {
				return qlBenficieryID;
			}
			public void setQlBenficieryID(String qlBenficieryID) {
				this.qlBenficieryID = qlBenficieryID;
			}
			public String getPreferredClientName() {
				return PreferredClientName;
			}
			public void setPreferredClientName(String preferredClientName) {
				PreferredClientName = preferredClientName;
			}
			public String getEchcType() {
				return echcType;
			}
			public void setEchcType(String echcType) {
				this.echcType = echcType;
			}
			public String getMeddCommercial() {
				return MeddCommercial;
			}
			public void setMeddCommercial(String meddCommercial) {
				MeddCommercial = meddCommercial;
			}
			public String getCarrierID() {
				return CarrierID;
			}
			public void setCarrierID(String carrierID) {
				CarrierID = carrierID;
			}
			public String getAccountID() {
				return AccountID;
			}
			public void setAccountID(String accountID) {
				AccountID = accountID;
			}
			public String getGroupID() {
				return GroupID;
			}
			public void setGroupID(String groupID) {
				GroupID = groupID;
			}
			public String getSecureMsgSenderName() {
				return SecureMsgSenderName;
			}
			public void setSecureMsgSenderName(String secureMsgSenderName) {
				SecureMsgSenderName = secureMsgSenderName;
			}
			public String getContentID() {
				return contentID;
			}
			public String getRequestId() {
				return requestId;
			}
			public void setRequestId(String requestId) {
				this.requestId = requestId;
			}
			public String getAlertSourceSystem() {
				return alertSourceSystem;
			}
			public void setAlertSourceSystem(String alertSourceSystem) {
				this.alertSourceSystem = alertSourceSystem;
			}
			public String getVaultEnabled() {
				return vaultEnabled;
			}
			public void setVaultEnabled(String vaultEnabled) {
				this.vaultEnabled = vaultEnabled;
			}
			public String getOrderNumber() {
				return orderNumber;
			}
			public void setOrderNumber(String orderNumber) {
				this.orderNumber = orderNumber;
			}
			public String getLogCHV() {
				return logCHV;
			}
			public void setLogCHV(String logCHV) {
				this.logCHV = logCHV;
			}
			public void setContentID(String contentID) {
				this.contentID = contentID;
			}
			
			public String getParentMessageID() {
				return parentMessageID;
			}
			public void setParentMessageID(String parentMessageId) {
				this.parentMessageID = parentMessageId;
			}
			public String getSubTopicID() {
				return subTopicID;
			}
			public void setSubTopicID(String subTopicId) {
				this.subTopicID = subTopicId;
			}
			public String getFolderType() {
				return folderType;
			}
			public void setFolderType(String folderType) {
				this.folderType = folderType;
			}
			public String getSenderName() {
				return senderName;
			}
			public void setSenderName(String senderName) {
				this.senderName = senderName;
			}
			public String getRecipientName() {
				return recipientName;
			}
			public void setRecipientName(String recipientName) {
				this.recipientName = recipientName;
			}
			public String getDeliveryStatus() {
				return deliveryStatus;
			}
			public void setDeliveryStatus(String deliveryStatus) {
				this.deliveryStatus = deliveryStatus;
			}
			public String getFormFields() {
				return formFields;
			}
			public void setFormFields(String formFields) {
				this.formFields = formFields;
			}
			public String getEffectiveDate() {
				return effectiveDate;
			}
			public void setEffectiveDate(String effectiveDate) {
				this.effectiveDate = effectiveDate;
			}
			public String getExpirationDate() {
				return expirationDate;
			}
			public void setExpirationDate(String expirationDate) {
				this.expirationDate = expirationDate;
			}
			public String getSentDate() {
				return sentDate;
			}
			public void setSentDate(String sentDate) {
				this.sentDate = sentDate;
			}
			public String getReceivedDate() {
				return receivedDate;
			}
			public void setReceivedDate(String receivedDate) {
				this.receivedDate = receivedDate;
			}
			public String getOrigin() {
				return origin;
			}
			public void setOrigin(String origin) {
				this.origin = origin;
			}
			public String getEventName() {
				return eventName;
			}
			public void setEventName(String eventName) {
				this.eventName = eventName;
			}
			public String getAppName() {
				return appName;
			}
			public void setAppName(String appName) {
				this.appName = appName;
			}
			public String getMemberID() {
				return memberID;
			}
			public void setMemberID(String memberID) {
				this.memberID = memberID;
			}
			public String getMemberSource() {
				return memberSource;
			}
			public void setMemberSource(String memberSource) {
				this.memberSource = memberSource;
			}
			public String getClientID() {
				return clientID;
			}
			public void setClientID(String clientID) {
				this.clientID = clientID;
			}
			public String getClientCode() {
				return clientCode;
			}
			public void setClientCode(String clientCode) {
				this.clientCode = clientCode;
			}
			public String getCommMsgReqestID() {
				return commMsgReqestID;
			}
			public void setCommMsgReqestID(String commMsgReqestID) {
				this.commMsgReqestID = commMsgReqestID;
			}
			public String getCommAlertID() {
				return commAlertID;
			}
			public void setCommAlertID(String commAlertID) {
				this.commAlertID = commAlertID;
			}
			public String getCommAlertName() {
				return commAlertName;
			}
			public void setCommAlertName(String commAlertName) {
				this.commAlertName = commAlertName;
			}
			public String getCommDeliveryChannel() {
				return commDeliveryChannel;
			}
			public void setCommDeliveryChannel(String commDeliveryChannel) {
				this.commDeliveryChannel = commDeliveryChannel;
			}
			public String getCommContentType() {
				return commContentType;
			}
			public void setCommContentType(String commContentType) {
				this.commContentType = commContentType;
			}
			public String getCommContactInfo() {
				return commContactInfo;
			}
			public void setCommContactInfo(String commContactInfo) {
				this.commContactInfo = commContactInfo;
			}
			public String getCommSenderInfo() {
				return commSenderInfo;
			}
			public void setCommSenderInfo(String commSenderInfo) {
				this.commSenderInfo = commSenderInfo;
			}
			public String getCommSubject() {
				return commSubject;
			}
			public void setCommSubject(String commSubject) {
				this.commSubject = commSubject;
			}
			public String getClientSet() {
				return clientSet;
			}
			public void setClientSet(String clientSet) {
				this.clientSet = clientSet;
			}
			public String getFirstName() {
				return firstName;
			}
			public void setFirstName(String firstName) {
				this.firstName = firstName;
			}
			public String getLastName() {
				return lastName;
			}
			public void setLastName(String lastName) {
				this.lastName = lastName;
			}
			public String getPlanName() {
				return planName;
			}
			public void setPlanName(String planName) {
				this.planName = planName;
			}
			public String getDocumentName() {
				return documentName;
			}
			public void setDocumentName(String documentName) {
				this.documentName = documentName;
			}
			public String getDocTypeCode() {
				return docTypeCode;
			}
			public void setDocTypeCode(String docTypeCode) {
				this.docTypeCode = docTypeCode;
			}
			public String getCampaignID() {
				return campaignID;
			}
			public void setCampaignID(String campaignID) {
				this.campaignID = campaignID;
			}
			public String getFileID() {
				return fileID;
			}
			public void setFileID(String fileID) {
				this.fileID = fileID;
			}
			public String getLongURL() {
				return longURL;
			}
			public void setLongURL(String longURL) {
				this.longURL = longURL;
			}
			public String getLob() {
				return lob;
			}
			public void setLob(String lob) {
				this.lob = lob;
			}
			public String getExternalID() {
				return externalID;
			}
			public void setExternalID(String externalID) {
				this.externalID = externalID;
			}
			@Override
			public String toString() {
				return "Data [appName=" + appName + ", memberID=" + memberID
						+ ", memberSource=" + memberSource + ", clientID="
						+ clientID + ", clientCode=" + clientCode
						+ ", commMsgReqestID=" + commMsgReqestID
						+ ", commAlertID=" + commAlertID + ", commAlertName="
						+ commAlertName + ", commDeliveryChannel="
						+ commDeliveryChannel + ", commContentType="
						+ commContentType + ", commContactInfo="
						+ commContactInfo + ", commSenderInfo="
						+ commSenderInfo + ", commSubject=" + commSubject
						+ ", clientSet=" + clientSet + ", firstName="
						+ firstName + ", lastName=" + lastName + ", planName="
						+ planName + ", documentName=" + documentName
						+ ", docTypeCode=" + docTypeCode + ", campaignID="
						+ campaignID + ", fileID=" + fileID + ", longURL="
						+ longURL + ", lob=" + lob + ", externalID="
						+ externalID + ", contentID=" + contentID
						+ ", parentMessageID=" + parentMessageID
						+ ", subTopicID=" + subTopicID + ", folderType="
						+ folderType + ", senderName=" + senderName
						+ ", recipientName=" + recipientName
						+ ", deliveryStatus=" + deliveryStatus
						+ ", formFields=" + formFields + ", effectiveDate="
						+ effectiveDate + ", expirationDate=" + expirationDate
						+ ", sentDate=" + sentDate + ", receivedDate="
						+ receivedDate + ", origin=" + origin + ", eventName="
						+ eventName + ", requestId=" + requestId
						+ ", alertSourceSystem=" + alertSourceSystem
						+ ", vaultEnabled=" + vaultEnabled + ", orderNumber="
						+ orderNumber + ", logCHV=" + logCHV + ", middleName="
						+ middleName + ", echcReqID=" + echcReqID
						+ ", addrTypeCD=" + addrTypeCD + ", address1="
						+ address1 + ", address2=" + address2 + ", city="
						+ city + ", state=" + state + ", zipCode=" + zipCode
						+ ", ZipSfx=" + ZipSfx + ", cardMailingDate="
						+ cardMailingDate + ", MktgType=" + MktgType
						+ ", MKTG_TYPE_END_DT=" + MKTG_TYPE_END_DT
						+ ", qlBenficieryID=" + qlBenficieryID
						+ ", PreferredClientName=" + PreferredClientName
						+ ", echcType=" + echcType + ", MeddCommercial="
						+ MeddCommercial + ", CarrierID=" + CarrierID
						+ ", AccountID=" + AccountID + ", GroupID=" + GroupID
						+ ", SecureMsgSenderName=" + SecureMsgSenderName
						+ ", interactionID=" + interactionID + ", alertName="
						+ alertName + ", alertID=" + alertID + "]";
			}
			
	
			
				
	
		}

		
	}
}
