package com.cvshealth.dep.etlutils.extracare.analytic.esp;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.extracare.analytic.esp.AnalyticRequest.Analytic_event_data;
import com.cvshealth.dep.etlutils.utils.Utility;

public class AnalyticRequestBuilder {
	private final Logger infoLogger = Logger.getLogger("analyticinfo");
	private final Logger errorLogger = Logger.getLogger("analyticerror");

	@SuppressWarnings("null")
	public AnalyticRequest analyticESLRequest(String[] reqParamArray,
			String finalProduct, String folder) {
		AnalyticRequest analyticRequest = new AnalyticRequest();

		String timestamp = null;
		Integer input_event_type_cd = null;
		String input_recpt_rqst = null;
		if (reqParamArray.length < 3) {
			errorLogger
					.error(" AnalyticRequestBuilder| analyticESLRequest() | Service Request : "
							+ reqParamArray[0].toString()
							+ " | Error : "
							+ "Input record doesn't have mandatory parameters");
			return null;
		} else {
			input_event_type_cd = Integer.parseInt(reqParamArray[0].trim());
			timestamp = reqParamArray[1].trim();
			input_recpt_rqst = reqParamArray[2].trim();
			// System.out.println(isNumeric(input_recpt_rqst));
			if ((input_recpt_rqst != null) && (!isValid(input_recpt_rqst))) {

				errorLogger
						.error(" AnalyticRequestBuilder| analyticESLRequest() | Service Request : "
								+ reqParamArray[2].toString()
								+ " | Error : "
								+ "Receipt number is not correct");
				return null;

			}
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date inputDate = null;
		String outputDate = null;
		try {
			inputDate = sdf.parse(timestamp);
			sdf.applyPattern("yyyyMMddHH:mm:ss-00:00");
			outputDate = sdf.format(inputDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorLogger
					.error(" AnalyticRequestBuilder| analyticESLRequest() | Service Request : "
							+ reqParamArray.toString()
							+ " | Error : "
							+ Utility.getStrackTrace(e));

			return null;
		}

		Analytic_event_data analytic_event_data = new Analytic_event_data();
		analytic_event_data.setRecpt_rqst_seq_nbr(input_recpt_rqst);

		analyticRequest.setAnalytic_event_data(analytic_event_data);
		analyticRequest.setTs(outputDate);
		analyticRequest.setAnalytic_event_type_cd(input_event_type_cd);

		return analyticRequest;
	}

	public boolean isValid(String str) {
		if (str.length() < 8) {
			return false;
		}
		               if (str.length() > 10){
                       return false;
               }

		for (char c : str.toCharArray()) {
			if (!Character.isDigit(c))
				return false;
		}
		return true;
	}
}
