package com.cvshealth.dep.etlutils.mcs;

import java.io.Serializable;
import java.util.List;

import com.cvshealth.dep.etlutils.mcs.MCSRequest;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;


public class MCSRequest implements Serializable {

	private static final long serialVersionUID = -4187537354799171017L;

	

	private RequestMetaData requestMetaData = null;
	private RequestPayloadData requestPayloadData = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MCSJSONRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}

	/**
	 * @return the requestMetaData
	 */
	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	/**
	 * @param requestMetaData
	 *            the requestMetaData to set
	 */
	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	/**
	 * @return the requestPayloadData
	 */
	public RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}

	/**
	 * @param requestPayloadData
	 *            the requestPayloadData to set
	 */
	public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */@JsonInclude(Include.NON_NULL)
	public static class RequestMetaData {
		private String appName = "";
		private String lineOfBusiness = "MCS";
		private String conversationID = "";
		private String operationName="";
		private String env= "";
		
	

		

		public String getEnv() {
			return env;
		}

		public void setEnv(String env) {
			this.env = env;
		}

		/**
		 * @return the appName
		 */
		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		/**
		 * @return the conversationID
		 */
		public String getConversationID() {
			return conversationID;
		}

		/**
		 * @param conversationID
		 *            the conversationID to set
		 */
		public void setConversationID(String conversationID) {
			this.conversationID = conversationID;
		}

		public String getOperationName() {
			return operationName;
		}

		public void setOperationName(String operationName) {
			this.operationName = operationName;
		}

		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", conversationID=" + conversationID
					+ ", operationName=" + operationName + ", env=" + env + "]";
		}

		
	}

	@JsonInclude(Include.NON_NULL)
	public static class RequestPayloadData {
		 

		public String documentContent;

		    public CommunicationMetaData communicationMetaData;

		    public String getDocumentContent () {
		        return documentContent;
		    }

		    public void setDocumentContent (String documentContent) {
		        this.documentContent = documentContent;
		    }

		    public CommunicationMetaData getCommunicationMetaData () {
		        return communicationMetaData;
		    }

		    public void setCommunicationMetaData (CommunicationMetaData communicationMetaData)
		    {
		        this.communicationMetaData = communicationMetaData;
		    }

		    @Override
		    public String toString()
		    {
		        return "RequestPayloadData [documentContent = "+documentContent+", communicationMetaData = "+communicationMetaData+"]";
		    }
	
		    @JsonInclude(Include.NON_NULL)
	public static class CommunicationMetaData {
		private String commDeliveryDate="";
	    private String clientId="";
	    private String memberSourceId="";
	    private String commContactInfo="";
	    private String groupId="";
	    private String commDeliveryStatus="";
	    private String commDeliveryChannel="";
	    private String commSourceSystem="";
	    private String commSubject="";
	    private String commFirstAttempt="";
	    private String accountId="";
	    private String commDocId="";
	    private String commSenderInfo="";
	    private String clientCode="";
	    private String commOutcome="";
	    private String commId="";
	    private String commDocNm="";
	    private String commFinalAttempt="";
	    private String commName="";
	    private String carrierId="";
	    private String memberSource="";
	    private String memberId="";
	    private String commDocType="";
	    private String contractID="";
	    private String pbpID="";
	    private String commLOB="";
	    private String commDocInd="";
	    private String cltPlatformCD="";
	    private String cltDivision="";
		private String clstMasterGroup="";
	    private String cltPlanType="";
	    private String cltGroup="";
	    private String cltFamilyID="";
	    private String cltDOB="";
	    private String cltDependentCD="";
	    private String commDlvryMnYr="";
	    private String docTemplID="";
	    private String fileName="";
	    private String loadDate="";
	    private String rcsSource="";
		public String getCommDeliveryDate() {
			return commDeliveryDate;
		}
		public void setCommDeliveryDate(String commDeliveryDate) {
			this.commDeliveryDate = commDeliveryDate;
		}
		public String getClientId() {
			return clientId;
		}
		public void setClientId(String clientId) {
			this.clientId = clientId;
		}
		public String getMemberSourceId() {
			return memberSourceId;
		}
		public void setMemberSourceId(String memberSourceId) {
			this.memberSourceId = memberSourceId;
		}
		public String getCommContactInfo() {
			return commContactInfo;
		}
		public void setCommContactInfo(String commContactInfo) {
			this.commContactInfo = commContactInfo;
		}
		public String getGroupId() {
			return groupId;
		}
		public void setGroupId(String groupId) {
			this.groupId = groupId;
		}
		public String getCommDeliveryStatus() {
			return commDeliveryStatus;
		}
		public void setCommDeliveryStatus(String commDeliveryStatus) {
			this.commDeliveryStatus = commDeliveryStatus;
		}
		public String getCommDeliveryChannel() {
			return commDeliveryChannel;
		}
		public void setCommDeliveryChannel(String commDeliveryChannel) {
			this.commDeliveryChannel = commDeliveryChannel;
		}
		public String getCommSourceSystem() {
			return commSourceSystem;
		}
		public void setCommSourceSystem(String commSourceSystem) {
			this.commSourceSystem = commSourceSystem;
		}
		public String getCommSubject() {
			return commSubject;
		}
		public void setCommSubject(String commSubject) {
			this.commSubject = commSubject;
		}
		public String getCommFirstAttempt() {
			return commFirstAttempt;
		}
		public void setCommFirstAttempt(String commFirstAttempt) {
			this.commFirstAttempt = commFirstAttempt;
		}
		public String getAccountId() {
			return accountId;
		}
		public void setAccountId(String accountId) {
			this.accountId = accountId;
		}
		public String getCommDocId() {
			return commDocId;
		}
		public void setCommDocId(String commDocId) {
			this.commDocId = commDocId;
		}
		public String getCommSenderInfo() {
			return commSenderInfo;
		}
		public void setCommSenderInfo(String commSenderInfo) {
			this.commSenderInfo = commSenderInfo;
		}
		public String getClientCode() {
			return clientCode;
		}
		public void setClientCode(String clientCode) {
			this.clientCode = clientCode;
		}
		public String getCommOutcome() {
			return commOutcome;
		}
		public void setCommOutcome(String commOutcome) {
			this.commOutcome = commOutcome;
		}
		public String getCommId() {
			return commId;
		}
		public void setCommId(String commId) {
			this.commId = commId;
		}
		public String getCommDocNm() {
			return commDocNm;
		}
		public void setCommDocNm(String commDocNm) {
			this.commDocNm = commDocNm;
		}
		public String getCommFinalAttempt() {
			return commFinalAttempt;
		}
		public void setCommFinalAttempt(String commFinalAttempt) {
			this.commFinalAttempt = commFinalAttempt;
		}
		public String getCommName() {
			return commName;
		}
		public void setCommName(String commName) {
			this.commName = commName;
		}
		public String getCarrierId() {
			return carrierId;
		}
		public void setCarrierId(String carrierId) {
			this.carrierId = carrierId;
		}
		public String getMemberSource() {
			return memberSource;
		}
		public void setMemberSource(String memberSource) {
			this.memberSource = memberSource;
		}
		public String getMemberId() {
			return memberId;
		}
		public void setMemberId(String memberId) {
			this.memberId = memberId;
		}
		public String getCommDocType() {
			return commDocType;
		}
		public void setCommDocType(String commDocType) {
			this.commDocType = commDocType;
		}
		public String getContractID() {
			return contractID;
		}
		public void setContractID(String contractID) {
			this.contractID = contractID;
		}
		public String getPbpID() {
			return pbpID;
		}
		public void setPbpID(String pbpID) {
			this.pbpID = pbpID;
		}
		public String getCommLOB() {
			return commLOB;
		}
		public void setCommLOB(String commLOB) {
			this.commLOB = commLOB;
		}
		public String getCommDocInd() {
			return commDocInd;
		}
		public void setCommDocInd(String commDocInd) {
			this.commDocInd = commDocInd;
		}
		public String getCltPlatformCD() {
			return cltPlatformCD;
		}
		public void setCltPlatformCD(String cltPlatformCD) {
			this.cltPlatformCD = cltPlatformCD;
		}
		public String getCltDivision() {
			return cltDivision;
		}
		public void setCltDivision(String cltDivision) {
			this.cltDivision = cltDivision;
		}
		public String getClstMasterGroup() {
			return clstMasterGroup;
		}
		public void setClstMasterGroup(String clstMasterGroup) {
			this.clstMasterGroup = clstMasterGroup;
		}
		public String getCltPlanType() {
			return cltPlanType;
		}
		public void setCltPlanType(String cltPlanType) {
			this.cltPlanType = cltPlanType;
		}
		public String getCltGroup() {
			return cltGroup;
		}
		public void setCltGroup(String cltGroup) {
			this.cltGroup = cltGroup;
		}
		public String getCltFamilyID() {
			return cltFamilyID;
		}
		public void setCltFamilyID(String cltFamilyID) {
			this.cltFamilyID = cltFamilyID;
		}
		public String getCltDOB() {
			return cltDOB;
		}
		public void setCltDOB(String cltDOB) {
			this.cltDOB = cltDOB;
		}
		public String getCltDependentCD() {
			return cltDependentCD;
		}
		public void setCltDependentCD(String cltDependentCD) {
			this.cltDependentCD = cltDependentCD;
		}
		public String getCommDlvryMnYr() {
			return commDlvryMnYr;
		}
		public void setCommDlvryMnYr(String commDlvryMnYr) {
			this.commDlvryMnYr = commDlvryMnYr;
		}
		public String getDocTemplID() {
			return docTemplID;
		}
		public void setDocTemplID(String docTemplID) {
			this.docTemplID = docTemplID;
		}
		public String getFileName() {
			return fileName;
		}
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}
		public String getLoadDate() {
			return loadDate;
		}
		public void setLoadDate(String loadDate) {
			this.loadDate = loadDate;
		}
		public String getRcsSource() {
			return rcsSource;
		}
		public void setRcsSource(String rcsSource) {
			this.rcsSource = rcsSource;
		}
		@Override
		public String toString() {
			return "CommunicationMetaData [commDeliveryDate="
					+ commDeliveryDate + ", clientId=" + clientId
					+ ", memberSourceId=" + memberSourceId
					+ ", commContactInfo=" + commContactInfo + ", groupId="
					+ groupId + ", commDeliveryStatus=" + commDeliveryStatus
					+ ", commDeliveryChannel=" + commDeliveryChannel
					+ ", commSourceSystem=" + commSourceSystem
					+ ", commSubject=" + commSubject + ", commFirstAttempt="
					+ commFirstAttempt + ", accountId=" + accountId
					+ ", commDocId=" + commDocId + ", commSenderInfo="
					+ commSenderInfo + ", clientCode=" + clientCode
					+ ", commOutcome=" + commOutcome + ", commId=" + commId
					+ ", commDocNm=" + commDocNm + ", commFinalAttempt="
					+ commFinalAttempt + ", commName=" + commName
					+ ", carrierId=" + carrierId + ", memberSource="
					+ memberSource + ", memberId=" + memberId
					+ ", commDocType=" + commDocType + ", contractID="
					+ contractID + ", pbpID=" + pbpID + ", commLOB=" + commLOB
					+ ", commDocInd=" + commDocInd + ", cltPlatformCD="
					+ cltPlatformCD + ", cltDivision=" + cltDivision
					+ ", clstMasterGroup=" + clstMasterGroup + ", cltPlanType="
					+ cltPlanType + ", cltGroup=" + cltGroup + ", cltFamilyID="
					+ cltFamilyID + ", cltDOB=" + cltDOB + ", cltDependentCD="
					+ cltDependentCD + ", commDlvryMnYr=" + commDlvryMnYr
					+ ", docTemplID=" + docTemplID + ", fileName=" + fileName
					+ ", loadDate=" + loadDate + ", rcsSource=" + rcsSource
					+ "]";
		}
	
	}



	}		
	
	}		
				
	
		

		
	

