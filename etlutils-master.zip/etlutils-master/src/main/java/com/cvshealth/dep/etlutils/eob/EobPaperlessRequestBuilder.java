package com.cvshealth.dep.etlutils.eob;

import java.util.ArrayList;
import java.util.List;


import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.eob.EobPaperlessRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.usps.UspsRequest;
import com.cvshealth.dep.etlutils.usps.ZipcodeUtil;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EobPaperlessRequestBuilder implements RequestBuilder {
	private RequestMetaData requestMetaData;

	public EobPaperlessRequestBuilder(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	
	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		

		 final int APPNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "APPNAME_POSITION").trim());
		
		final int MEMBERID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERID_POSITION").trim());
		final int MEMBERSOURCE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERSOURCE_POSITION").trim());
		final int CLIENTID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CLIENTID_POSITION").trim());
		final int CLIENTCODE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CLIENTCODE_POSITION").trim());
		final int FIRSTNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "FIRSTNAME_POSITION").trim());
		final int COMMMSGREQESTID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMMSGREQESTID_POSITION").trim());
		final int COMMALERTID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMALERTID_POSITION").trim());
		final int COMMALERTNAME_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMALERTNAME_POSITION").trim());
		final int COMMDELIVERYCHANNEL_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMDELIVERYCHANNEL_POSITION").trim());
		final int COMMCONTENTTYPE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMCONTENTTYPE_POSITION").trim());
		final int COMMCONTACTINFO_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMCONTACTINFO_POSITION").trim());
		final int COMMSENDERINFO_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMSENDERINFO_POSITION").trim());
		final int COMMSUBJECT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMSUBJECT_POSITION").trim());
		final int CLIENTSET_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CLIENTSET_POSITION").trim());
		
		final int LASTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LASTNAME_POSITION").trim());
		final int PLANNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PLANNAME_POSITION").trim());
		final int DOCUMENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DOCUMENTNAME_POSITION").trim());
		final int DOCTYPECODE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DOCTYPECODE_POSITION").trim());
		final int LONGURL_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LONGURL_POSITION").trim());
		final int LINEOFBUSINESS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LINEOFBUSINESS_POSITION").trim());
		
		final int FILEID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FILEID_POSITION").trim());
		final int CAMPAIGNID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CAMPAIGNID_POSITION").trim());
		final int EXTERNALID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EXTERNALID_POSITION").trim());
		final int CONTENTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CONTENTID_POSITION").trim());
		final int PARENTMESSAGEID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PARENTMESSAGEID_POSITION").trim());
		final int SUBTOPICID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SUBTOPICID_POSITION").trim());
		final int FOLDERTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FOLDERTYPE_POSITION").trim());
		final int SENDERNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SENDERNAME_POSITION").trim());
		final int RECIPIENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RECIPIENTNAME_POSITION").trim());
		final int DELIVERYSTATUS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DELIVERYSTATUS_POSITION").trim());
		final int FORMFIELDS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FORMFIELDS_POSITION").trim());
		
		final int EFFECTIVEDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EFFECTIVEDATE_POSITION").trim());
		
		final int EXPIRATIONDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EXPIRATIONDATE_POSITION").trim());
		
		final int SENTDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SENTDATE_POSITION").trim());
			
		final int RECEIVEDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RECEIVEDATE_POSITION").trim());
		final int ORIGIN_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ORIGIN_POSITION").trim());
			
		final int EVENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EVENTNAME_POSITION").trim());
		final int REQUESTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "REQUESTID_POSITION").trim());
		final int ALERTSOURCESYSTEM_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ALERTSOURCESYSTEM_POSITION").trim());
		final int VAULTENABLED_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "VAULTENABLED_POSITION").trim());
		final int ORDERNUMBER_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ORDERNUMBER_POSITION").trim());
		final int LOGCHV_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LOGCHV_POSITION").trim());
		/*final int ALERTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ALERTID_POSITION").trim());
		
		final int ALERTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ALERTNAME_POSITION").trim());*/
		final int 	CONTRACTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CONTRACTID_POSITION").trim());
		
		final int 	lANGUAGUEINDICATOR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "lANGUAGUEINDICATOR_POSITION").trim());
		final int 	PBPID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PBPID_POSITION").trim());
		final int 	ACCOUNTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ACCOUNTID_POSITION").trim());
		final int 	GROUPID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "GROUPID_POSITION").trim());
		final int 	CARRIERID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CARRIERID_POSITION").trim());

	
			
		
		String reqString = null;
		String recordType = null;
		
		
		ObjectMapper objectMapper = null;
		EobPaperlessRequest jsonRequest = new EobPaperlessRequest();

		EobPaperlessRequest.RequestPayloadData requestPayloadData = null;

		EobPaperlessRequest.RequestPayloadData.Data data = null;
		

		
		/*
		 * if (null != recordType && recordType.equalsIgnoreCase("T")) {
		 * reqString = "EOF"; } else {
		 */
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		requestPayloadData = new EobPaperlessRequest.RequestPayloadData();
		
		  requestMetaData = new EobPaperlessRequest.RequestMetaData();
		  requestMetaData.setAppName(reqParamArray[APPNAME_POSITION]);
		  requestMetaData.setLineOfBusiness(reqParamArray[
		  LINEOFBUSINESS_POSITION]);
		 
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		data = new EobPaperlessRequest.RequestPayloadData.Data();

		// Populate Data
		data.setAppName(reqParamArray[APPNAME_POSITION].trim());
		data.setMemberID(reqParamArray[MEMBERID_POSITION].trim());
		data.setMemberSource(reqParamArray[MEMBERSOURCE_POSITION].trim());
		data.setClientID(reqParamArray[CLIENTID_POSITION].trim());
		data.setClientCode(reqParamArray[CLIENTCODE_POSITION].trim());
		data.setFirstName(reqParamArray[FIRSTNAME_POSITION].trim());
		data.setCommMsgReqestID(reqParamArray[COMMMSGREQESTID_POSITION].trim());
		data.setCommAlertID(reqParamArray[COMMALERTID_POSITION].trim());
		data.setCommAlertName(reqParamArray[COMMALERTNAME_POSITION].trim());
		data.setCommDeliveryChannel(reqParamArray[COMMDELIVERYCHANNEL_POSITION].trim());
		data.setCommContentType(reqParamArray[COMMCONTENTTYPE_POSITION].trim());
		data.setCommContactInfo(reqParamArray[COMMCONTACTINFO_POSITION].trim());
		data.setCommSenderInfo(reqParamArray[COMMSENDERINFO_POSITION].trim());
		data.setCommSubject(reqParamArray[COMMSUBJECT_POSITION].trim());
		data.setFileID(reqParamArray[FILEID_POSITION].trim());
		data.setCampaignID(reqParamArray[CAMPAIGNID_POSITION].trim());
		data.setClientSet(reqParamArray[CLIENTSET_POSITION].trim());
		data.setLastName(reqParamArray[LASTNAME_POSITION].trim());
		data.setPlanName(reqParamArray[PLANNAME_POSITION].trim());
		data.setDocumentName(reqParamArray[DOCUMENTNAME_POSITION].trim());
		data.setDocTypeCode(reqParamArray[DOCTYPECODE_POSITION].trim());
		data.setLongURL(reqParamArray[LONGURL_POSITION].trim());
		data.setExternalID(reqParamArray[EXTERNALID_POSITION].trim());
		data.setContentID(reqParamArray[CONTENTID_POSITION].trim());
		data.setLob(reqParamArray[LINEOFBUSINESS_POSITION].trim());
		data.setParentMessageID(reqParamArray[PARENTMESSAGEID_POSITION].trim());
		data.setSubTopicID(reqParamArray[SUBTOPICID_POSITION].trim());
		data.setFolderType(reqParamArray[FOLDERTYPE_POSITION].trim());
		data.setSenderName(reqParamArray[SENDERNAME_POSITION].trim());
		data.setRecipientName(reqParamArray[RECIPIENTNAME_POSITION].trim());
		data.setDeliveryStatus(reqParamArray[DELIVERYSTATUS_POSITION].trim());
		data.setFormFields(reqParamArray[FORMFIELDS_POSITION].trim());
		data.setEffectiveDate(reqParamArray[EFFECTIVEDATE_POSITION].trim());
		data.setExpirationDate(reqParamArray[EXPIRATIONDATE_POSITION].trim());
		data.setSentDate(reqParamArray[SENTDATE_POSITION].trim());
		data.setReceivedDate(reqParamArray[RECEIVEDATE_POSITION].trim());
		data.setOrigin(reqParamArray[ORIGIN_POSITION].trim());
		data.setEventName(reqParamArray[EVENTNAME_POSITION].trim());
		data.setAlertSourceSystem(reqParamArray[ALERTSOURCESYSTEM_POSITION].trim());
		data.setRequestId(reqParamArray[REQUESTID_POSITION].trim());
		data.setVaultEnabled(reqParamArray[VAULTENABLED_POSITION].trim());
		data.setOrderNumber(reqParamArray[ORDERNUMBER_POSITION].trim());
		data.setLogCHV(reqParamArray[LOGCHV_POSITION].trim());
		data.setContractID(reqParamArray[CONTRACTID_POSITION].trim());
		data.setLanguageIndicator(reqParamArray[lANGUAGUEINDICATOR_POSITION].trim());
		data.setPbpID(reqParamArray[PBPID_POSITION].trim());
		data.setAccountID(reqParamArray[ACCOUNTID_POSITION].trim());
		data.setGroupID(reqParamArray[GROUPID_POSITION].trim());
		data.setCarrierID(reqParamArray[CARRIERID_POSITION].trim());
		data.setQlBenficieryID(reqParamArray[MEMBERID_POSITION].trim());
		
		
		
		//data.setAlertId(reqParamArray[ALERTID_POSITION].trim());
		//data.setAlertName(reqParamArray[ALERTNAME_POSITION].trim());
		
        
        	 

		requestPayloadData.setData(data);
		jsonRequest.setRequestMetaData(requestMetaData);
		jsonRequest.setRequestPayloadData(requestPayloadData);

		reqString = objectMapper.writeValueAsString(jsonRequest);

	
		return reqString;
	}

}
