package com.cvshealth.dep.etlutils.patientinfonotification;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.cvshealth.dep.etlutils.patientinfonotification.PatientinfoRequest;


import com.cvshealth.dep.etlutils.patientinfonotification.PatientinfoRequest.AdditionalData;
import com.cvshealth.dep.etlutils.patientinfonotification.PatientinfoRequest.Data;
import com.cvshealth.dep.etlutils.patientinfonotification.PatientinfoRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.patientinfonotification.PatientinfoRequest.RequestPayloadData;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
public class PatientinfoRequestBuilder  {
	private static String env;

	


	public String getRequest (String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		final int PROFILEID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "PROFILEID_POSITION");
		final int PATIENTFIRSTNAME_POSITION= Utility.getPropertyInt(folder, 
				finalProduct, "PATIENTFIRSTNAME_POSITION");
		
		
		final String APP_NAME = Utility.getProperty(folder, finalProduct,
				"APP_NAME");
		final String LINE_OF_BUSINESS = Utility.getProperty(folder,
				finalProduct, "LINE_OF_BUSINESS");
		final String OPERATION_NAME = Utility.getProperty(folder,
				finalProduct, "OPERATION_NAME");
		final int CHANNELID_POSITION = Utility.getPropertyInt(folder, 
				finalProduct ,"CHANNELID_POSITION");
		final int DEVICETYPE_POSITION =Utility.getPropertyInt(folder, 
				finalProduct , "DEVICETYPE_POSITION");
		
		// Populate AdditionalData model
		AdditionalData additionalData = new AdditionalData();
		additionalData.setProfileId(reqParamArray[PROFILEID_POSITION].trim());
		additionalData.setPatientFirstName(reqParamArray[PATIENTFIRSTNAME_POSITION].trim());
		
		
		// Populate Data model
		Data data = new Data();
	   data.setMemberID(additionalData.getProfileId());
	   data.setChannelID(reqParamArray[CHANNELID_POSITION].trim());
	   data.setDeviceType(reqParamArray[DEVICETYPE_POSITION].trim());
	
		// Populate RequestPayloadData
		RequestPayloadData requestPayloadData = new RequestPayloadData();
		requestPayloadData.setData(data);

		requestPayloadData.setAdditionalData(additionalData);

		// Populate RequestMetaData
		RequestMetaData requestMetaData = new RequestMetaData();
		requestMetaData.setAppName(APP_NAME);
		requestMetaData.setLineOfBusiness(LINE_OF_BUSINESS);
		requestMetaData.setOperationName(OPERATION_NAME);
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		// Populate UspsRequest
	PatientinfoRequest patientinfoRequest = new PatientinfoRequest();
	patientinfoRequest.setRequestMetaData(requestMetaData);
	patientinfoRequest.setRequestPayloadData(requestPayloadData);

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		return objectMapper.writeValueAsString(patientinfoRequest);
	}

	

}
