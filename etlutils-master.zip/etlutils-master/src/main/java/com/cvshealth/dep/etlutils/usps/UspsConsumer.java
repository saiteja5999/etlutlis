package com.cvshealth.dep.etlutils.usps;

import java.io.FileWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import javax.rmi.CORBA.Util;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.cvshealth.dep.etlutils.utils.ServiceClient;
import com.cvshealth.dep.etlutils.utils.Utility;




/**
 * UspsConsumer is used to handle build Usps Messages and assembly the data
 * together
 *
 * @author CVSHealth
 */
public class UspsConsumer implements Runnable {
	private static final String APP_NAME = null;
	private static final String START_TIME = null;
	private static String FAILEDRECORDS = null;
	private final Logger infoLogger = Logger.getLogger("uspsinfo");
	private final Logger errorLogger = Logger.getLogger("uspserror");
	private final String PRODUCT = "usps";
	private BlockingQueue<String> _Queue;
	private String finalProduct;
	protected UspsRequestBuilder _RequestBuilder;
	private String nodeJsUrl;
	private String fieldDelimiter;
	private ZipcodeUtil _ZipcodeUtil;
	static Utility util = Utility.getInstance();
	String logUri;

	public UspsConsumer(BlockingQueue<String> q, String env) throws Exception {
		this._Queue = q;
		this.finalProduct = PRODUCT + "_" + env;
		this.nodeJsUrl = Utility.getProperty(PRODUCT, finalProduct,
				"nodejs.uri");
		this.FAILEDRECORDS = Utility.getProperty(PRODUCT,
				finalProduct, "FAILEDRECORDS");
		this.fieldDelimiter = Utility.getProperty(PRODUCT, finalProduct,
				"field.delimiter");
		this.logUri = Utility.getProperty(PRODUCT, finalProduct, "logger.uri");
		_ZipcodeUtil = new ZipcodeUtil(env);
	}

	@Override
	public void run() {
		String record = "";
		try {
			String msg;
			while (true) {
				msg = _Queue.poll(5, TimeUnit.SECONDS);
				if (msg == null) {
					break;
				}
		          record = msg;
				// System.out.println(msg);

				if (msg.startsWith("\"")) {
					msg = msg.substring(1);
				}
				if (msg.endsWith("\"")) {
					msg = msg.substring(0, msg.length() - 1);
				}

				try {
					Date startDate = new Date();
					String[] reqParamArray = msg.split(fieldDelimiter, -1);
					_RequestBuilder = new UspsRequestBuilder(_ZipcodeUtil);
					String reqString = _RequestBuilder.getRequest(
							reqParamArray, finalProduct, PRODUCT);
					// System.out.println("nodejsUri=" + nodejsUri);
					// System.out.println("etlPayload=" + reqString);
					infoLogger.info(reqString);

					String logMsg = "uspspayload=" + reqString;

					util.log(APP_NAME, logUri, "0000", "Success", logMsg,
							startDate, "");
					Map<String, Object> headers = new HashMap<String, Object>();
					headers.put("content-type", "application/json");
					String uspsresult = ServiceClient.postDataWithHeadersNodejs(
							nodeJsUrl, reqString, headers);
					infoLogger.info(uspsresult);
					logMsg = uspsresult;
					util.log(APP_NAME, logUri, "0000", "Success", logMsg,
							startDate, "");
					JSONObject json = new JSONObject(uspsresult);
				String statusDesc=	json.getJSONObject("responseMetaData").getString("statusDesc");
					//String statusDesc = json.getString("responseMetaData");
					
					infoLogger.info("************************************************"+statusDesc);
					if (!(statusDesc).equals("Success")) {
						appendToFile(record + "|" + statusDesc);
						// appendToFile(result);
						infoLogger
								.info("please check the file for failed records ");
					}

				} catch (Exception e) {
					e.printStackTrace();
					infoLogger
							.info("UspsProcessor | service.execute() | Error while converting record into KafkaRequest"
								+record	+ e.getMessage());
					errorLogger.error(Utility.getStrackTrace(e)+record);
					appendToFile(record + "||" + e);
				}
			}
			System.out.println("Consumer STOPPED.");
		} catch (Exception e ) {
			e.printStackTrace();
			infoLogger
					.info("UspsProcessor | processRecords() | Error in processing records | "
						+	record+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e)+record);
			appendToFile(record + "||" + e);
		}
	}
	public static void appendToFile(String records) {

		try {
			String cDate = System.getProperty("current.date.time");
			String newLine = "\n";

			FileWriter file = new FileWriter(FAILEDRECORDS + "uspsfailedrecords"
					+ cDate + ".txt", true);

			file.write(records.toString() + newLine);
			// file.write(records.toString());
			file.close();

		} catch (Exception ie) {
			throw new RuntimeException("Could not write Exception to file", ie);
		}
	}
}
