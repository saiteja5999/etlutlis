package com.cvshealth.dep.etlutils.extracare.coupon.esp;

import java.io.Serializable;
import java.util.List;

public class CouponRequest implements Serializable {
	private static final long serialVersionUID = -3241212568743708851L;

	private String extraCareCard = "";
	private String referrer_cd = "";
	private List<ViewList> viewList;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CouponJSONRequest [extraCareCard=" + extraCareCard
				+ ", referrer_cd=" + referrer_cd + ", viewList=" + viewList
				+ "]";
	}

	public String getExtraCareCard() {
		return extraCareCard;
	}

	public void setExtraCareCard(String extraCareCard) {
		this.extraCareCard = extraCareCard;
	}

	public String getReferrer_cd() {
		return referrer_cd;
	}

	public void setReferrer_cd(String referrer_cd) {
		this.referrer_cd = referrer_cd;
	}

	public List<ViewList> getViewList() {
		return viewList;
	}

	public void setViewList(List<ViewList> viewList) {
		this.viewList = viewList;
	}

	/**
	 * @return the requestMetaData
	 */
	/**
	 * ViewList
	 * 
	 * @author CVSHealth
	 */
	public static class ViewList {
		private String cpnSeqNbr = "";
		private String ts = "";

		public String getCpnSeqNbr() {
			return cpnSeqNbr;
		}

		public void setCpnSeqNbr(String cpnSeqNbr) {
			this.cpnSeqNbr = cpnSeqNbr;
		}

		public String getTs() {
			return ts;
		}

		public void setTs(String ts) {
			this.ts = ts;
		}

	}
}
