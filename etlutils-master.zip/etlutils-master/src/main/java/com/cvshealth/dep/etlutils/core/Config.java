package com.cvshealth.dep.etlutils.core;

import java.util.ArrayList;
import java.util.List;

public class Config {
	int recordsPerBatch = 10;
	String appName = null;
	String delimiter = "|";
	String kafkaUri = null;
	String kafkaServers = null;
	String kafkaAuthkey = null;
	List<ConfigNode> configNodeList = new ArrayList<ConfigNode>();

	public int getRecordsPerBatch() {
		return recordsPerBatch;
	}

	public void setRecordsPerBatch(int recordsPerBatch) {
		this.recordsPerBatch = recordsPerBatch;
	}

	public String getKafkaUri() {
		return kafkaUri;
	}

	public void setKafkaUri(String kafkaUri) {
		this.kafkaUri = kafkaUri;
	}

	public String getKafkaServers() {
		return kafkaServers;
	}

	public void setKafkaServers(String kafkaServers) {
		this.kafkaServers = kafkaServers;
	}

	public String getKafkaAuthkey() {
		return kafkaAuthkey;
	}

	public void setKafkaAuthkey(String kafkaAuthkey) {
		this.kafkaAuthkey = kafkaAuthkey;
	}

	public List<ConfigNode> getConfigNodeList() {
		return configNodeList;
	}

	public void setConfigNodeList(List<ConfigNode> configNodeList) {
		this.configNodeList = configNodeList;
	}

	public String getDelimiter() {
		return delimiter;
	}

	public void setDelimiter(String delimiter) {
		this.delimiter = delimiter;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	@Override
	public String toString() {
		return "Config [recordsPerBatch=" + recordsPerBatch + ", appName="
				+ appName + ", delimiter=" + delimiter + ", kafkaUri="
				+ kafkaUri + ", kafkaServers=" + kafkaServers
				+ ", kafkaAuthkey=" + kafkaAuthkey + ", configNodeList="
				+ configNodeList + "]";
	}

}
