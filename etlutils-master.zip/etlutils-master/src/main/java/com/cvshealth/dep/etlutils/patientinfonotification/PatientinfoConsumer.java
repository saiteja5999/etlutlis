package com.cvshealth.dep.etlutils.patientinfonotification;

import java.io.FileWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.cvshealth.dep.etlutils.utils.ServiceClient;
import com.cvshealth.dep.etlutils.utils.Utility;

public class PatientinfoConsumer implements Runnable {
	private final static Logger infoLogger = Logger.getLogger("patientinfo");
	private final Logger errorLogger = Logger.getLogger("patienterror");
	private BlockingQueue<String> _Queue;
	private String finalProduct;
	protected PatientinfoRequestBuilder _RequestBuilder;
	private String uri;
	private String logUri;
	private String fieldDelimiter;
	private static String FAILEDRECORDS;
	List<String> failRecords;

	public PatientinfoConsumer(BlockingQueue<String> q, String env)
			throws Exception {
		this._Queue = q;

		this.finalProduct = PatientinfoMain.PRODUCT + "_" + env;
		this.uri = Utility.getProperty(PatientinfoMain.PRODUCT, finalProduct,
				"nodejs.uri");

		this.FAILEDRECORDS = Utility.getProperty(PatientinfoMain.PRODUCT,
				finalProduct, "FAILEDRECORDS");
		this.logUri = Utility.getProperty(PatientinfoMain.PRODUCT,
				finalProduct, "logger.uri");
		this.fieldDelimiter = Utility.getProperty(PatientinfoMain.PRODUCT,
				finalProduct, "field.delimiter");
	}

	/*
	 * (non-Javadoc) Thread
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		String record = "";
		try {
			String msg;

			while (true) {
				msg = _Queue.poll(5, TimeUnit.SECONDS);
				if (msg == null) {
					break;
				}
				record = msg;

				if (msg.startsWith(fieldDelimiter)) {
					msg = msg.substring(1);
				}
				if (msg.endsWith(fieldDelimiter)) {
					msg = msg.substring(0, msg.length() - 1);
				}
				/*
				 * We are buliding the request body and passing to the URL
				 */
				try {
					String[] reqParamArray = msg.split(fieldDelimiter, -1);

					_RequestBuilder = new PatientinfoRequestBuilder();

					String reqString = _RequestBuilder.getRequest(
							reqParamArray, finalProduct,
							PatientinfoMain.PRODUCT);
					System.out.println("PatientinfoRequest=" + reqString);
					Map<String, Object> headers = new HashMap<String, Object>();
					headers.put("content-type", "application/json");
					headers.put("Accept", "application/json");

					String result = ServiceClient.postDataWithHeadersNodejs(
							uri, reqString, headers);

					infoLogger.debug(result);
					System.out.println("PatientinfoResponse=" + result);
					JSONObject json = new JSONObject(result);
					String statusDesc = json.getJSONObject("responseMetaData")
							.getString("statusDesc");

					if (!(statusDesc).equals("Success")) {
						appendToFile(record + "|" + statusDesc);
						// appendToFile(result);
						infoLogger
								.info("please check the file for failed records ");
					}

				} catch (Exception e) {
					e.printStackTrace();
					infoLogger
							.info("PatientinfoProcessor | service.execute() | Error while converting record into KafkaRequest"
									+ e.getMessage() + record);

					errorLogger.error(Utility.getStrackTrace(e) + record);
					appendToFile(record + "||" + e);

				}
			}
			System.out.println("Consumer STOPPED.");
		} catch (Exception e) {
			e.printStackTrace();

			infoLogger
					.info("PatientinfoProcessor | processRecords() | Error in processing records | "
							+ record + e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e) + record);
			appendToFile(record + "||" + e);
		}
	}

	public static void appendToFile(String records) {

		try {
			String cDate = System.getProperty("current.date.time");
			String newLine = "\n";

			FileWriter file = new FileWriter(FAILEDRECORDS
					+ "patientinforecords" + cDate + ".txt", true);

			file.write(records.toString() + newLine);
			// file.write(records.toString());
			file.close();

		} catch (Exception ie) {
			throw new RuntimeException("Could not write Exception to file", ie);
		}

	}
}
