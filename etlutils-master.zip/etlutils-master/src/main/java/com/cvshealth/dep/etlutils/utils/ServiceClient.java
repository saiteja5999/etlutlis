package com.cvshealth.dep.etlutils.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;

import com.cvshealth.dep.etlutils.utils.Service.Error;
import com.cvshealth.dep.etlutils.utils.Service.LogRequest;
import com.cvshealth.dep.etlutils.utils.Service.RequestMetaData;
import com.cvshealth.dep.etlutils.utils.Service.RequestPayloadData;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class ServiceClient {

	private static final String SERVICE = "javaapps";
	static HttpPost httpPost = null;

	/**
	 * @param uri
	 * @param body
	 * @param headers
	 * @return
	 * @throws Exception
	 * @throws IOException
	 * @throws ClientProtocolException
	 */
	public static String postDataWithHeaders(String uri, String body,
			Map<String, Object> headers) throws ClientProtocolException,
			IOException, Exception {
		String out = null;
		StringBuilder response = null;
		BufferedReader reader = null;
		StringEntity entity = null;
		// HttpPost httpPost = null;
		HttpResponse httpResponse = null;
		// try {
		httpPost = new HttpPost(uri);

		int hardTimeout = 180; // seconds
		TimerTask task = new TimerTask() {
			@Override
			public void run() {
				if (httpPost != null) {
					httpPost.abort();
				}
			}
		};
		new Timer(true).schedule(task, hardTimeout * 1000);

		entity = new StringEntity(body);
		// entity.setContentType("application/json");

		httpPost.setEntity(entity);
		if (null != headers) {
			for (Map.Entry<String, Object> entry : headers.entrySet()) {
				httpPost.setHeader(entry.getKey(), (String) entry.getValue());
			}
		}
		httpResponse = HttpClientFactory.getHttpsClient().execute(httpPost);
		System.out.println("HTTP Status of response: "
				+ httpResponse.getStatusLine().getStatusCode());

		reader = new BufferedReader(new InputStreamReader(httpResponse
				.getEntity().getContent()));
		response = new StringBuilder();

		while ((out = reader.readLine()) != null) {
			response.append(out);
		}
		/*
		 * } catch (Exception e) { eccmLogger.error("Error in service call :" +
		 * uri + e); response = new StringBuilder(
		 * "{\"responseMetaData\" : {\"statusCode\" : \"9999\", \"statusDesc\" : \""
		 * + e.getMessage() + "\"}}"); }
		 */
		String responseString = null;
		if (null != response) {
			responseString = response.toString();
		}
		return responseString;
	}

	public static String postDataWithHeadersNodejs(String uri, String body,
			Map<String, Object> headers) throws ClientProtocolException,
			IOException, Exception {
		String out = null;
		StringBuilder response = null;
		BufferedReader reader = null;
		StringEntity entity = null;
		HttpPost httpPost = null;
		HttpResponse httpResponse = null;

		httpPost = new HttpPost(uri);

		entity = new StringEntity(body);
		// entity.setContentType("application/json");

		httpPost.setEntity(entity);
		if (null != headers) {
			for (Map.Entry<String, Object> entry : headers.entrySet()) {
				httpPost.setHeader(entry.getKey(), (String) entry.getValue());
			}
		}
		httpResponse = HttpClientFactoryNodejs.getHttpsClient().execute(
				httpPost);

		reader = new BufferedReader(new InputStreamReader(httpResponse
				.getEntity().getContent()));
		response = new StringBuilder();

		while ((out = reader.readLine()) != null) {
			response.append(out);
		}
		String responseString = null;
		if (null != response) {
			responseString = response.toString();
		}
		return responseString;
	}

	
	
	public static String logToSplunk(String operation, String uri,
			String conversationId, String statusCode, String statusDesc,
			String httpStatusCode, String requestTimeStamp, String request,
			String response, String responseTimeStamp, String error)
			throws ClientProtocolException, IOException, Exception {

		Map<String, Object> headers = new HashMap<String, Object>();
		headers.put("content-type", "application/json");
		String body = _getBody(operation, conversationId, statusCode,
				statusDesc, httpStatusCode, requestTimeStamp, request,
				response, responseTimeStamp, error);
		String logResult = postDataWithHeadersNodejs(uri, body, headers);
		// System.out.println("logResult=" + logResult);
		return logResult;
	}

	private static String _getBody(String operation, String conversationId,
			String statusCode, String statusDesc, String httpStatusCode,
			String requestTimeStamp, String request, String response,
			String responseTimeStamp, String error)
			throws JsonProcessingException {
		LogRequest logReq = new LogRequest();

		RequestMetaData requestMetaData = new RequestMetaData();
		requestMetaData.setConversationId(conversationId);

		RequestPayloadData requestPayloadData = new RequestPayloadData();
		requestPayloadData.setService(SERVICE);
		requestPayloadData.setOperation(operation);
		requestPayloadData.setStatusCode(statusCode);
		requestPayloadData.setStatusDesc(statusDesc);
		requestPayloadData.setHttpStatusCode(httpStatusCode);
		requestPayloadData.setRequestTimeStamp(requestTimeStamp);
		requestPayloadData.setRequest(request);
		requestPayloadData.setResponse(response);
		requestPayloadData.setResponseTimeStamp(responseTimeStamp);
		requestPayloadData.setError(new Error(error));

		logReq.setRequestMetaData(requestMetaData);
		logReq.setRequestPayloadData(requestPayloadData);
		return new ObjectMapper().writeValueAsString(logReq);

	}

}
