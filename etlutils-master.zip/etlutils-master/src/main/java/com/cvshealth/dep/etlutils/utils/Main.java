package com.cvshealth.dep.etlutils.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {
	static {
		System.setProperty("current.date",
				new SimpleDateFormat("MMddyyyy").format(new Date()));
		System.setProperty("current.date.time", new SimpleDateFormat(
				"yyyyMMdd_HHmmss").format(new Date()));
	}
}
