package com.cvshealth.dep.etlutils.common;

public interface RequestBuilder {

	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception;

}
