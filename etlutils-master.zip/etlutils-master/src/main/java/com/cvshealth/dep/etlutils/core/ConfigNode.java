package com.cvshealth.dep.etlutils.core;

import com.fasterxml.jackson.databind.JsonNode;

public class ConfigNode {
	int colNumber;
	String colName;
	String type;
	String defaultValue;
	JsonNode configNodeList;
	
	public int getColNumber() {
		return colNumber;
	}
	public void setColNumber(int colNumber) {
		this.colNumber = colNumber;
	}
	public String getColName() {
		return colName;
	}
	public void setColName(String colName) {
		this.colName = colName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public JsonNode getConfigNodeList() {
		return configNodeList;
	}
	public void setConfigNodeList(JsonNode configNodeList) {
		this.configNodeList = configNodeList;
	}

	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	
	@Override
	public String toString() {
		return "ConfigNode [colNumber=" + colNumber + ", colName=" + colName
				+ ", type=" + type + ", defaultValue=" + defaultValue
				+ ", configNodeList=" + configNodeList + "]";
	}
		
}
