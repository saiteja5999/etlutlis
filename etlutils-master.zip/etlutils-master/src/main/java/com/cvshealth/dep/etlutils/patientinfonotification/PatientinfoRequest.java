package com.cvshealth.dep.etlutils.patientinfonotification;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;


public class PatientinfoRequest implements Serializable {

	private static final long serialVersionUID = -4187537354799171017L;

	private PatientinfoRequest.RequestMetaData requestMetaData = null;
	private PatientinfoRequest.RequestPayloadData requestPayloadData = null;

	@Override
	public String toString() {
		return "PatientinfoRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}

	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	public PatientinfoRequest.RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}

	public void setRequestPayloadData(
			PatientinfoRequest.RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}

	static class Data {

		private String eventName = "PHR_Notification_ETL";
		private String memberID = null;
		private String memberType = "CVSProfile";
		private String channelID = null;
		private String deviceType = null;

		public String getEventName() {
			return eventName;
		}

	
		public String getMemberID() {
			return memberID;
		}

		public void setMemberID(String memberID) {
			this.memberID = memberID;
		}

		public String getMemberType() {
			return memberType;
		}

		public void setMemberType(String memberType) {
			this.memberType = memberType;
		}
		public String getChannelID() {
			return channelID;
		}
		public void setChannelID(String channelID){
			this.channelID = channelID;
		}
		public String DeviceType() {
			return deviceType;
		}
		public void setDeviceType(String deviceType){
			this.deviceType = deviceType;
		}

		@Override
		public String toString() {
			return "Data [  eventName=" + eventName
					 + ", memberID=" + memberID + ", memberType="
				+ memberType +", channelID="+channelID+",deviceType="+deviceType+"]";
		}
	}

	static class AdditionalData {
		private String profileId = null;
		private String PatientFirstName = null;
		public String getProfileId() {
			return profileId;
		}
		public void setProfileId(String profileId) {
			this.profileId = profileId;
		}
		@JsonProperty("PatientFirstName")
		public String getPatientFirstName() {
			return PatientFirstName;
		}
		public void setPatientFirstName(String patientFirstName) {
			PatientFirstName = patientFirstName;
		}
		
		@Override
		public String toString() {
			return "AdditionalData [profileId=" + profileId
					+ ", PatientFirstName=" + PatientFirstName
					 + "]";
		}
		
	}

	static class RequestPayloadData {
		private Data data = null;
		private AdditionalData additionalData = null;

		public Data getData() {
			return data;
		}

		public void setData(Data data) {
			this.data = data;
		}

		public AdditionalData getAdditionalData() {
			return additionalData;
		}

		public void setAdditionalData(AdditionalData additionalData) {
			this.additionalData = additionalData;
		}

	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */
	static class RequestMetaData {
		private String appName = null;
		private String lineOfBusiness = null;
		private String conversationID = null;
		private String operationName =null; 
		
		public String getOperationName(){
			return operationName;
			
		}
		public void setOperationName (String operationName) {
			
			
	     this.operationName = operationName;
		}

		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		public String getConversationID() {
			return conversationID;
		}

		public void setConversationID(String conversationID) {
			this.conversationID = conversationID;
		}

		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", conversationID=" + conversationID +", operationName="+operationName
					+ "]";
		}

	}
}