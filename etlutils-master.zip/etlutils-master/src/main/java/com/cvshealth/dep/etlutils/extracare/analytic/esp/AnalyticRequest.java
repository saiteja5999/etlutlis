package com.cvshealth.dep.etlutils.extracare.analytic.esp;

import java.io.Serializable;
import java.util.List;

public class AnalyticRequest implements Serializable {
	private static final long serialVersionUID = -3241212568743708851L;

	private Integer analytic_event_type_cd;
	private String ts = "";
	private Analytic_event_data analytic_event_data;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "AnalyticJSONRequest [analytic_event_type_cd="
				+ analytic_event_type_cd + ", timestamp=" + ts
				+ ", analytic_event_data=" + analytic_event_data + "]";
	}

	public Integer getAnalytic_event_type_cd() {
		return analytic_event_type_cd;
	}

	public void setAnalytic_event_type_cd(Integer analytic_event_type_cd) {
		this.analytic_event_type_cd = analytic_event_type_cd;
	}

	public String getTs() {
		return ts;
	}

	public void setTs(String ts) {
		this.ts = ts;
	}

	public Analytic_event_data getAnalytic_event_data() {
		return analytic_event_data;
	}

	public void setAnalytic_event_data(Analytic_event_data analytic_event_data) {
		this.analytic_event_data = analytic_event_data;
	}

	/**
	 * @return the requestMetaData
	 */
	/**
	 * ViewList
	 * 
	 * @author CVSHealth
	 */
	public static class Analytic_event_data {
		private String recpt_rqst_seq_nbr = "";

		public String getRecpt_rqst_seq_nbr() {
			return recpt_rqst_seq_nbr;
		}

		public void setRecpt_rqst_seq_nbr(String recpt_rqst_seq_nbr) {
			this.recpt_rqst_seq_nbr = recpt_rqst_seq_nbr;
		}

	}
}
