package com.cvshealth.dep.etlutils.securechat;

import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.utils.Utility;
import java.util.Date;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

public class SecurechatProcessor implements Processor {
	private static final String APP_NAME = "securechatetlutils";
	private final Logger infoLogger = Logger.getLogger("securechatinfo");
	private final Logger errorLogger = Logger.getLogger("securechaterror");
	private final int BOUND = 100;
	private BlockingQueue<String> _SecurechatQueue;
	private String _env;
	private int WorkerNumber = 2;
	static Utility util;
	private String finalProduct;

	String logUri = null;

	protected SecurechatProcessor(String env, int workerNumber)
			throws Exception {
		this.WorkerNumber = workerNumber;
		this._env = env;
		this.finalProduct = ("securechat_" + env);

		this.logUri = Utility.getProperty("securechat", this.finalProduct,
				"logger.uri");

		this._SecurechatQueue = new LinkedBlockingQueue<>(BOUND);
	}

	public void close() {
	}

	public void processRecords(List<String> records) {
		int availCores = Utility.getAvailableCores();
		ExecutorService service = Executors.newFixedThreadPool(availCores);

		SecurechatProducer producer = new SecurechatProducer(
				this._SecurechatQueue, records);

		service.submit(producer);
		try {
			for (int i = 1; i < this.WorkerNumber; i++) {
				System.out.println(this._SecurechatQueue);
				SecurechatConsumer consumer = new SecurechatConsumer(
						this._SecurechatQueue, this._env);

				service.submit(consumer);
			}
		} catch (Exception e) {
			e.printStackTrace();
			infoLogger
					.info("SecurechatProcessor | processRecords() | Error in processing records | "
							+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e));

		} finally {
			if (null != service) {
				service.shutdown();
				try {
					service.awaitTermination(30L, TimeUnit.MINUTES);
				} catch (Exception e) {
					this.errorLogger.error(Utility.getStrackTrace(e));
					util.log(APP_NAME, logUri, "9999", "Error", "Job failed",
							new Date(), Utility.getStrackTrace(e));
				}
			}
		}

	}
}