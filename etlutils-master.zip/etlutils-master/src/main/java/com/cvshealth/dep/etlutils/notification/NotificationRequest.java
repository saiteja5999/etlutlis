package com.cvshealth.dep.etlutils.notification;

import java.io.Serializable;
import java.util.List;

import org.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Notification Service JSON request Model
 * 
 * @author CVSHealth
 */
public class NotificationRequest implements Serializable {

	private static final long serialVersionUID = -4187537354799171017L;

	private NotificationRequest.RequestMetaData requestMetaData = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "NotificationRequest [requestMetaData=" + requestMetaData + "]";
	}

	/**
	 * @return the requestMetaData
	 */
	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	/**
	 * @param requestMetaData
	 *            the requestMetaData to set
	 */
	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	/**
	 * DeviceData
	 * 
	 * @author CVSHealth
	 */
	static class DeviceData {
		private String channelType = "";
		private String channelID = "";
		private String contentID = "";
		private String contentType = "";
		private String deviceType = "";
		private String memberID = "";
		private String memberType = "";
		private String campaignID = "";
		private String opportunityID = "";
		private String action = "";
		private String CNID = "";

		/**
		 * @return the channelType
		 */
		public String getChannelType() {
			return channelType;
		}

		/**
		 * @param channelType
		 *            the channelType to set
		 */
		public void setChannelType(String channelType) {
			this.channelType = channelType;
		}

		/**
		 * @return the channelID
		 */
		public String getChannelID() {
			return channelID;
		}

		/**
		 * @param channelID
		 *            the channelID to set
		 */
		public void setChannelID(String channelID) {
			this.channelID = channelID;
		}

		/**
		 * @return the contentID
		 */
		public String getContentID() {
			return contentID;
		}

		/**
		 * @param contentID
		 *            the contentID to set
		 */
		public void setContentID(String contentID) {
			this.contentID = contentID;
		}

		/**
		 * @return the contentType
		 */
		public String getContentType() {
			return contentType;
		}

		/**
		 * @param contentType
		 *            the contentType to set
		 */
		public void setContentType(String contentType) {
			this.contentType = contentType;
		}

		/**
		 * @return the deviceType
		 */
		public String getDeviceType() {
			return deviceType;
		}

		/**
		 * @param deviceType
		 *            the deviceType to set
		 */
		public void setDeviceType(String deviceType) {
			this.deviceType = deviceType;
		}

		/**
		 * @return the memberID
		 */
		public String getMemberID() {
			return memberID;
		}

		/**
		 * @param memberID
		 *            the memberID to set
		 */
		public void setMemberID(String memberID) {
			this.memberID = memberID;
		}

		/**
		 * @return the memberType
		 */
		public String getMemberType() {
			return memberType;
		}

		/**
		 * @param memberType
		 *            the memberType to set
		 */
		public void setMemberType(String memberType) {
			this.memberType = memberType;
		}

		/**
		 * @return the campaignID
		 */
		public String getCampaignID() {
			return campaignID;
		}

		/**
		 * @param campaignID
		 *            the campaignID to set
		 */
		public void setCampaignID(String campaignID) {
			this.campaignID = campaignID;
		}

		/**
		 * @return the opportunityID
		 */
		public String getOpportunityID() {
			return opportunityID;
		}

		/**
		 * @param opportunityID
		 *            the opportunityID to set
		 */
		public void setOpportunityID(String opportunityID) {
			this.opportunityID = opportunityID;
		}

		/**
		 * @return the action
		 */
		public String getAction() {
			return action;
		}

		/**
		 * @param action
		 *            the action to set
		 */
		public void setAction(String action) {
			this.action = action;
		}

		/**
		 * @return the cNID
		 */
		public String getCNID() {
			return CNID;
		}

		/**
		 * @param cNID
		 *            the cNID to set
		 */
		@JsonProperty("CNID")
		public void setCNID(String cNID) {
			CNID = cNID;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "DeviceData [channelType=" + channelType + ", channelID="
					+ channelID + ", contentID=" + contentID + ", contentType="
					+ contentType + ", deviceType=" + deviceType
					+ ", memberID=" + memberID + ", memberType=" + memberType
					+ ", campaignID=" + campaignID + ", opportunityID="
					+ opportunityID + ", action=" + action + ", CNID=" + CNID
					+ "]";
		}
	}

	/**
	 * KeyValue
	 * 
	 * @author CVSHealth
	 */
	static class KeyValue {
		private String key = "";
		private String value = "";

		/**
		 * @return the key
		 */
		public String getKey() {
			return key;
		}

		/**
		 * @param key
		 *            the key to set
		 */
		public void setKey(String key) {
			this.key = key;
		}

		/**
		 * @return the value
		 */
		public String getValue() {
			return value;
		}

		/**
		 * @param value
		 *            the value to set
		 */
		public void setValue(String value) {
			this.value = value;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "KeyValue [key=" + key + ", value=" + value + "]";
		}
	}

	/**
	 * MessageData
	 * 
	 * @author CVSHealth
	 */
	static class MessageData {
		private String from = "";
		private String subject = "";
		private String body = "";
		private String attachment = "";
		private List<KeyValue> keyValueList = null;

		/**
		 * @return the from
		 */
		public String getFrom() {
			return from;
		}

		/**
		 * @param from
		 *            the from to set
		 */
		@JsonProperty("From")
		public void setFrom(String from) {
			this.from = from;
		}

		/**
		 * @return the subject
		 */
		public String getSubject() {
			return subject;
		}

		/**
		 * @param subject
		 *            the subject to set
		 */
		@JsonProperty("Subject")
		public void setSubject(String subject) {
			this.subject = subject;
		}

		/**
		 * @return the body
		 */
		public String getBody() {
			return body;
		}

		/**
		 * @param body
		 *            the body to set
		 */
		@JsonProperty("Body")
		public void setBody(String body) {
			this.body = body;
		}

		/**
		 * @return the attachments
		 */
		public String getAttachment() {
			return attachment;
		}

		/**
		 * @param attachments
		 *            the attachments to set
		 */
		public void setAttachment(String attachment) {
			this.attachment = attachment;
		}

		/**
		 * @return the keyValueList
		 */
		public List<KeyValue> getKeyValueList() {
			return keyValueList;
		}

		/**
		 * @param keyValueList
		 *            the keyValueList to set
		 */
		public void setKeyValueList(List<KeyValue> keyValueList) {
			this.keyValueList = keyValueList;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "MessageData [from=" + from + ", subject=" + subject
					+ ", body=" + body + ", attachment=" + attachment
					+ ", keyValueList=" + keyValueList + "]";
		}
	}

	/**
	 * RequestPayloadData
	 * 
	 * @author CVSHealth
	 */
	static class RequestPayloadData {
		private DeviceData deviceData = null;
		private MessageData messageData = null;
		private JSONObject additionalData = null;

		/**
		 * @return the deviceData
		 */
		public DeviceData getDeviceData() {
			return deviceData;
		}

		/**
		 * @param deviceData
		 *            the deviceData to set
		 */
		public void setDeviceData(DeviceData deviceData) {
			this.deviceData = deviceData;
		}

		/**
		 * @return the messageData
		 */
		public MessageData getMessageData() {
			return messageData;
		}

		/**
		 * @param messageData
		 *            the messageData to set
		 */
		public void setMessageData(MessageData messageData) {
			this.messageData = messageData;
		}

		/**
		 * @return the additionalData
		 */
		public JSONObject getAdditionalData() {
			return additionalData;
		}

		/**
		 * @param additionalData
		 *            the additionalData to set
		 */
		public void setAdditionalData(JSONObject additionalData) {
			this.additionalData = additionalData;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestPayloadData [deviceData=" + deviceData
					+ ", messageData=" + messageData + ", additionalData="
					+ additionalData + "]";
		}
	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */
	static class RequestMetaData {
		private String appName = null;
		private String lineOfBusiness = null;
		private String programName = null;
		private String grid = null;
		private RequestPayloadData requestPayloadData = null;

		/**
		 * @return the appName
		 */
		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		/**
		 * @return the programName
		 */
		public String getProgramName() {
			return programName;
		}

		/**
		 * @param programName
		 *            the programName to set
		 */
		public void setProgramName(String programName) {
			this.programName = programName;
		}

		/**
		 * @return the grid
		 */
		public String getGrid() {
			return grid;
		}

		/**
		 * @param grid
		 *            the grid to set
		 */
		@JsonProperty("GRID")
		public void setGrid(String grid) {
			this.grid = grid;
		}

		/**
		 * @return the requestPayloadData
		 */
		public RequestPayloadData getRequestPayloadData() {
			return requestPayloadData;
		}

		/**
		 * @param requestPayloadData
		 *            the requestPayloadData to set
		 */
		public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
			this.requestPayloadData = requestPayloadData;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", programName=" + programName
					+ ", grid=" + grid + ", requestPayloadData="
					+ requestPayloadData + "]";
		}
	}
}