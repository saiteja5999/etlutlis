package com.cvshealth.dep.etlutils.echc;

import java.util.UUID;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.echc.EchcRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.ObjectMapper;

public class EchcRequestBuilder implements RequestBuilder {
	private RequestMetaData requestMetaData;

	public EchcRequestBuilder(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	
	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		

		 final int APPNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "APPNAME_POSITION").trim());
		
		final int MEMBERID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERID_POSITION").trim());
		final int MEMBERSOURCE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERSOURCE_POSITION").trim());
		final int CLIENTID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CLIENTID_POSITION").trim());
		final int CLIENTCODE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CLIENTCODE_POSITION").trim());
		final int FIRSTNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "FIRSTNAME_POSITION").trim());
		final int COMMMSGREQESTID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMMSGREQESTID_POSITION").trim());
		final int COMMALERTID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMALERTID_POSITION").trim());
		final int COMMALERTNAME_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMALERTNAME_POSITION").trim());
		final int COMMDELIVERYCHANNEL_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMDELIVERYCHANNEL_POSITION").trim());
		final int COMMCONTENTTYPE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMCONTENTTYPE_POSITION").trim());
		final int COMMCONTACTINFO_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMCONTACTINFO_POSITION").trim());
		final int COMMSENDERINFO_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMSENDERINFO_POSITION").trim());
		final int COMMSUBJECT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMSUBJECT_POSITION").trim());
		final int CLIENTSET_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CLIENTSET_POSITION").trim());
		
		final int LASTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LASTNAME_POSITION").trim());
		final int PLANNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PLANNAME_POSITION").trim());
		final int DOCUMENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DOCUMENTNAME_POSITION").trim());
		final int DOCTYPECODE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DOCTYPECODE_POSITION").trim());
		final int LONGURL_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LONGURL_POSITION").trim());
		final int LINEOFBUSINESS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LINEOFBUSINESS_POSITION").trim());
		
		final int FILEID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FILEID_POSITION").trim());
		final int CAMPAIGNID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CAMPAIGNID_POSITION").trim());
		final int EXTERNALID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EXTERNALID_POSITION").trim());
		final int CONTENTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CONTENTID_POSITION").trim());
		final int PARENTMESSAGEID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PARENTMESSAGEID_POSITION").trim());
		final int SUBTOPICID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SUBTOPICID_POSITION").trim());
		final int FOLDERTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FOLDERTYPE_POSITION").trim());
		final int SENDERNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SENDERNAME_POSITION").trim());
		final int RECIPIENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RECIPIENTNAME_POSITION").trim());
		final int DELIVERYSTATUS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DELIVERYSTATUS_POSITION").trim());
		final int FORMFIELDS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FORMFIELDS_POSITION").trim());
		
		final int EFFECTIVEDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EFFECTIVEDATE_POSITION").trim());
		
		final int EXPIRATIONDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EXPIRATIONDATE_POSITION").trim());
		
		final int SENTDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SENTDATE_POSITION").trim());
			
		final int RECEIVEDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RECEIVEDATE_POSITION").trim());
		final int ORIGIN_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ORIGIN_POSITION").trim());
			
		final int EVENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EVENTNAME_POSITION").trim());
		final int REQUESTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "REQUESTID_POSITION").trim());
		final int ALERTSOURCESYSTEM_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ALERTSOURCESYSTEM_POSITION").trim());
		final int VAULTENABLED_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "VAULTENABLED_POSITION").trim());
		final int ORDERNUMBER_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ORDERNUMBER_POSITION").trim());
		final int LOGCHV_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LOGCHV_POSITION").trim());
		/*final int ALERTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ALERTID_POSITION").trim());
		
		final int ALERTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ALERTNAME_POSITION").trim());
		*/
		final int MIDDLENAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "MIDDLENAME_POSITION").trim());
		
		final int ECHCREQID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ECHCREQID_POSITION").trim());
		
		final int ADDRTYPECD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ADDRTYPECD_POSITION").trim());
		
		final int ADDRESS1_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ADDRESS1_POSITION").trim());
		
		final int ADDRESS2_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ADDRESS2_POSITION").trim());
		
		final int CITY_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CITY_POSITION").trim());
		
		final int ZIPCODE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ZIPCODE_POSITION").trim());
		final int ZIPSFX_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ZIPSFX_POSITION").trim());
		final int CARDMAILINGDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CARDMAILINGDATE_POSITION").trim());
		final int MKTGTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "MKTGTYPE_POSITION").trim());
		final int MKTG_TYPE_END_DT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "MKTG_TYPE_END_DT_POSITION").trim());
		final int QLBENFICIERYID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "QLBENFICIERYID_POSITION").trim());
		final int PREFERREDCLIENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PREFERREDCLIENTNAME_POSITION").trim());	
		final int ECHCTYPE_POSITION = Integer.parseInt(Utility
						.getProperty(folder, finalProduct, "ECHCTYPE_POSITION").trim());
		final int MEDDCOMMERCIAL_POSITIOM = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "MEDDCOMMERCIAL_POSITIOM").trim());
		final int CARRIERID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CARRIERID_POSITION").trim());
		final int ACCOUNTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ACCOUNTID_POSITION").trim());
		final int GROUPNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "GROUPNAME_POSITION").trim());
		//final int CAMPAIGNID_POSITION = Integer.parseInt(Utility
			//	.getProperty(folder, finalProduct, "CAMPAIGNID_POSITION").trim());
	//	final int COMMONCONTENTTYPE_POSITION = Integer.parseInt(Utility
			//	.getProperty(folder, finalProduct, "COMMONCONTENTTYPE_POSITION").trim());
		final int SECUREMSGSENDERNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SECUREMSGSENDERNAME_POSITION").trim());
		final int INTERACTIONID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "INTERACTIONID_POSITION").trim());
		
		final int STATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "STATE_POSITION").trim());
		

	
			
		
		String reqString = null;
		String recordType = null;
		
		
		ObjectMapper objectMapper = null;
	 EchcRequest jsonRequest = new EchcRequest();

		EchcRequest.RequestPayloadData requestPayloadData = null;

		EchcRequest.RequestPayloadData.Data data = null;
		

		
		/*
		 * if (null != recordType && recordType.equalsIgnoreCase("T")) {
		 * reqString = "EOF"; } else {
		 */
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		requestPayloadData = new EchcRequest.RequestPayloadData();
		
		  requestMetaData = new EchcRequest.RequestMetaData();
		  requestMetaData.setAppName(reqParamArray[APPNAME_POSITION]);
		  requestMetaData.setLineOfBusiness(reqParamArray[
		  LINEOFBUSINESS_POSITION]);
		 
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		data = new EchcRequest.RequestPayloadData.Data();

		// Populate Data
		data.setAppName(reqParamArray[APPNAME_POSITION].trim());
		data.setMemberID(reqParamArray[MEMBERID_POSITION].trim());
		data.setMemberSource(reqParamArray[MEMBERSOURCE_POSITION].trim());
		data.setClientID(reqParamArray[CLIENTID_POSITION].trim());
		data.setClientCode(reqParamArray[CLIENTCODE_POSITION].trim());
		data.setFirstName(reqParamArray[FIRSTNAME_POSITION].trim());
		data.setCommMsgReqestID(reqParamArray[COMMMSGREQESTID_POSITION].trim());
		data.setCommAlertID(reqParamArray[COMMALERTID_POSITION].trim());
		data.setCommAlertName(reqParamArray[COMMALERTNAME_POSITION].trim());
		data.setCommDeliveryChannel(reqParamArray[COMMDELIVERYCHANNEL_POSITION].trim());
		data.setCommContentType(reqParamArray[COMMCONTENTTYPE_POSITION].trim());
		data.setCommContactInfo(reqParamArray[COMMCONTACTINFO_POSITION].trim());
		data.setCommSenderInfo(reqParamArray[COMMSENDERINFO_POSITION].trim());
		data.setCommSubject(reqParamArray[COMMSUBJECT_POSITION].trim());
		data.setFileID(reqParamArray[FILEID_POSITION].trim());
		data.setCampaignID(reqParamArray[CAMPAIGNID_POSITION].trim());
		data.setClientSet(reqParamArray[CLIENTSET_POSITION].trim());
		data.setLastName(reqParamArray[LASTNAME_POSITION].trim());
		data.setPlanName(reqParamArray[PLANNAME_POSITION].trim());
		data.setDocumentName(reqParamArray[DOCUMENTNAME_POSITION].trim());
		data.setDocTypeCode(reqParamArray[DOCTYPECODE_POSITION].trim());
		data.setLongURL(reqParamArray[LONGURL_POSITION].trim());
		data.setExternalID(reqParamArray[EXTERNALID_POSITION].trim());
		data.setContentID(reqParamArray[CONTENTID_POSITION].trim());
		data.setLob(reqParamArray[LINEOFBUSINESS_POSITION].trim());
		data.setParentMessageID(reqParamArray[PARENTMESSAGEID_POSITION].trim());
		data.setSubTopicID(reqParamArray[SUBTOPICID_POSITION].trim());
		data.setFolderType(reqParamArray[FOLDERTYPE_POSITION].trim());
		data.setSenderName(reqParamArray[SENDERNAME_POSITION].trim());
		data.setRecipientName(reqParamArray[RECIPIENTNAME_POSITION].trim());
		data.setDeliveryStatus(reqParamArray[DELIVERYSTATUS_POSITION].trim());
		data.setFormFields(reqParamArray[FORMFIELDS_POSITION].trim());
		data.setEffectiveDate(reqParamArray[EFFECTIVEDATE_POSITION].trim());
		data.setExpirationDate(reqParamArray[EXPIRATIONDATE_POSITION].trim());
		data.setSentDate(reqParamArray[SENTDATE_POSITION].trim());
		data.setReceivedDate(reqParamArray[RECEIVEDATE_POSITION].trim());
		data.setOrigin(reqParamArray[ORIGIN_POSITION].trim());
		data.setEventName(reqParamArray[EVENTNAME_POSITION].trim());
		data.setAlertSourceSystem(reqParamArray[ALERTSOURCESYSTEM_POSITION].trim());
		data.setRequestId(reqParamArray[REQUESTID_POSITION].trim());
		data.setVaultEnabled(reqParamArray[VAULTENABLED_POSITION].trim());
		data.setOrderNumber(reqParamArray[ORDERNUMBER_POSITION].trim());
		data.setLogCHV(reqParamArray[LOGCHV_POSITION].trim());
		//data.setAlertId(reqParamArray[ALERTID_POSITION].trim());
		//data.setAlertName(reqParamArray[ALERTNAME_POSITION].trim());
		data.setMiddleName(reqParamArray[MIDDLENAME_POSITION].trim());
		data.setEchcReqID(reqParamArray[ECHCREQID_POSITION].trim());
		data.setAddrTypeCD(reqParamArray[ADDRTYPECD_POSITION].trim());
		data.setAddress1(reqParamArray[ADDRESS1_POSITION].trim());
		data.setAddress2(reqParamArray[ADDRESS2_POSITION].trim());
		data.setCity(reqParamArray[CITY_POSITION].trim());
		data.setState(reqParamArray[STATE_POSITION].trim());
		data.setZipCode(reqParamArray[ZIPCODE_POSITION].trim());
		data.setZipSfx(reqParamArray[ZIPSFX_POSITION].trim());
		data.setCardMailingDate(reqParamArray[CARDMAILINGDATE_POSITION].trim());
		data.setMktgType(reqParamArray[MKTGTYPE_POSITION].trim());
		data.setMKTG_TYPE_END_DT(reqParamArray[MKTG_TYPE_END_DT_POSITION].trim());
		data.setQlBenficieryID(reqParamArray[QLBENFICIERYID_POSITION].trim());
		data.setPreferredClientName(reqParamArray[PREFERREDCLIENTNAME_POSITION].trim());
		data.setEchcType(reqParamArray[ECHCTYPE_POSITION].trim());
		data.setMeddCommercial(reqParamArray[MEDDCOMMERCIAL_POSITIOM].trim());
		data.setCarrierID(reqParamArray[CARRIERID_POSITION].trim());
		data.setAccountID(reqParamArray[ACCOUNTID_POSITION].trim());
		data.setGroupID(reqParamArray[GROUPNAME_POSITION].trim());
		//data.setCampaignID(reqParamArray[CAMPAIGNID_POSITION].trim());
		//data.setCommonContentType(reqParamArray[COMMONCONTENTTYPE_POSITION].trim());
		data.setSecureMsgSenderName(reqParamArray[SECUREMSGSENDERNAME_POSITION].trim());
		data.setInteractionID(reqParamArray[INTERACTIONID_POSITION].trim());
	    data.setAlertName(reqParamArray[COMMALERTNAME_POSITION].trim());
	    data.setAlertID(reqParamArray[COMMALERTID_POSITION].trim());
        
        	 

		requestPayloadData.setData(data);
		jsonRequest.setRequestMetaData(requestMetaData);
		jsonRequest.setRequestPayloadData(requestPayloadData);

		reqString = objectMapper.writeValueAsString(jsonRequest);

	
		return reqString;
	}

}
