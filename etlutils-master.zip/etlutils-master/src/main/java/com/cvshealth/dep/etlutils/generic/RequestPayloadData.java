package com.cvshealth.dep.etlutils.generic;

public class RequestPayloadData {
	

    public String data;

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "RequestPayloadData [data=" + data + "]";
	}

	/*public Data getData() {
		return data;
	}

	public void setData(Data data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "RequestPayloadData [data=" + data + "]";
	}
*/
	

}
