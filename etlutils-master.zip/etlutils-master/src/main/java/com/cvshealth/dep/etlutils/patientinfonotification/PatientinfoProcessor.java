package com.cvshealth.dep.etlutils.patientinfonotification;

import java.util.Date;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.securechat.SecurechatConsumer;
import com.cvshealth.dep.etlutils.securechat.SecurechatProducer;
import com.cvshealth.dep.etlutils.utils.Utility;

public class PatientinfoProcessor implements Processor {
	private static final String APP_NAME = "patientinfoetlutils";
	private final Logger infoLogger = Logger.getLogger("patientinfo");
	private final Logger errorLogger = Logger.getLogger("patienterror");
	private final int BOUND = 100;
	private BlockingQueue<String> _PatientQueue;
	private String _env;
	private int WorkerNumber = 2;
	static Utility util = Utility.getInstance();

	private String finalProduct;

	String logUri = null;

	protected PatientinfoProcessor(String env, int workerNumber)
			throws Exception {
		this.WorkerNumber = workerNumber;
		this._env = env;
		this.finalProduct = ("patientinfo_" + env);

		this.logUri = Utility.getProperty("patientinfo", this.finalProduct,
				"logger.uri");

		this._PatientQueue = new LinkedBlockingQueue<>(BOUND);
	}

	public void close() {
	}

	public void processRecords(List<String> records) {
		int availCores = Utility.getAvailableCores();
		ExecutorService service = Executors.newFixedThreadPool(availCores);

		patientinfoProducer producer = new patientinfoProducer(
				this._PatientQueue, records);

		service.submit(producer);
		try {
			for (int i = 1; i < this.WorkerNumber; i++) {
				System.out.println(this._PatientQueue);
				PatientinfoConsumer consumer = new PatientinfoConsumer(
						this._PatientQueue, this._env);

				service.submit(consumer);
			}
		} catch (Exception e) {
			e.printStackTrace();
			infoLogger
					.info("PatientinfoProcessor | processRecords() | Error in processing records | "
							+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e));

		} finally {
			if (null != service) {
				service.shutdown();
				try {
					service.awaitTermination(30L, TimeUnit.MINUTES);
				} catch (Exception e) {
					this.errorLogger.error(Utility.getStrackTrace(e));
					util.log(APP_NAME, logUri, "9999", "Error", "Job failed",
							new Date(), Utility.getStrackTrace(e));
				}
			}
		}

	}
}