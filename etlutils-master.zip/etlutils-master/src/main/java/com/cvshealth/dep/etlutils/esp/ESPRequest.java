package com.cvshealth.dep.etlutils.esp;

import java.io.Serializable;
import java.util.List;

/**
 * JSON Request Marshaller
 * 
 * @author CVS Health
 */
public class ESPRequest implements Serializable {

	private static final long serialVersionUID = -3241212568743708851L;

	private RequestMetaData requestMetaData = null;
	private RequestPayloadData requestPayloadData = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ESPJSONRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}

	/**
	 * @return the requestMetaData
	 */
	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	/**
	 * @param requestMetaData
	 *            the requestMetaData to set
	 */
	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	/**
	 * @return the requestPayloadData
	 */
	public RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}

	/**
	 * @param requestPayloadData
	 *            the requestPayloadData to set
	 */
	public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */
	public static class RequestMetaData {
		private String appName = "";
		private String lineOfBusiness = "";
		private String conversationID = "";
		private String feedFileName = "";

		public String getFeedFileName() {
			return feedFileName;
		}

		public void setFeedFileName(String feedFileName) {
			this.feedFileName = feedFileName;
		}

		/**
		 * @return the appName
		 */
		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		/**
		 * @return the conversationID
		 */
		public String getConversationID() {
			return conversationID;
		}

		/**
		 * @param conversationID
		 *            the conversationID to set
		 */
		public void setConversationID(String conversationID) {
			this.conversationID = conversationID;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", conversationID=" + conversationID
					+ "]";
		}
	}

	public static class RequestPayloadData {
		private String operation = "";
		private String timestamp = "";
		private Data data = null;
		private ProfileData profile_data = null;
		private List<IdData> id_data = null;
		private List<GlobalOptData> global_opt_data = null;
		private List<EmailPrefData> email_pref_data = null;

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestPayloadData [operation=" + operation
					+ ", timestamp=" + timestamp + ", data=" + data
					+ ", profile_data=" + profile_data + ", id_data=" + id_data
					+ ", global_opt_data=" + global_opt_data
					+ ", email_pref_data=" + email_pref_data + "]";
		}

		/**
		 * @return the operation
		 */
		public String getOperation() {
			return operation;
		}

		/**
		 * @param operation
		 *            the operation to set
		 */
		public void setOperation(String operation) {
			this.operation = operation;
		}

		/**
		 * @return the timestamp
		 */
		public String getTimestamp() {
			return timestamp;
		}

		/**
		 * @param timestamp
		 *            the timestamp to set
		 */
		public void setTimestamp(String timestamp) {
			this.timestamp = timestamp;
		}

		/**
		 * @return the data
		 */
		public Data getData() {
			return data;
		}

		/**
		 * @param data
		 *            the data to set
		 */
		public void setData(Data data) {
			this.data = data;
		}

		/**
		 * @return the profile_data
		 */
		public ProfileData getProfile_data() {
			return profile_data;
		}

		/**
		 * @param profile_data
		 *            the profile_data to set
		 */
		public void setProfile_data(ProfileData profile_data) {
			this.profile_data = profile_data;
		}

		/**
		 * @return the id_data
		 */
		public List<IdData> getId_data() {
			return id_data;
		}

		/**
		 * @param id_data
		 *            the id_data to set
		 */
		public void setId_data(List<IdData> id_data) {
			this.id_data = id_data;
		}

		/**
		 * @return the global_opt_data
		 */
		public List<GlobalOptData> getGlobal_opt_data() {
			return global_opt_data;
		}

		/**
		 * @param global_opt_data
		 *            the global_opt_data to set
		 */
		public void setGlobal_opt_data(List<GlobalOptData> global_opt_data) {
			this.global_opt_data = global_opt_data;
		}

		/**
		 * @return the email_pref_data
		 */
		public List<EmailPrefData> getEmail_pref_data() {
			return email_pref_data;
		}

		/**
		 * @param email_pref_data
		 *            the email_pref_data to set
		 */
		public void setEmail_pref_data(List<EmailPrefData> email_pref_data) {
			this.email_pref_data = email_pref_data;
		}

		/**
		 * Data
		 * 
		 * @author CVSHealth
		 */
		public static class Data {
			private String memberID = "";
			private String memberType = "";
			private String transactionOrigin = "";
			private String transactionLOB = "";
			private String channelID = "";
			private String channelType = "";

			/**
			 * @return the memberID
			 */
			public String getMemberID() {
				return memberID;
			}

			/**
			 * @param memberID
			 *            the memberID to set
			 */
			public void setMemberID(String memberID) {
				this.memberID = memberID;
			}

			/**
			 * @return the memberType
			 */
			public String getMemberType() {
				return memberType;
			}

			/**
			 * @param memberType
			 *            the memberType to set
			 */
			public void setMemberType(String memberType) {
				this.memberType = memberType;
			}

			/**
			 * @return the transactionOrigin
			 */
			public String getTransactionOrigin() {
				return transactionOrigin;
			}

			/**
			 * @param transactionOrigin
			 *            the transactionOrigin to set
			 */
			public void setTransactionOrigin(String transactionOrigin) {
				this.transactionOrigin = transactionOrigin;
			}

			/**
			 * @return the transactionLOB
			 */
			public String getTransactionLOB() {
				return transactionLOB;
			}

			/**
			 * @param transactionLOB
			 *            the transactionLOB to set
			 */
			public void setTransactionLOB(String transactionLOB) {
				this.transactionLOB = transactionLOB;
			}

			/**
			 * @return the channelID
			 */
			public String getChannelID() {
				return channelID;
			}

			/**
			 * @param channelID
			 *            the channelID to set
			 */
			public void setChannelID(String channelID) {
				this.channelID = channelID;
			}

			/**
			 * @return the channelType
			 */
			public String getChannelType() {
				return channelType;
			}

			/**
			 * @param channelType
			 *            the channelType to set
			 */
			public void setChannelType(String channelType) {
				this.channelType = channelType;
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Object#toString()
			 */
			@Override
			public String toString() {
				return "Data [memberID=" + memberID + ", memberType="
						+ memberType + ", transactionOrigin="
						+ transactionOrigin + ", transactionLOB="
						+ transactionLOB + ", channelID=" + channelID
						+ ", channelType=" + channelType + "]";
			}
		}

		/**
		 * ProfileData
		 * 
		 * @author CVSHealth
		 */
		public static class ProfileData {
			private String firstName = "";
			private String lastName = "";
			private String birthDate = "";
			private String address1 = "";
			private String address2 = "";
			private String city = "";
			private String state = "";
			private String postalCode = "";

			/**
			 * @return the firstName
			 */
			public String getFirstName() {
				return firstName;
			}

			/**
			 * @param firstName
			 *            the firstName to set
			 */
			public void setFirstName(String firstName) {
				this.firstName = firstName;
			}

			/**
			 * @return the lastName
			 */
			public String getLastName() {
				return lastName;
			}

			/**
			 * @param lastName
			 *            the lastName to set
			 */
			public void setLastName(String lastName) {
				this.lastName = lastName;
			}

			/**
			 * @return the birthDate
			 */
			public String getBirthDate() {
				return birthDate;
			}

			/**
			 * @param birthDate
			 *            the birthDate to set
			 */
			public void setBirthDate(String birthDate) {
				this.birthDate = birthDate;
			}

			/**
			 * @return the address1
			 */
			public String getAddress1() {
				return address1;
			}

			/**
			 * @param address1
			 *            the address1 to set
			 */
			public void setAddress1(String address1) {
				this.address1 = address1;
			}

			/**
			 * @return the address2
			 */
			public String getAddress2() {
				return address2;
			}

			/**
			 * @param address2
			 *            the address2 to set
			 */
			public void setAddress2(String address2) {
				this.address2 = address2;
			}

			/**
			 * @return the city
			 */
			public String getCity() {
				return city;
			}

			/**
			 * @param city
			 *            the city to set
			 */
			public void setCity(String city) {
				this.city = city;
			}

			/**
			 * @return the state
			 */
			public String getState() {
				return state;
			}

			/**
			 * @param state
			 *            the state to set
			 */
			public void setState(String state) {
				this.state = state;
			}

			/**
			 * @return the postalCode
			 */
			public String getPostalCode() {
				return postalCode;
			}

			/**
			 * @param postalCode
			 *            the postalCode to set
			 */
			public void setPostalCode(String postalCode) {
				this.postalCode = postalCode;
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Object#toString()
			 */
			@Override
			public String toString() {
				return "ProfileData [firstName=" + firstName + ", lastName="
						+ lastName + ", birthDate=" + birthDate + ", address1="
						+ address1 + ", address2=" + address2 + ", city="
						+ city + ", state=" + state + ", postalCode="
						+ postalCode + "]";
			}
		}

		/**
		 * GlobalOptData
		 * 
		 * @author CVSHealth
		 */
		public static class GlobalOptData {
			private String key = "";
			private String value = "";

			/**
			 * @return the key
			 */
			public String getKey() {
				return key;
			}

			/**
			 * @param key
			 *            the key to set
			 */
			public void setKey(String key) {
				this.key = key;
			}

			/**
			 * @return the value
			 */
			public String getValue() {
				return value;
			}

			/**
			 * @param value
			 *            the value to set
			 */
			public void setValue(String value) {
				this.value = value;
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Object#toString()
			 */
			@Override
			public String toString() {
				return "GlobalOptData [key=" + key + ", value=" + value + "]";
			}
		}

		/**
		 * EmailPrefData
		 * 
		 * @author CVSHealth
		 */
		public static class EmailPrefData {
			private String key = "";
			private String value = "";
			private String timestamp = "";

			/**
			 * @return the timestamp
			 */
			public String getTimestamp() {
				return timestamp;
			}

			/**
			 * @param timestamp
			 *            the timestamp to set
			 */
			public void setTimestamp(String timestamp) {
				this.timestamp = timestamp;
			}

			/**
			 * @return the key
			 */
			public String getKey() {
				return key;
			}

			/**
			 * @param key
			 *            the key to set
			 */
			public void setKey(String key) {
				this.key = key;
			}

			/**
			 * @return the value
			 */
			public String getValue() {
				return value;
			}

			/**
			 * @param value
			 *            the value to set
			 */
			public void setValue(String value) {
				this.value = value;
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Object#toString()
			 */
			@Override
			public String toString() {
				return "EmailPrefData [key=" + key + ", value=" + value
						+ ", timestamp=" + timestamp + "]";
			}
		}

		/**
		 * IdData
		 * 
		 * @author CVSHealth
		 */
		public static class IdData {
			private String key = "";
			private String value = "";

			/**
			 * @return the key
			 */
			public String getKey() {
				return key;
			}

			/**
			 * @param key
			 *            the key to set
			 */
			public void setKey(String key) {
				this.key = key;
			}

			/**
			 * @return the value
			 */
			public String getValue() {
				return value;
			}

			/**
			 * @param value
			 *            the value to set
			 */
			public void setValue(String value) {
				this.value = value;
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Object#toString()
			 */
			@Override
			public String toString() {
				return "IdData [key=" + key + ", value=" + value + "]";
			}
		}
	}
}
