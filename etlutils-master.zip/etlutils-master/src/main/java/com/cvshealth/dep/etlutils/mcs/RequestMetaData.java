package com.cvshealth.dep.etlutils.mcs;

public class RequestMetaData {
	private String appName = "";
	private String lineOfBusiness = "MCS";
	private String conversationID = "";
	private String operationName="";
	private String env= "";
	


	

	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	/**
	 * @return the appName
	 */
	public String getAppName() {
		return appName;
	}

	/**
	 * @param appName
	 *            the appName to set
	 */
	public void setAppName(String appName) {
		this.appName = appName;
	}

	/**
	 * @return the lineOfBusiness
	 */
	public String getLineOfBusiness() {
		return lineOfBusiness;
	}

	/**
	 * @param lineOfBusiness
	 *            the lineOfBusiness to set
	 */
	public void setLineOfBusiness(String lineOfBusiness) {
		this.lineOfBusiness = lineOfBusiness;
	}

	/**
	 * @return the conversationID
	 */
	public String getConversationID() {
		return conversationID;
	}

	/**
	 * @param conversationID
	 *            the conversationID to set
	 */
	public void setConversationID(String conversationID) {
		this.conversationID = conversationID;
	}

	public String getOperationName() {
		return operationName;
	}

	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	@Override
	public String toString() {
		return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
				+ lineOfBusiness + ", conversationID=" + conversationID
				+ ", operationName=" + operationName + ", env=" + env + "]";
	}

	
}


