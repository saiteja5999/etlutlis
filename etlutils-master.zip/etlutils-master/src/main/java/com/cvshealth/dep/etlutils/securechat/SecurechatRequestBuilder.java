package com.cvshealth.dep.etlutils.securechat;

import java.util.ArrayList;
import java.util.List;

import com.cvshealth.dep.etlutils.securechat.SecurechatRequest;
import com.cvshealth.dep.etlutils.securechat.Patients;
import com.cvshealth.dep.etlutils.securechat.MessageList;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SecurechatRequestBuilder {

	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {

		final int PSRUSERID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "PSRUSERID_POSITION");
		final int PATIENTID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "PATIENTID_POSITION");
		final int PHONE_POSITION = Utility.getPropertyInt(folder, finalProduct,
				"PHONE_POSITION");
		final int EMAIL_POSITION = Utility.getPropertyInt(folder, finalProduct,
				"EMAIL_POSITION");

		final int MESSAGECATEGORY_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "MESSAGECATEGORY_POSITION");
		final int MESSAGEID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "MESSAGEID_POSITION");
		final int MESSAGETEXT_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "MESSAGETEXT_POSITION");
		final int SECUREMESSAGETEXT_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "SECUREMESSAGETEXT_POSITION");
		final int CHANNELTYPE_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "CHANNELTYPE_POSITION");

		final int MESSAGEDATETIMESTAMP_POSITION = Utility.getPropertyInt(
				folder, finalProduct, "MESSAGEDATETIMESTAMP_POSITION");
		final int MESSAGETOPIC_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "MESSAGETOPIC_POSITION");
		final int CAMPAIGNID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "CAMPAIGNID_POSITION");

		final int STATUSRESPONSE_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "STATUSRESPONSE_POSITION");
		final int STATUSREASON_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "STATUSREASON_POSITION");
		final int LEADMESSAGEID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "LEADMESSAGEID_POSITION");

		List<Patients> patientsList = new ArrayList<Patients>();
		// Populate patients model
		Patients patients = new Patients();
		patients.setPatientId(reqParamArray[PATIENTID_POSITION].trim());
		patients.setPhone(reqParamArray[PHONE_POSITION].trim());
		patients.setEmail(reqParamArray[EMAIL_POSITION].trim());
		/*
		 * we are creating the arraylist and request body positions for patients
		 * and messagelist
		 */
		List<MessageList> messsgeList = new ArrayList<MessageList>();
		// Populate MessageList model

		MessageList messageReq = new MessageList();
		messageReq.setMessageCategory(reqParamArray[MESSAGECATEGORY_POSITION]
				.trim());
		messageReq.setMessageId(reqParamArray[MESSAGEID_POSITION].trim());
		messageReq.setMessageText(reqParamArray[MESSAGETEXT_POSITION].trim());
		messageReq
				.setSecureMessageText(reqParamArray[SECUREMESSAGETEXT_POSITION]
						.trim());
		messageReq.setMessageTopic(reqParamArray[MESSAGETOPIC_POSITION].trim());
		messageReq.setCampaignId(reqParamArray[CAMPAIGNID_POSITION].trim());
		messageReq.setChannelType(reqParamArray[CHANNELTYPE_POSITION].trim());

		messageReq
				.setMessageDateTimestamp(reqParamArray[MESSAGEDATETIMESTAMP_POSITION]
						.trim());
		messageReq.setStatusResponse(reqParamArray[STATUSRESPONSE_POSITION]
				.trim());
		messageReq.setStatusReason(reqParamArray[STATUSREASON_POSITION].trim());
		messageReq.setLeadMessageId(reqParamArray[LEADMESSAGEID_POSITION]
				.trim());

		if (messageReq != null) {
			messsgeList.add(messageReq);
		}

		if (messsgeList != null && messsgeList.size() > 0) {
			patients.setMessageList(messsgeList);
		}
		patientsList.add(patients);

		SecurechatRequest securechatRequest = new SecurechatRequest();

		if (patientsList != null && patientsList.size() > 0) {
			securechatRequest.setPatients(patientsList);
		}
		securechatRequest
				.setPsrUserId(reqParamArray[PSRUSERID_POSITION].trim());

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		return objectMapper.writeValueAsString(securechatRequest);

	}

}
