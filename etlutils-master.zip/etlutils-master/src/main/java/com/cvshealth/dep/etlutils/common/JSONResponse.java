package com.cvshealth.dep.etlutils.common;

import java.io.Serializable;

public class JSONResponse implements Serializable {

	private static final long serialVersionUID = 7177345883110611788L;

	private ResponseMetaData responseMetaData = null;
	private ResponsePayloadData responsePayloadData = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "JSONResponse [responseMetaData=" + responseMetaData
				+ ", responsePayloadData=" + responsePayloadData + "]";
	}

	/**
	 * @return the responseMetaData
	 */
	public ResponseMetaData getResponseMetaData() {
		return responseMetaData;
	}

	/**
	 * @param responseMetaData
	 *            the responseMetaData to set
	 */
	public void setResponseMetaData(ResponseMetaData responseMetaData) {
		this.responseMetaData = responseMetaData;
	}

	/**
	 * @return the responsePayloadData
	 */
	public ResponsePayloadData getResponsePayloadData() {
		return responsePayloadData;
	}

	/**
	 * @param responsePayloadData
	 *            the responsePayloadData to set
	 */
	public void setResponsePayloadData(ResponsePayloadData responsePayloadData) {
		this.responsePayloadData = responsePayloadData;
	}

	public static class ResponseMetaData {
		private String statusCode = "";
		private String statusDesc = "";

		/**
		 * @return the statusCode
		 */
		public String getStatusCode() {
			return statusCode;
		}

		/**
		 * @param statusCode
		 *            the statusCode to set
		 */
		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}

		/**
		 * @return the statusDesc
		 */
		public String getStatusDesc() {
			return statusDesc;
		}

		/**
		 * @param statusDesc
		 *            the statusDesc to set
		 */
		public void setStatusDesc(String statusDesc) {
			this.statusDesc = statusDesc;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "ResponseMetaData [statusCode=" + statusCode
					+ ", statusDesc=" + statusDesc + "]";
		}
	}

	public static class ResponsePayloadData {
		private String data = "";

		/**
		 * @return the data
		 */
		public String getData() {
			return data;
		}

		/**
		 * @param data
		 *            the data to set
		 */
		public void setData(String data) {
			this.data = data;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "ResponsePayloadData [data=" + data + "]";
		}
	}
}
