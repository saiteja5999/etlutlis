package com.cvshealth.dep.etlutils.patientinfonotification;

import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.common.JSONResponse;
import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.common.Response;
import com.cvshealth.dep.etlutils.securechat.SecurechatMain;
import com.cvshealth.dep.etlutils.securechat.SecurechatProcessor;
import com.cvshealth.dep.etlutils.utils.JSONBuilder;
import com.cvshealth.dep.etlutils.utils.Main;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class PatientinfoMain extends Main {

	private static List<String> records = null;

	private static Path inputFilePath = null;
	private static JSONResponse jsonResponse = null;
	private static Processor processor = null;

	private static final Charset CHARSET = Charset.forName("UTF-8");
	private static final Logger infoLogger = Logger.getLogger("patientinfo");
	private static final Logger errorLogger = Logger.getLogger("patienterror");

	private static final Date START_TIME = null;
	public final static String PRODUCT = "patientinfo";

	private static final String APP_NAME = "patientetlutils";

	private static int WorkNumber = 2;
	static Utility util = Utility.getInstance();

	public static void main(String[] args) {

		String env = null;
		String fileFeed = null;
		Date startDate = null;
		Date endDate = null;
		ObjectMapper objectMapper = null;

		String logUri = "";

		try {
			startDate = new Date();
			String logMsg = "patientinfo JOB started @ "
					+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
							.format(new Date());
			infoLogger.info(logMsg);
			jsonResponse = new JSONResponse();
			objectMapper = new ObjectMapper();
			if (args.length == 0 || null == args[0] || "".equals(args[0])
					|| null == args[1] || "".equals(args[1])) {
				logMsg = "Input file is empty or invalid / Execution environment is empty or invalid";
				jsonResponse = JSONBuilder.getJSONResponse(
						Response.STATUSCODE9999, Response.STATUSDESC9999,
						logMsg);
				logMsg = "PatientinfoMain | Input file is empty or invalid / Execution environment is empty or invalid";
				infoLogger.info(logMsg);
				errorLogger
						.error(objectMapper.writeValueAsString(jsonResponse));
				System.out.println(objectMapper
						.writeValueAsString(jsonResponse));
				endDate = new Date();
			} else {
				env = args[0];
				fileFeed = args[1];
				String finalProduct = PatientinfoMain.PRODUCT + "_" + env;
				logUri = Utility.getProperty(PRODUCT, finalProduct,
						"logger.uri");
				logMsg = "PatientinfoMain | env=" + env + " | fileFeed="
						+ fileFeed;
				infoLogger.info(logMsg);
				util.log(APP_NAME, logUri, "0000", "Success", logMsg,
						START_TIME, "");
				logMsg = "PatientinfoMain | Parsing fileFeed...";
				infoLogger.info(logMsg);
				inputFilePath = Paths.get(fileFeed);
				if (null == inputFilePath || !inputFilePath.toFile().isFile()) {
					logMsg = "Input file " + fileFeed
							+ " is invalid or does not exists";
					jsonResponse = JSONBuilder.getJSONResponse(
							Response.STATUSCODE9999, Response.STATUSDESC9999,
							logMsg);
					logMsg = "PatientinfoMain | Input file " + fileFeed
							+ " is invalid or does not exists";
					infoLogger.info(logMsg);
					errorLogger.error(objectMapper
							.writeValueAsString(jsonResponse));

					util.log(APP_NAME, logUri, "9999", "Error", "Job failed",
							START_TIME, logMsg);
					endDate = new Date();
				} else {

					records = Files.readAllLines(inputFilePath, CHARSET);
					infoLogger.info(records);
					logMsg = "PatientinfoMain | Num of records in file found : "
							+ records.size();
					infoLogger.info(logMsg);

					util.log(APP_NAME, logUri, "0000", "Success", logMsg,
							START_TIME, "");
					String workerNumber = System.getenv("worknumber");
					if (workerNumber != null) {
						WorkNumber = Integer.parseInt(workerNumber);
					}

					System.out.println("PatientinfoMain | Num of consumer : "
							+ WorkNumber);

					processor = new PatientinfoProcessor(env, WorkNumber);
					logMsg = "PatientinfoMain | Processing records...";
					infoLogger.info(logMsg);
					processor.processRecords(records);

					jsonResponse = JSONBuilder.getJSONResponse(
							Response.STATUSCODE0000, Response.STATUSDESC0000,
							"");
					infoLogger.info(objectMapper
							.writeValueAsString(jsonResponse));

					endDate = new Date();
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			jsonResponse = JSONBuilder.getJSONResponse(
					Response.STATUSCODE9999,
					Response.STATUSDESC9999,
					"Exception executing SecurechatMain Job | "
							+ e.getMessage());
			try {
				String logMsg = "Exception executing PatientinfoMain Job @  | "
						+ e.getMessage();
				infoLogger.info(logMsg);
				errorLogger
						.error(objectMapper.writeValueAsString(jsonResponse));
				endDate = new Date();
				util.log(APP_NAME, logUri, "9999", "Error", "Job failed",
						endDate, logMsg);
			} catch (JsonProcessingException e1) {
				errorLogger.error(Utility.getStrackTrace(e1));
			}
		}
		String logMsg = "PatientinfoMain JOB ended @ "
				+ new SimpleDateFormat("MM-dd-yyyy HH:mm:ss")
						.format(new Date());
		infoLogger.info(logMsg);

		util.log(APP_NAME, logUri, "0000", "Success", logMsg, new Date(), "");

		infoLogger.info("PatientinfoMain JOB took "
				+ (TimeUnit.SECONDS.toSeconds(endDate.getTime()
						- startDate.getTime())) + " ms");
	}
}
