package com.cvshealth.dep.etlutils.notification;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import org.json.JSONObject;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.notification.NotificationRequest.DeviceData;
import com.cvshealth.dep.etlutils.notification.NotificationRequest.KeyValue;
import com.cvshealth.dep.etlutils.notification.NotificationRequest.MessageData;
import com.cvshealth.dep.etlutils.notification.NotificationRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.notification.NotificationRequest.RequestPayloadData;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Notification JSON Builder - Build the JSON request payload for the
 * XID/Notification service
 * 
 * @author CVSHealth
 */
public class NotificationRequestBuilder implements RequestBuilder {

	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		final int CAMPID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CAMPID_POSITION"));
		final int MEMBERID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERID_POSITION"));
		final int MEMBERTYPE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERTYPE_POSITION"));
		final int CHANNELID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CHANNELID_POSITION"));
		final int CHANNELTYPE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CHANNELTYPE_POSITION"));
		final int LOB_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "LOB_POSITION"));
		final int CAMPTYPE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CAMPTYPE_POSITION"));
		final int SUBJECT_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "SUBJECT_POSITION"));
		final int CAMPTEMP_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CAMPTEMP_POSITION"));
		final int OPPID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "OPPID_POSITION"));
		final int ADDDATA_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "ADDDATA_POSITION"));
		final int DEEPLINKURL_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "DEEPLINKURL_POSITION"));
		final int XID_FLAG_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "XID_FLAG_POSITION"));
		final int ACTION_FLAG_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "ACTION_FLAG_POSITION"));
		final int PRGNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "PRGNAME_POSITION"));
		final int EXTCAMPID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "EXTCAMPID_POSITION"));
		final int FROMEMAIL_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "FROMEMAIL_POSITION"));

		final String APP_NAME = Utility.getProperty(folder, finalProduct,
				"APP_NAME");
		final String SUCCESS_CODE = Utility.getProperty(folder, finalProduct,
				"SUCCESS_CODE");
		final String PROGRAM_NAME = Utility.getProperty(folder, finalProduct,
				"PROGRAM_NAME");
		final String FROM_EMAIL = Utility.getProperty(folder, finalProduct,
				"FROM_EMAIL");
		final String XTIFY_MODE = Utility.getProperty(folder, finalProduct,
				"XTIFY_MODE");
		final String XID_APP_NAME = Utility.getProperty(folder, finalProduct,
				"XID_APP_NAME");
		final String KEY_VALUE_DELIMITER = Utility.getProperty(folder,
				finalProduct, "KEY_VALUE_DELIMITER");
		final String KEY_VALUE_DELIMITER_2 = Utility.getProperty(folder,
				finalProduct, "KEY_VALUE_DELIMITER_2");
		final String SPECIAL_DELIMITER_CHAR = Utility.getProperty(folder,
				finalProduct, "SPECIAL_DELIMITER_CHAR");

		// RegEx
		String kvregex = "(?<!" + Pattern.quote(SPECIAL_DELIMITER_CHAR) + ")"
				+ Pattern.quote(KEY_VALUE_DELIMITER);
		String kvregex2 = "(?<!" + Pattern.quote(SPECIAL_DELIMITER_CHAR) + ")"
				+ Pattern.quote(KEY_VALUE_DELIMITER_2);

		// Populate DeviceData
		DeviceData deviceData = new DeviceData();
		deviceData.setChannelType(reqParamArray[CHANNELTYPE_POSITION]);
		deviceData.setChannelID(reqParamArray[CHANNELID_POSITION]);
		deviceData.setContentType(reqParamArray[CAMPTYPE_POSITION]);
		deviceData.setDeviceType("");
		deviceData.setMemberID(reqParamArray[MEMBERID_POSITION]);
		deviceData.setMemberType(reqParamArray[MEMBERTYPE_POSITION]);
		deviceData.setCampaignID(reqParamArray[CAMPID_POSITION]);
		deviceData.setOpportunityID(reqParamArray[OPPID_POSITION]);
		deviceData.setContentID(reqParamArray[CAMPTEMP_POSITION]);

		if (null == reqParamArray[EXTCAMPID_POSITION]) {
			deviceData.setCNID("");
		} else {
			deviceData.setCNID(reqParamArray[EXTCAMPID_POSITION]);
		}

		// Populate Message Data
		MessageData messageData = new MessageData();
		List<KeyValue> keyValueList = new ArrayList<KeyValue>();
		JSONObject additionalData = new JSONObject();

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

		if (FROMEMAIL_POSITION >= 0
				&& FROMEMAIL_POSITION < reqParamArray.length) {
			messageData.setFrom(reqParamArray[FROMEMAIL_POSITION]);
		} else {
			messageData.setFrom(FROM_EMAIL);
		}

		messageData.setSubject(reqParamArray[SUBJECT_POSITION]);
		messageData.setBody("");
		messageData.setAttachment("N");

		// Check for additionalData
		if (null != reqParamArray[ADDDATA_POSITION]
				&& !"".equals(reqParamArray[ADDDATA_POSITION])) {
			String[] addDataArr = reqParamArray[ADDDATA_POSITION]
					.split(kvregex);

			for (String str : addDataArr) {
				KeyValue keyValue = new KeyValue();
				String[] kvStr = str.split(kvregex2);
				String key = kvStr[0];
				String value = kvStr[1].replace(SPECIAL_DELIMITER_CHAR, "");
				keyValue.setKey(key);
				keyValue.setValue(value);
				keyValueList.add(keyValue);

				// Also set the key value in the additional
				additionalData.put(key, value);

				// Check for the deviceType if present set it in the deviceData
				if ("device_data".equalsIgnoreCase(key)) {
					deviceData.setDeviceType(value);
				}
			}
			messageData.setKeyValueList(keyValueList);
		} // End of additionalData checks

		// Populate RequestPayloadData
		RequestPayloadData requestPayloadData = new RequestPayloadData();
		requestPayloadData.setDeviceData(deviceData);
		requestPayloadData.setMessageData(messageData);
		requestPayloadData.setAdditionalData(additionalData);

		// Populate RequestMetaData
		RequestMetaData requestMetaData = new RequestMetaData();
		requestMetaData.setAppName(APP_NAME);
		requestMetaData.setLineOfBusiness(reqParamArray[LOB_POSITION]);
		requestMetaData.setProgramName(PROGRAM_NAME);
		requestMetaData.setGrid(UUID.randomUUID().toString());
		requestMetaData.setRequestPayloadData(requestPayloadData);

		// Populate NotificationRequest
		NotificationRequest notificationRequest = new NotificationRequest();
		notificationRequest.setRequestMetaData(requestMetaData);

		return objectMapper.writeValueAsString(notificationRequest);
	}
}
