package com.cvshealth.dep.etlutils.echc;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.echc.EchcRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.utils.Service;
import com.cvshealth.dep.etlutils.utils.Utility;

/**
 * PaperlessRequestGenerator processes the file entries and marshalls each entry in a
 * valid JSON request
 * 
 * @author CVS Health
 */
public class EchcProcessor implements Processor {

	private final String PRODUCT = "echc";
	private String finalProduct = null;
	private final Logger infoLogger = Logger.getLogger("echcinfo");
	private final Logger errorLogger = Logger.getLogger("echcerror");
	private String feedFileName = "";

	protected EchcProcessor(String env, String fileName) {
		finalProduct = PRODUCT + "_" + env;
		feedFileName = fileName;
	}

	@Override
	public void processRecords(List<String> records) {
		ExecutorService service = null;

		try {
			final String[] kafkaServers = Utility.getProperty(PRODUCT,
					finalProduct, "kafka.servers").split("\\|");
		
			final int APPNAME_POSITION = Integer.parseInt(Utility.getProperty(
					PRODUCT, finalProduct, "APPNAME_POSITION"));
			final int LINEOFBUSINESS_POSITION = Integer.parseInt(Utility
					.getProperty(PRODUCT, finalProduct,
							"LINEOFBUSINESS_POSITION"));
			final EchcRequest.RequestMetaData requestMetaData = new EchcRequest.RequestMetaData();

			final String kafkaURI = Utility.getProperty(PRODUCT, finalProduct,
					"kafka.uri");
			int availCores = Utility.getAvailableCores();

			infoLogger
					.info("ECHCPaperlessProcessor | processRecords() | Avail CPU Cores:"
							+ availCores
							+ ", spawing threads as available cores for parallel execution");

			// service = Executors.newFixedThreadPool(availCores);
			service = Executors.newFixedThreadPool(1);
			int recCount = 0;
			String headerRecord1 = records.get(0);
			String  headerRecord = new String (headerRecord1.getBytes("UTF-8"), "UTF-8");
			//String�headerRecord�=�new�String(headerRecord1.getBytes("UTF-8")); 
			//String�headerRecord�=�new�String(headerRecord1,�"UTF_8"); 
			String[] reqParamArray = headerRecord.split(Utility.getProperty(
					PRODUCT, finalProduct, "field.delimiter"));
			
			//String recordType = reqParamArray[RECORDTYPE_POSITION].trim();
			//if (null != recordType && recordType.equalsIgnoreCase("H")) {
				requestMetaData.setAppName(reqParamArray[APPNAME_POSITION]
						.trim());
				requestMetaData
						.setLineOfBusiness(reqParamArray[LINEOFBUSINESS_POSITION]
								.trim());
				
			
			// iterate for each record and process
			for (final String record : records) {

				// Spawn thread and process it async
				// service.execute(new Runnable() {
				// String[] reqParamArray = null;
				reqParamArray = null;
				String reqString = null;
				
				EchcRequestBuilder requestBuilder =null;
				recCount = recCount + 1;
				// @Override
				// public void run() {
				try {
					RequestMetaData requestMetaData1 = new EchcRequest.RequestMetaData();
					requestMetaData1.setAppName(requestMetaData1.getAppName());
					requestMetaData1.setLineOfBusiness(requestMetaData1
							.getLineOfBusiness());
					
					requestMetaData1.setConversationID(UUID.randomUUID()
							.toString());

					// Marshall the record into JSON Request
					reqParamArray = record.split(Utility.getProperty(PRODUCT,
							finalProduct, "field.delimiter"));
					
						requestBuilder = new EchcRequestBuilder(requestMetaData1);
						reqString = requestBuilder.getRequest(reqParamArray,
								finalProduct, PRODUCT);
					//	String etlPayload = JSONBuilder.getETLPayload(Utility
							//.getProperty(PRODUCT, finalProduct, "product"),
								//reqString);
						System.out.println("EchcRequest= "+reqString);

						// Invoke the Service to push the message into
						// Kafka
						System.out.println(reqString);
						infoLogger
						.info("PayLoadRequest to Kafka:" + reqString);
						String URL = "http://"
								+ kafkaServers[ThreadLocalRandom.current()
										.nextInt(0, kafkaServers.length)]
								+ ":4104" + kafkaURI;
						infoLogger
								.info("PayLoadRequest to Kafka:" + reqString);

						// Build the header
						Map<String, String> headers = new HashMap<String, String>();
						headers.put("AuthKey", Utility.getProperty(PRODUCT,
								finalProduct, "kafka.authkey"));

			           Service.post(URL, "echcpaperless", reqString, headers);
			       
						if (recCount > 15) {
							recCount = 0;
							Thread.sleep(1000);
						}
					
				} catch (Exception e) {
					infoLogger
							.info("ECHCPaperlessProcessor | service.execute() | Error while converting record into JSONRequest"
									+ e.getMessage());
					errorLogger
							.error("ECHCPaperlessProcessor | service.execute() | Service Request : "
									+ record + " | Error : " + Utility.getStrackTrace(e));
				}
			}
		} catch (Exception e) {
			infoLogger
					.info("ECHCPaperlessProcessor | processRecords() | Error in processing records | "
							+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e));
		} finally {
			if (null != service) {
				service.shutdown();
				try {
					if (!service.awaitTermination(30, TimeUnit.MINUTES)) {
						errorLogger
								.info("ECHCPaperlessProcessor | processRecords() | Threads did not complete all the tasks in 30 minutes. For stopping the Job");
						service.shutdownNow();
					}
				} catch (Exception e) {
					errorLogger.error(Utility.getStrackTrace(e));
				}
			}
		}
	}
}
