package com.cvshealth.dep.etlutils.generic;

import java.io.Serializable;



public class GenericRequest implements Serializable {
private static final long serialVersionUID = -4187537354799171017L;

	

	private RequestMetaData requestMetaData = null;
	private RequestPayloadData requestPayloadData = null;
	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}
	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}
	public RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}
	public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}
	@Override
	public String toString() {
		return "GenericRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}
	

}
