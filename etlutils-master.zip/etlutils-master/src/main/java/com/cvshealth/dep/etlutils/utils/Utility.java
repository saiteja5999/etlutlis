package com.cvshealth.dep.etlutils.utils;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang.exception.ExceptionUtils;

/**
 * Generic Utility with helper functions
 * 
 * @author CVS Health
 */
public class Utility {

	private static Map<String, Properties> props = new HashMap<String, Properties>();
	private static Utility utility = null;

	/**
	 * Generates a detailed printStackTrack in String format
	 * 
	 * @param e
	 * @return
	 */
	public static String getStrackTrace(Exception e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();
	}
	
	/**
	 * Converts the printStack into String
	 * 
	 * @param e
	 * @return
	 */
	public static String getError(Exception e) {
		return ExceptionUtils.getStackTrace(e);
	}

	public void log(String log) {
		System.out.println(log);
	}

	public String rmvVerticalBarEtc(String input) {
		if (null == input || "".equals(input)) {
			return input;
		}
		return input.replaceAll("\\||\\\r|\\\n", "");
	}

	public void log(String operation, String logServiceUri,
			String conversationId, String statusCode, String statusDesc,
			String httpStatusCode, String requestTimeStamp, String request,
			String response, String responseTimeStamp, String error) {
		try {
			ServiceClient.logToSplunk(operation, logServiceUri, conversationId,
					statusCode, statusDesc, httpStatusCode, requestTimeStamp,
					request, response, responseTimeStamp, error);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void log(String operation, String logServiceUri, String statusCode,
			String statusDesc, String request, Date requestTimeStamp,
			String error) {
		log(request);
		try {
			Date responseTime = new Date();
			String responseTimeStamp = String.valueOf(responseTime);
			log(operation, logServiceUri, "", statusCode, statusDesc, "200",
					String.valueOf(requestTimeStamp), request, "",
					responseTimeStamp, error);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Fetches the property for that ke
	 * 
	 * @param product
	 * @param key
	 * @return
	 */
	public static String getProperty(String folder, String product, String key)
			throws Exception {
		if (!props.containsKey(product)) {
			Properties properties = new Properties();

			properties
					.load(Utility.class.getClassLoader()
					// .getResourceAsStream(product.substring(0,
					// product.length() - 4) + "/" + product + ".properties"));
							.getResourceAsStream(
									folder + "/" + product + ".properties"));
			props.put(product, properties);
		}
		return props.get(product).getProperty(key);
	}

	/*
	 * public static Map<String, String> loadCode() throws IOException
	 * 
	 * { Map<String, String> propertyMap = new HashMap<String, String>();
	 * FileReader reader = new FileReader(
	 * "/opt/digital/scripts/usps/eventcode_dev.properties");
	 * 
	 * Properties p = new Properties(); p.load(reader); Enumeration keys =
	 * p.propertyNames(); while (keys.hasMoreElements()) { String key = (String)
	 * keys.nextElement(); propertyMap.put(key, p.getProperty(key)); }
	 * reader.close(); return propertyMap; }
	 */
	/**
	 * Fetches the property for that key
	 * 
	 * @param product
	 * @param key
	 * @return
	 */
	public static int getPropertyInt(String folder, String product, String key)
			throws Exception {
		String value = getProperty(folder, product, key);
		return Integer.parseInt(value);
	}

	/**
	 * Returns the available CPU Cores from Runtime()
	 * 
	 * @return
	 */
	public static int getAvailableCores() {
		return Runtime.getRuntime().availableProcessors();
	}

	public static Utility getInstance() {
		if (null == utility) {
			synchronized (Utility.class) {
				if (null == utility) {
					utility = new Utility();
				}
			}
		}
		return utility;
	}
}
