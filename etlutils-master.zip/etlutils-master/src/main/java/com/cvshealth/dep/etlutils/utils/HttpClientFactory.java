package com.cvshealth.dep.etlutils.utils;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.KeyStore;
import java.security.cert.X509Certificate;

public class HttpClientFactory {

	private static CloseableHttpClient client;
	final char[] JKS_PASSWORD = "caremark".toCharArray();
	final static char[] KEY_PASSWORD = "caremark".toCharArray();

	private static class DummyHostnameVerifier implements HostnameVerifier {
		public boolean verify(String hostname, SSLSession session) {
			return true;
		}
	}

	public static HttpClient getHttpsClient() throws Exception {
		try {
			if (client != null) {
				return client;
			}

			KeyStore keyStore = KeyStore.getInstance("JKS");
			FileInputStream fin = new FileInputStream(
					"/opt/digital/javaapps/config/nodejsprod.jks");
			keyStore.load(fin, "caremark".toCharArray());
			fin.close();

			KeyManagerFactory keyManagerFactory = KeyManagerFactory
					.getInstance("SunX509");
			keyManagerFactory.init(keyStore, "caremark".toCharArray());

			SSLContext sslContext = SSLContext.getInstance("TLSv1.2");
			sslContext.init(keyManagerFactory.getKeyManagers(),
					new TrustManager[] { new X509TrustManager() {
						public X509Certificate[] getAcceptedIssuers() {
							System.out
									.println("getAcceptedIssuers =============");
							return null;
						}

						public void checkClientTrusted(X509Certificate[] certs,
								String authType) {
							System.out
									.println("checkClientTrusted =============");
						}

						public void checkServerTrusted(X509Certificate[] certs,
								String authType) {
							System.out
									.println("checkServerTrusted =============");
						}
					} }, null);

			HostnameVerifier dummy_hostname_verifier = new DummyHostnameVerifier();

			SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
					sslContext, new String[] { "TLSv1.2" }, null,
					dummy_hostname_verifier);

			client = HttpClients.custom().setSSLSocketFactory(sslsf).build();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return client;
	}

	public static void releaseInstance() {
		if (client != null) {
			try {
				client.close();
			} catch (IOException e) {
				e.printStackTrace();
				client = null;
			}
		}
	}

}
