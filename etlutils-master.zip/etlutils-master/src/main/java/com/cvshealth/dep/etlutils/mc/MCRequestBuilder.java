package com.cvshealth.dep.etlutils.mc;

import java.util.ArrayList;
import java.util.List;


import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.mc.MCRequest;
import com.cvshealth.dep.etlutils.mc.MCRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.usps.UspsRequest;
import com.cvshealth.dep.etlutils.usps.ZipcodeUtil;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class MCRequestBuilder implements RequestBuilder {
	private RequestMetaData requestMetaData;

	public MCRequestBuilder(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	
	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		

		 final int APPNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "APPNAME_POSITION").trim());
		
		final int MEMBERID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERID_POSITION").trim());
		final int MEMBERSOURCE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "MEMBERSOURCE_POSITION").trim());
		final int CLIENTID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CLIENTID_POSITION").trim());
		final int CLIENTCODE_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CLIENTCODE_POSITION").trim());
		final int FIRSTNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "FIRSTNAME_POSITION").trim());
		final int COMMMSGREQESTID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMMSGREQESTID_POSITION").trim());
		final int COMMALERTID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMALERTID_POSITION").trim());
		final int COMMALERTNAME_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMALERTNAME_POSITION").trim());
		final int COMMDELIVERYCHANNEL_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMDELIVERYCHANNEL_POSITION").trim());
		final int COMMCONTENTTYPE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "COMMCONTENTTYPE_POSITION").trim());
		final int COMMCONTACTINFO_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMCONTACTINFO_POSITION").trim());
		final int COMMSENDERINFO_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMSENDERINFO_POSITION").trim());
		final int COMMSUBJECT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "COMMSUBJECT_POSITION").trim());
		final int CLIENTSET_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CLIENTSET_POSITION").trim());
		
		final int LASTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LASTNAME_POSITION").trim());
		final int PLANNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PLANNAME_POSITION").trim());
		final int DOCUMENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DOCUMENTNAME_POSITION").trim());
		final int DOCTYPECODE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DOCTYPECODE_POSITION").trim());
		final int LONGURL_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LONGURL_POSITION").trim());
		final int LINEOFBUSINESS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LINEOFBUSINESS_POSITION").trim());
		
		final int FILEID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FILEID_POSITION").trim());
		final int CAMPAIGNID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CAMPAIGNID_POSITION").trim());
		final int EXTERNALID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EXTERNALID_POSITION").trim());
		final int CONTENTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CONTENTID_POSITION").trim());
		final int PARENTMESSAGEID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PARENTMESSAGEID_POSITION").trim());
		final int SUBTOPICID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SUBTOPICID_POSITION").trim());
		final int FOLDERTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FOLDERTYPE_POSITION").trim());
		final int SENDERNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SENDERNAME_POSITION").trim());
		final int RECIPIENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RECIPIENTNAME_POSITION").trim());
		final int DELIVERYSTATUS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DELIVERYSTATUS_POSITION").trim());
		final int FORMFIELDS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "FORMFIELDS_POSITION").trim());
		
		final int EFFECTIVEDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EFFECTIVEDATE_POSITION").trim());
		
		final int EXPIRATIONDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EXPIRATIONDATE_POSITION").trim());
		
		final int SENTDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SENTDATE_POSITION").trim());
			
		final int RECEIVEDATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RECEIVEDATE_POSITION").trim());
		final int ORIGIN_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ORIGIN_POSITION").trim());
			
		final int EVENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EVENTNAME_POSITION").trim());
		final int REQUESTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "REQUESTID_POSITION").trim());
		final int ALERTSOURCESYSTEM_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ALERTSOURCESYSTEM_POSITION").trim());
		final int VAULTENABLED_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "VAULTENABLED_POSITION").trim());
		final int ORDERNUMBER_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ORDERNUMBER_POSITION").trim());
		final int LOGCHV_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LOGCHV_POSITION").trim());
		final int CONTRACTID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "CONTRACTID_POSITION").trim());
		final int LANGUAGEINDICATOR_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "LANGUAGEINDICATOR_POSITION").trim());
		final int PBPID_POSITION = Integer.parseInt(Utility.getProperty(folder, finalProduct, "PBPID_POSITION").trim());
		final int ADDRESS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ADDRESS_POSITION").trim());
		final int RXPATID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXPATID_POSITION").trim());
		final int RXTIEDID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXTIEDID_POSITION").trim());
		final int SSENRLMIND_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SSENRLMIND_POSITION").trim());
		final int RDYFILLENRLMIND_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RDYFILLENRLMIND_POSITION").trim());
		final int CRGVRIND_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CRGVRIND_POSITION").trim());
		final int TEMPLATETYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "TEMPLATETYPE_POSITION").trim());
		final int TEMPLATEVERSION_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "TEMPLATEVERSION_POSITION").trim());
		final int TOTALACTIVEMIANTRXS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "TOTALACTIVEMIANTRXS_POSITION").trim());
		final int TOTALACTIVERXS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "TOTALACTIVERXS_POSITION").trim());
		final int PREDICTEDPDCVAL_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PREDICTEDPDCVAL_POSITION").trim());
		final int DOB_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DOB_POSITION").trim());
		final int MOBILENM_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "MOBILENM_POSITION").trim());
		final int EMAIL_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EMAIL_POSITION").trim());
		final int LASTSTOREFILLEDAT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LASTSTOREFILLEDAT_POSITION").trim());
		final int CITY_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CITY_POSITION").trim());
		final int STATE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "STATE_POSITION").trim());
		final int POSTALCODE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "POSTALCODE_POSITION").trim());
		final int INDICATIONCONHEARTFAILURE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "INDICATIONCONHEARTFAILURE_POSITION").trim());
		final int INDICATIONSEVEREDIATEBES_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "INDICATIONSEVEREDIATEBES_POSITION").trim());
		final int INDICATIONHYPERLIPIDEMIA_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "INDICATIONHYPERLIPIDEMIA_POSITION").trim());
		final int INDICATIONHYPERTENSION_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "INDICATIONHYPERTENSION_POSITION").trim());
		final int INDICATIONISCHEMICHEARTDISEASE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "INDICATIONISCHEMICHEARTDISEASE_POSITION").trim());
		final int ACCOUNTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ACCOUNTID_POSITION").trim());
		final int GROUPID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "GROUPID_POSITION").trim());
		
		
	//	final int INTERACTIONID_POSITION = Integer.parseInt(Utility
				//.getProperty(folder, finalProduct, "INTERACTIONID_POSITION").trim());
		
		
	
			
		
		String reqString = null;
		String recordType = null;
		
		
		ObjectMapper objectMapper = null;
		MCRequest jsonRequest = new MCRequest();

		MCRequest.RequestPayloadData requestPayloadData = null;

		MCRequest.RequestPayloadData.Data data = null;
		

		
		/*
		 * if (null != recordType && recordType.equalsIgnoreCase("T")) {
		 * reqString = "EOF"; } else {
		 */
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		requestPayloadData = new MCRequest.RequestPayloadData();
		
		  requestMetaData = new MCRequest.RequestMetaData();
		  requestMetaData.setAppName(reqParamArray[APPNAME_POSITION]);
		  requestMetaData.setLineOfBusiness(reqParamArray[
		  LINEOFBUSINESS_POSITION]);
		 
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		data = new MCRequest.RequestPayloadData.Data();

		// Populate Data
		data.setAppName(reqParamArray[APPNAME_POSITION].trim());
		data.setMemberID(reqParamArray[MEMBERID_POSITION].trim());
		data.setMemberSource(reqParamArray[MEMBERSOURCE_POSITION].trim());
		data.setClientID(reqParamArray[CLIENTID_POSITION].trim());
		data.setClientCode(reqParamArray[CLIENTCODE_POSITION].trim());
		data.setFirstName(reqParamArray[FIRSTNAME_POSITION].trim());
		data.setCommMsgReqestID(reqParamArray[COMMMSGREQESTID_POSITION].trim());
		data.setCommAlertID(reqParamArray[COMMALERTID_POSITION].trim());
		data.setCommAlertName(reqParamArray[COMMALERTNAME_POSITION].trim());
		data.setCommDeliveryChannel(reqParamArray[COMMDELIVERYCHANNEL_POSITION].trim());
		data.setCommContentType(reqParamArray[COMMCONTENTTYPE_POSITION].trim());
		data.setCommContactInfo(reqParamArray[COMMCONTACTINFO_POSITION].trim());
		data.setCommSenderInfo(reqParamArray[COMMSENDERINFO_POSITION].trim());
		data.setCommSubject(reqParamArray[COMMSUBJECT_POSITION].trim());
		data.setFileID(reqParamArray[FILEID_POSITION].trim());
		data.setCampaignID(reqParamArray[CAMPAIGNID_POSITION].trim());
		data.setClientSet(reqParamArray[CLIENTSET_POSITION].trim());
		data.setLastName(reqParamArray[LASTNAME_POSITION].trim());
		data.setPlanName(reqParamArray[PLANNAME_POSITION].trim());
		data.setDocumentName(reqParamArray[DOCUMENTNAME_POSITION].trim());
		data.setDocTypeCode(reqParamArray[DOCTYPECODE_POSITION].trim());
		data.setLongURL(reqParamArray[LONGURL_POSITION].trim());
		data.setExternalID(reqParamArray[EXTERNALID_POSITION].trim());
		data.setContentID(reqParamArray[CONTENTID_POSITION].trim());
		data.setLob(reqParamArray[LINEOFBUSINESS_POSITION].trim());
		data.setParentMessageID(reqParamArray[PARENTMESSAGEID_POSITION].trim());
		data.setSubTopicID(reqParamArray[SUBTOPICID_POSITION].trim());
		data.setFolderType(reqParamArray[FOLDERTYPE_POSITION].trim());
		data.setSenderName(reqParamArray[SENDERNAME_POSITION].trim());
		data.setRecipientName(reqParamArray[RECIPIENTNAME_POSITION].trim());
		data.setDeliveryStatus(reqParamArray[DELIVERYSTATUS_POSITION].trim());
		data.setFormFields(reqParamArray[FORMFIELDS_POSITION].trim());
		data.setEffectiveDate(reqParamArray[EFFECTIVEDATE_POSITION].trim());
		data.setExpirationDate(reqParamArray[EXPIRATIONDATE_POSITION].trim());
		data.setSentDate(reqParamArray[SENTDATE_POSITION].trim());
		data.setReceivedDate(reqParamArray[RECEIVEDATE_POSITION].trim());
		data.setOrigin(reqParamArray[ORIGIN_POSITION].trim());
		data.setEventName(reqParamArray[EVENTNAME_POSITION].trim());
		data.setAlertSourceSystem(reqParamArray[ALERTSOURCESYSTEM_POSITION].trim());
		data.setRequestId(reqParamArray[REQUESTID_POSITION].trim());
		data.setVaultEnabled(reqParamArray[VAULTENABLED_POSITION].trim());
		data.setOrderNumber(reqParamArray[ORDERNUMBER_POSITION].trim());
		data.setLogCHV(reqParamArray[LOGCHV_POSITION].trim());
		data.setContractID(reqParamArray[CONTRACTID_POSITION].trim());
		data.setLanguageIndicator(reqParamArray[LANGUAGEINDICATOR_POSITION].trim());
		data.setPbpID(reqParamArray[PBPID_POSITION].trim());
		
		data.setRxcPatID(reqParamArray[RXPATID_POSITION].trim());
		data.setRxTiedInd(reqParamArray[RXTIEDID_POSITION].trim());
		data.setSsEnrlmInd(reqParamArray[SSENRLMIND_POSITION].trim());
		data.setRdyFillEnrlmInd(reqParamArray[RDYFILLENRLMIND_POSITION].trim());
		data.setCrgvrInd(reqParamArray[CRGVRIND_POSITION].trim());
		data.setTemplateType(reqParamArray[TEMPLATETYPE_POSITION].trim());
		data.setTemplateVersion(reqParamArray[TEMPLATEVERSION_POSITION].trim());
		data.setTotalActiveMaintRxs(reqParamArray[TOTALACTIVEMIANTRXS_POSITION].trim());
		data.setTotalActiveRxs(reqParamArray[TOTALACTIVERXS_POSITION].trim());
		data.setPredictedPdcVal(reqParamArray[PREDICTEDPDCVAL_POSITION].trim());
		data.setDOB(reqParamArray[DOB_POSITION].trim());
		data.setMobileNM(reqParamArray[MOBILENM_POSITION].trim());
		data.setEmail(reqParamArray[EMAIL_POSITION].trim());
		data.setLastStoreFilledAt(reqParamArray[LASTSTOREFILLEDAT_POSITION].trim());
		data.setPostalCode(reqParamArray[POSTALCODE_POSITION].trim());
		data.setIndicationConHeartFailure(reqParamArray[INDICATIONCONHEARTFAILURE_POSITION].trim());
		data.setIndicationSevereDiatebes(reqParamArray[INDICATIONSEVEREDIATEBES_POSITION].trim());
		data.setIndicationHyperLipidemia(reqParamArray[INDICATIONHYPERLIPIDEMIA_POSITION].trim());
		data.setIndicationHypertension(reqParamArray[INDICATIONHYPERTENSION_POSITION].trim());
		data.setIndicationIschemicHeartDisease(reqParamArray[INDICATIONISCHEMICHEARTDISEASE_POSITION].trim());
		data.setEmail(reqParamArray[EMAIL_POSITION].trim());
		
		data.setEmail(reqParamArray[EMAIL_POSITION].trim());
		data.setAccountID(reqParamArray[ACCOUNTID_POSITION].trim());
		data.setGroupID(reqParamArray[GROUPID_POSITION].trim());
		data.setAddress(reqParamArray[ADDRESS_POSITION].trim());
		data.setCity(reqParamArray[CITY_POSITION].trim());
		data.setState(reqParamArray[STATE_POSITION].trim());
		
	
        
        	 

		requestPayloadData.setData(data);
		jsonRequest.setRequestMetaData(requestMetaData);
		jsonRequest.setRequestPayloadData(requestPayloadData);

		reqString = objectMapper.writeValueAsString(jsonRequest);

	
		return reqString;
	}

}
