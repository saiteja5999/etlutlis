package com.cvshealth.dep.etlutils.hee;

public class HeeRequestData {
	

private String HeeRequestData;

	

	public String getHeeRequestData() {
	return HeeRequestData;
}



public void setHeeRequestData(String heeRequestData) {
	HeeRequestData = heeRequestData;
}



@Override
public String toString() {
	return "HeeRequestData [HeeRequestData=" + HeeRequestData + "]";
}



	

}
