package com.cvshealth.dep.etlutils.usps;

import java.io.Serializable;

/**
 * Notification Service JSON request Model
 * 
 * @author CVSHealth
 */
public class UspsRequest implements Serializable {

	private static final long serialVersionUID = -4187537354799171017L;

	private UspsRequest.RequestMetaData requestMetaData = null;
	private UspsRequest.RequestPayloadData requestPayloadData = null;

	@Override
	public String toString() {
		return "UspsRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}

	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	public UspsRequest.RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}

	public void setRequestPayloadData(
			UspsRequest.RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}

	static class Data {
		private String authType = "APP";
		private String eventName = "RxExpress_NDDCarrierPickedUp/RxExpress_NDDCarrierDelivered/RxExpress_NDDAvailableForPickUp/RxExpress_InTransit";
		private String channelID = "8888888888";
		private String channelType = "Mobile";
		private String memberID = "USPS";
		private String memberType = "Carrier";

		public String getEventName() {
			return eventName;
		}

		public void setEventName(String eventName) {
			this.eventName = eventName;
		}

		public String getChannelID() {
			return channelID;
		}

		public void setChannelID(String channelID) {
			this.channelID = channelID;
		}

		public String getChannelType() {
			return channelType;
		}

		public void setChannelType(String channelType) {
			this.channelType = channelType;
		}

		public String getMemberID() {
			return memberID;
		}

		public void setMemberID(String memberID) {
			this.memberID = memberID;
		}

		public String getMemberType() {
			return memberType;
		}

		public void setMemberType(String memberType) {
			this.memberType = memberType;
		}

		@Override
		public String toString() {
			return "Data [authType=" + authType + ", eventName=" + eventName
					+ ", channelID=" + channelID + ", channelType="
					+ channelType + ", memberID=" + memberID + ", memberType="
					+ memberType + "]";
		}
	}

	static class AdditionalData {
		private String version = null;
		private String trackNumber = null;
		private String fileNumber = null;
		private String mailerID = null;
		private String mailerName = null;

		private String destinationZip = null;
		private String destinationZip4 = null;
		private String scanFacilityZip = null;
		private String scanFacilityName = null;
		private String eventCode = null;

		private String eventName = null;
		private String eventDate = null;
		private String eventTime = null;
		private String ownerMailerID = null;
		private String custReferenceNumber = null;

		private String destCountryCode = null;
		private String recipientName = null;
		private String originalLabel = null;
		private String unitMeasureCode = null;
		private String weight = null;

		private String guarDeliveryDate = null;
		private String guarDeliveryTime = null;
		private String managerMailerID = null;
		private String scheduledDeliveryDate = null;
		private String activityTimeStamp = null;

		public String getVersion() {
			return version;
		}

		public void setVersion(String version) {
			this.version = version;
		}

		public String getTrackNumber() {
			return trackNumber;
		}

		public void setTrackNumber(String trackNumber) {
			this.trackNumber = trackNumber;
		}

		public String getFileNumber() {
			return fileNumber;
		}

		public void setFileNumber(String fileNumber) {
			this.fileNumber = fileNumber;
		}

		public String getMailerID() {
			return mailerID;
		}

		public void setMailerID(String mailerID) {
			this.mailerID = mailerID;
		}

		public String getMailerName() {
			return mailerName;
		}

		public void setMailerName(String mailerName) {
			this.mailerName = mailerName;
		}

		public String getDestinationZip() {
			return destinationZip;
		}

		public void setDestinationZip(String destinationZip) {
			this.destinationZip = destinationZip;
		}

		public String getDestinationZip4() {
			return destinationZip4;
		}

		public void setDestinationZip4(String destinationZip4) {
			this.destinationZip4 = destinationZip4;
		}

		public String getScanFacilityZip() {
			return scanFacilityZip;
		}

		public void setScanFacilityZip(String scanFacilityZip) {
			this.scanFacilityZip = scanFacilityZip;
		}

		public String getScanFacilityName() {
			return scanFacilityName;
		}

		public void setScanFacilityName(String scanFacilityName) {
			this.scanFacilityName = scanFacilityName;
		}

		public String getEventCode() {
			return eventCode;
		}

		public void setEventCode(String eventCode) {
			this.eventCode = eventCode;
		}

		public String getEventName() {
			return eventName;
		}

		public void setEventName(String eventName) {
			this.eventName = eventName;
		}

		public String getEventDate() {
			return eventDate;
		}

		public void setEventDate(String eventDate) {
			this.eventDate = eventDate;
		}

		public String getEventTime() {
			return eventTime;
		}

		public void setEventTime(String eventTime) {
			this.eventTime = eventTime;
		}

		public String getOwnerMailerID() {
			return ownerMailerID;
		}

		public void setOwnerMailerID(String ownerMailerID) {
			this.ownerMailerID = ownerMailerID;
		}

		public String getCustReferenceNumber() {
			return custReferenceNumber;
		}

		public void setCustReferenceNumber(String custReferenceNumber) {
			this.custReferenceNumber = custReferenceNumber;
		}

		public String getDestCountryCode() {
			return destCountryCode;
		}

		public void setDestCountryCode(String destCountryCode) {
			this.destCountryCode = destCountryCode;
		}

		public String getRecipientName() {
			return recipientName;
		}

		public void setRecipientName(String recipientName) {
			this.recipientName = recipientName;
		}

		public String getOriginalLabel() {
			return originalLabel;
		}

		public void setOriginalLabel(String originalLabel) {
			this.originalLabel = originalLabel;
		}

		public String getUnitMeasureCode() {
			return unitMeasureCode;
		}

		public void setUnitMeasureCode(String unitMeasureCode) {
			this.unitMeasureCode = unitMeasureCode;
		}

		public String getWeight() {
			return weight;
		}

		public void setWeight(String weight) {
			this.weight = weight;
		}

		public String getGuarDeliveryDate() {
			return guarDeliveryDate;
		}

		public void setGuarDeliveryDate(String guarDeliveryDate) {
			this.guarDeliveryDate = guarDeliveryDate;
		}

		public String getGuarDeliveryTime() {
			return guarDeliveryTime;
		}

		public void setGuarDeliveryTime(String guarDeliveryTime) {
			this.guarDeliveryTime = guarDeliveryTime;
		}

		public String getManagerMailerID() {
			return managerMailerID;
		}

		public void setManagerMailerID(String managerMailerID) {
			this.managerMailerID = managerMailerID;
		}

		public String getScheduledDeliveryDate() {
			return scheduledDeliveryDate;
		}

		public void setScheduledDeliveryDate(String scheduledDeliveryDate) {
			this.scheduledDeliveryDate = scheduledDeliveryDate;
		}

		public String getActivityTimeStamp() {
			return activityTimeStamp;
		}

		public void setActivityTimeStamp(String activityTimeStamp) {
			this.activityTimeStamp = activityTimeStamp;
		}

		public void setActivityTimeStamp(String date, String time, String offset) {
			if (date.length() == 8) {
				String year = date.substring(0, 4);
				String month = date.substring(4, 6);
				String day = date.substring(6);
				date = year + "-" + month + "-" + day;
			}
			if (time.length() >= 4) {
				String hour = time.substring(0, 2);
				String minute = time.substring(2, 4);
				time = hour + ":" + minute + ":00.000";
			}
			this.activityTimeStamp = date + "T" + time + offset + ":00";
		}

		@Override
		public String toString() {
			return "AdditionalData [version=" + version + ", trackNumber="
					+ trackNumber + ", fileNumber=" + fileNumber
					+ ", mailerID=" + mailerID + ", mailerName=" + mailerName
					+ ", destinationZip=" + destinationZip
					+ ", destinationZip4=" + destinationZip4
					+ ", scanFacilityZip=" + scanFacilityZip
					+ ", scanFacilityName=" + scanFacilityName + ", eventCode="
					+ eventCode + ", eventName=" + eventName + ", eventDate="
					+ eventDate + ", eventTime=" + eventTime
					+ ", ownerMailerID=" + ownerMailerID
					+ ", custReferenceNumber=" + custReferenceNumber
					+ ", destCountryCode=" + destCountryCode
					+ ", recipientName=" + recipientName + ", originalLabel="
					+ originalLabel + ", unitMeasureCode=" + unitMeasureCode
					+ ", weight=" + weight + ", guarDeliveryDate="
					+ guarDeliveryDate + ", guarDeliveryTime="
					+ guarDeliveryTime + ", managerMailerID=" + managerMailerID
					+ ", scheduledDeliveryDate=" + scheduledDeliveryDate
					+ ", activityTimeStamp=" + activityTimeStamp + "]";
		}

	}

	static class RequestPayloadData {
		private Data data = null;
		private AdditionalData additionalData = null;

		public Data getData() {
			return data;
		}

		public void setData(Data data) {
			this.data = data;
		}

		public AdditionalData getAdditionalData() {
			return additionalData;
		}

		public void setAdditionalData(AdditionalData additionalData) {
			this.additionalData = additionalData;
		}

	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */
	static class RequestMetaData {
		private String appName = null;
		private String lineOfBusiness = null;
		private String conversationID = null;

		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		public String getConversationID() {
			return conversationID;
		}

		public void setConversationID(String conversationID) {
			this.conversationID = conversationID;
		}

		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", conversationID=" + conversationID
					+ "]";
		}

	}
}