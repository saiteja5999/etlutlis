package com.cvshealth.dep.etlutils.mc;

import java.io.Serializable;
import java.util.List;





import com.cvshealth.dep.etlutils.mc.MCRequest;



public class MCRequest implements Serializable {

	private static final long serialVersionUID = -4187537354799171017L;

	

	private RequestMetaData requestMetaData = null;
	private RequestPayloadData requestPayloadData = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "MCJSONRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}

	/**
	 * @return the requestMetaData
	 */
	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	/**
	 * @param requestMetaData
	 *            the requestMetaData to set
	 */
	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	/**
	 * @return the requestPayloadData
	 */
	public RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}

	/**
	 * @param requestPayloadData
	 *            the requestPayloadData to set
	 */
	public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */
	public static class RequestMetaData {
		private String appName = "";
		private String lineOfBusiness = "ECCM";
		private String conversationID = "";
	

		

		/**
		 * @return the appName
		 */
		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		/**
		 * @return the conversationID
		 */
		public String getConversationID() {
			return conversationID;
		}

		/**
		 * @param conversationID
		 *            the conversationID to set
		 */
		public void setConversationID(String conversationID) {
			this.conversationID = conversationID;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", conversationID=" + conversationID
					+ "]";
		}
	}

	public static class RequestPayloadData {
		
		private Data data = null;
		
		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		
		/**
		 * @return the data
		 */
		public Data getData() {
			return data;
		}

		/**
		 * @param data
		 *            the data to set
		 */
		public void setData(Data data) {
			this.data = data;
		}
		@Override
		public String toString() {
			return "RequestPayloadData [data=" + data + "]";
		}



		/**
		 * Data
		 * 
		 * @author CVSHealth
		 */
		public static class Data {
			

			private String appName= "";
			private String memberID = "";
			private String memberSource = "";
			private String clientID = "";
			private String clientCode = "";
			private String commMsgReqestID = "";
			private String commAlertID = "";
			private String commAlertName = "";
			private String commDeliveryChannel = "";
			private String commContentType = "";
			private String commContactInfo = "";
			private String commSenderInfo = "";
			private String commSubject = "";
			private String clientSet="";
			private String firstName= "";
			private String lastName= "";
			private String planName="";
			private String documentName= "";
			private String docTypeCode="";
			private String campaignID= "";
			private String fileID ="";
			private String lob="";
			private String longURL= "";
			private String externalID= "";
			private String contentID="";
			private String parentMessageID="";
			private String subTopicID="";
			private String folderType= "";
			private String senderName="";
			private String recipientName= "";
			private String deliveryStatus ="";
			private String formFields= "";
			private String effectiveDate="";
			private String expirationDate= "";
			private String sentDate="";
			private String receivedDate="";
			private String origin= "";
			private String eventName="";
			private String requestId="";
			private String alertSourceSystem="";
			private String orderNumber="";
			private String vaultEnabled="";
			private String logCHV="";
			private String contractID="";
			private String languageIndicator="";
			private String pbpID="";
			private String AccountID="";
			private String GroupID="";
			private String rxcPatID="";
		    private String rxTiedInd="";
		    private String ssEnrlmInd="";
		    private String rdyFillEnrlmInd="";
		    private String crgvrInd="";
		    private String templateType="";
		    private String TemplateVersion="";
		    private String totalActiveMaintRxs="";
			private String totalActiveRxs="";
			private String predictedPdcVal="";
			private String DOB="";
			private String MobileNM="";
			private String email="";
			private String lastStoreFilledAt="";
			private String address="";
			private String city="";
			private String state="";
			private String postalCode="";
			private String indicationConHeartFailure="";
			private String indicationSevereDiatebes="";
			private String indicationHyperLipidemia="";
			private String indicationHypertension="";
			private String indicationIschemicHeartDisease="";
			
			public String getAppName() {
				return appName;
			}

			public void setAppName(String appName) {
				this.appName = appName;
			}

			public String getMemberID() {
				return memberID;
			}

			public void setMemberID(String memberID) {
				this.memberID = memberID;
			}

			public String getMemberSource() {
				return memberSource;
			}

			public void setMemberSource(String memberSource) {
				this.memberSource = memberSource;
			}

			public String getClientID() {
				return clientID;
			}

			public void setClientID(String clientID) {
				this.clientID = clientID;
			}

			public String getClientCode() {
				return clientCode;
			}

			public void setClientCode(String clientCode) {
				this.clientCode = clientCode;
			}

			public String getCommMsgReqestID() {
				return commMsgReqestID;
			}

			public void setCommMsgReqestID(String commMsgReqestID) {
				this.commMsgReqestID = commMsgReqestID;
			}

			public String getCommAlertID() {
				return commAlertID;
			}

			public void setCommAlertID(String commAlertID) {
				this.commAlertID = commAlertID;
			}

			public String getCommAlertName() {
				return commAlertName;
			}

			public void setCommAlertName(String commAlertName) {
				this.commAlertName = commAlertName;
			}

			public String getCommDeliveryChannel() {
				return commDeliveryChannel;
			}

			public void setCommDeliveryChannel(String commDeliveryChannel) {
				this.commDeliveryChannel = commDeliveryChannel;
			}

			public String getCommContentType() {
				return commContentType;
			}

			public void setCommContentType(String commContentType) {
				this.commContentType = commContentType;
			}

			public String getCommContactInfo() {
				return commContactInfo;
			}

			public void setCommContactInfo(String commContactInfo) {
				this.commContactInfo = commContactInfo;
			}

			public String getCommSenderInfo() {
				return commSenderInfo;
			}

			public void setCommSenderInfo(String commSenderInfo) {
				this.commSenderInfo = commSenderInfo;
			}

			public String getCommSubject() {
				return commSubject;
			}

			public void setCommSubject(String commSubject) {
				this.commSubject = commSubject;
			}

			public String getClientSet() {
				return clientSet;
			}

			public void setClientSet(String clientSet) {
				this.clientSet = clientSet;
			}

			public String getFirstName() {
				return firstName;
			}

			public void setFirstName(String firstName) {
				this.firstName = firstName;
			}

			public String getLastName() {
				return lastName;
			}

			public void setLastName(String lastName) {
				this.lastName = lastName;
			}

			public String getPlanName() {
				return planName;
			}

			public void setPlanName(String planName) {
				this.planName = planName;
			}

			public String getDocumentName() {
				return documentName;
			}

			public void setDocumentName(String documentName) {
				this.documentName = documentName;
			}

			public String getDocTypeCode() {
				return docTypeCode;
			}

			public void setDocTypeCode(String docTypeCode) {
				this.docTypeCode = docTypeCode;
			}

			public String getCampaignID() {
				return campaignID;
			}

			public void setCampaignID(String campaignID) {
				this.campaignID = campaignID;
			}

			public String getFileID() {
				return fileID;
			}

			public void setFileID(String fileID) {
				this.fileID = fileID;
			}

			public String getLob() {
				return lob;
			}

			public void setLob(String lob) {
				this.lob = lob;
			}

			public String getLongURL() {
				return longURL;
			}

			public void setLongURL(String longURL) {
				this.longURL = longURL;
			}

			public String getExternalID() {
				return externalID;
			}

			public void setExternalID(String externalID) {
				this.externalID = externalID;
			}

			public String getContentID() {
				return contentID;
			}

			public void setContentID(String contentID) {
				this.contentID = contentID;
			}

			public String getParentMessageID() {
				return parentMessageID;
			}

			public void setParentMessageID(String parentMessageID) {
				this.parentMessageID = parentMessageID;
			}

			public String getSubTopicID() {
				return subTopicID;
			}

			public void setSubTopicID(String subTopicID) {
				this.subTopicID = subTopicID;
			}

			public String getFolderType() {
				return folderType;
			}

			public void setFolderType(String folderType) {
				this.folderType = folderType;
			}

			public String getSenderName() {
				return senderName;
			}

			public void setSenderName(String senderName) {
				this.senderName = senderName;
			}

			public String getRecipientName() {
				return recipientName;
			}

			public void setRecipientName(String recipientName) {
				this.recipientName = recipientName;
			}

			public String getDeliveryStatus() {
				return deliveryStatus;
			}

			public void setDeliveryStatus(String deliveryStatus) {
				this.deliveryStatus = deliveryStatus;
			}

			public String getFormFields() {
				return formFields;
			}

			public void setFormFields(String formFields) {
				this.formFields = formFields;
			}

			public String getEffectiveDate() {
				return effectiveDate;
			}

			public void setEffectiveDate(String effectiveDate) {
				this.effectiveDate = effectiveDate;
			}

			public String getExpirationDate() {
				return expirationDate;
			}

			public void setExpirationDate(String expirationDate) {
				this.expirationDate = expirationDate;
			}

			public String getSentDate() {
				return sentDate;
			}

			public void setSentDate(String sentDate) {
				this.sentDate = sentDate;
			}

			public String getReceivedDate() {
				return receivedDate;
			}

			public void setReceivedDate(String receivedDate) {
				this.receivedDate = receivedDate;
			}

			public String getOrigin() {
				return origin;
			}

			public void setOrigin(String origin) {
				this.origin = origin;
			}

			public String getEventName() {
				return eventName;
			}

			public void setEventName(String eventName) {
				this.eventName = eventName;
			}

			public String getRequestId() {
				return requestId;
			}

			public void setRequestId(String requestId) {
				this.requestId = requestId;
			}

			public String getAlertSourceSystem() {
				return alertSourceSystem;
			}

			public void setAlertSourceSystem(String alertSourceSystem) {
				this.alertSourceSystem = alertSourceSystem;
			}

			public String getOrderNumber() {
				return orderNumber;
			}

			public void setOrderNumber(String orderNumber) {
				this.orderNumber = orderNumber;
			}

			public String getVaultEnabled() {
				return vaultEnabled;
			}

			public void setVaultEnabled(String vaultEnabled) {
				this.vaultEnabled = vaultEnabled;
			}

			public String getLogCHV() {
				return logCHV;
			}

			public void setLogCHV(String logCHV) {
				this.logCHV = logCHV;
			}

			public String getContractID() {
				return contractID;
			}

			public void setContractID(String contractID) {
				this.contractID = contractID;
			}

			public String getLanguageIndicator() {
				return languageIndicator;
			}

			public void setLanguageIndicator(String languageIndicator) {
				this.languageIndicator = languageIndicator;
			}

			public String getPbpID() {
				return pbpID;
			}

			public void setPbpID(String pbpID) {
				this.pbpID = pbpID;
			}

			public String getAccountID() {
				return AccountID;
			}

			public void setAccountID(String accountID) {
				AccountID = accountID;
			}

			public String getGroupID() {
				return GroupID;
			}

			public void setGroupID(String groupID) {
				GroupID = groupID;
			}

			public String getRxcPatID() {
				return rxcPatID;
			}

			public void setRxcPatID(String rxcPatID) {
				this.rxcPatID = rxcPatID;
			}

			public String getRxTiedInd() {
				return rxTiedInd;
			}

			public void setRxTiedInd(String rxTiedInd) {
				this.rxTiedInd = rxTiedInd;
			}

			public String getSsEnrlmInd() {
				return ssEnrlmInd;
			}

			public void setSsEnrlmInd(String ssEnrlmInd) {
				this.ssEnrlmInd = ssEnrlmInd;
			}

			public String getRdyFillEnrlmInd() {
				return rdyFillEnrlmInd;
			}

			public void setRdyFillEnrlmInd(String rdyFillEnrlmInd) {
				this.rdyFillEnrlmInd = rdyFillEnrlmInd;
			}

			public String getCrgvrInd() {
				return crgvrInd;
			}

			public void setCrgvrInd(String crgvrInd) {
				this.crgvrInd = crgvrInd;
			}

			public String getTemplateType() {
				return templateType;
			}

			public void setTemplateType(String templateType) {
				this.templateType = templateType;
			}

			public String getTemplateVersion() {
				return TemplateVersion;
			}

			public void setTemplateVersion(String templateVersion) {
				TemplateVersion = templateVersion;
			}

			public String getTotalActiveMaintRxs() {
				return totalActiveMaintRxs;
			}

			public void setTotalActiveMaintRxs(String totalActiveMaintRxs) {
				this.totalActiveMaintRxs = totalActiveMaintRxs;
			}

			public String getTotalActiveRxs() {
				return totalActiveRxs;
			}

			public void setTotalActiveRxs(String totalActiveRxs) {
				this.totalActiveRxs = totalActiveRxs;
			}

			public String getPredictedPdcVal() {
				return predictedPdcVal;
			}

			public void setPredictedPdcVal(String predictedPdcVal) {
				this.predictedPdcVal = predictedPdcVal;
			}

			public String getDOB() {
				return DOB;
			}

			public void setDOB(String dOB) {
				DOB = dOB;
			}

			public String getMobileNM() {
				return MobileNM;
			}

			public void setMobileNM(String mobileNM) {
				MobileNM = mobileNM;
			}

			public String getEmail() {
				return email;
			}

			public void setEmail(String email) {
				this.email = email;
			}

			public String getLastStoreFilledAt() {
				return lastStoreFilledAt;
			}

			public void setLastStoreFilledAt(String lastStoreFilledAt) {
				this.lastStoreFilledAt = lastStoreFilledAt;
			}

			public String getAddress() {
				return address;
			}

			public void setAddress(String address) {
				this.address = address;
			}

			public String getCity() {
				return city;
			}

			public void setCity(String city) {
				this.city = city;
			}

			public String getState() {
				return state;
			}

			public void setState(String state) {
				this.state = state;
			}

			public String getPostalCode() {
				return postalCode;
			}

			public void setPostalCode(String postalCode) {
				this.postalCode = postalCode;
			}

			public String getIndicationConHeartFailure() {
				return indicationConHeartFailure;
			}

			public void setIndicationConHeartFailure(String indicationConHeartFailure) {
				this.indicationConHeartFailure = indicationConHeartFailure;
			}

			public String getIndicationSevereDiatebes() {
				return indicationSevereDiatebes;
			}

			public void setIndicationSevereDiatebes(String indicationSevereDiatebes) {
				this.indicationSevereDiatebes = indicationSevereDiatebes;
			}

			public String getIndicationHyperLipidemia() {
				return indicationHyperLipidemia;
			}

			public void setIndicationHyperLipidemia(String indicationHyperLipidemia) {
				this.indicationHyperLipidemia = indicationHyperLipidemia;
			}

			public String getIndicationHypertension() {
				return indicationHypertension;
			}

			public void setIndicationHypertension(String indicationHypertension) {
				this.indicationHypertension = indicationHypertension;
			}

			public String getIndicationIschemicHeartDisease() {
				return indicationIschemicHeartDisease;
			}

			public void setIndicationIschemicHeartDisease(
					String indicationIschemicHeartDisease) {
				this.indicationIschemicHeartDisease = indicationIschemicHeartDisease;
			}

			@Override
			public String toString() {
				return "Data [appName=" + appName + ", memberID=" + memberID
						+ ", memberSource=" + memberSource + ", clientID="
						+ clientID + ", clientCode=" + clientCode
						+ ", commMsgReqestID=" + commMsgReqestID
						+ ", commAlertID=" + commAlertID + ", commAlertName="
						+ commAlertName + ", commDeliveryChannel="
						+ commDeliveryChannel + ", commContentType="
						+ commContentType + ", commContactInfo="
						+ commContactInfo + ", commSenderInfo="
						+ commSenderInfo + ", commSubject=" + commSubject
						+ ", clientSet=" + clientSet + ", firstName="
						+ firstName + ", lastName=" + lastName + ", planName="
						+ planName + ", documentName=" + documentName
						+ ", docTypeCode=" + docTypeCode + ", campaignID="
						+ campaignID + ", fileID=" + fileID + ", lob=" + lob
						+ ", longURL=" + longURL + ", externalID=" + externalID
						+ ", contentID=" + contentID + ", parentMessageID="
						+ parentMessageID + ", subTopicID=" + subTopicID
						+ ", folderType=" + folderType + ", senderName="
						+ senderName + ", recipientName=" + recipientName
						+ ", deliveryStatus=" + deliveryStatus
						+ ", formFields=" + formFields + ", effectiveDate="
						+ effectiveDate + ", expirationDate=" + expirationDate
						+ ", sentDate=" + sentDate + ", receivedDate="
						+ receivedDate + ", origin=" + origin + ", eventName="
						+ eventName + ", requestId=" + requestId
						+ ", alertSourceSystem=" + alertSourceSystem
						+ ", orderNumber=" + orderNumber + ", vaultEnabled="
						+ vaultEnabled + ", logCHV=" + logCHV + ", contractID="
						+ contractID + ", languageIndicator="
						+ languageIndicator + ", pbpID=" + pbpID
						+ ", AccountID=" + AccountID + ", GroupID=" + GroupID
						+ ", rxcPatID=" + rxcPatID + ", rxTiedInd=" + rxTiedInd
						+ ", ssEnrlmInd=" + ssEnrlmInd + ", rdyFillEnrlmInd="
						+ rdyFillEnrlmInd + ", crgvrInd=" + crgvrInd
						+ ", templateType=" + templateType
						+ ", TemplateVersion=" + TemplateVersion
						+ ", totalActiveMaintRxs=" + totalActiveMaintRxs
						+ ", totalActiveRxs=" + totalActiveRxs
						+ ", predictedPdcVal=" + predictedPdcVal + ", DOC="
						+ DOB + ", MobileNM=" + MobileNM + ", email=" + email
						+ ", lastStoreFilledAt=" + lastStoreFilledAt
						+ ", address=" + address + ", city=" + city
						+ ", state=" + state + ", postalCode=" + postalCode
						+ ", indicationConHeartFailure="
						+ indicationConHeartFailure
						+ ", indicationSevereDiatebes="
						+ indicationSevereDiatebes
						+ ", indicationHyperLipidemia="
						+ indicationHyperLipidemia
						+ ", indicationHypertension=" + indicationHypertension
						+ ", indicationIschemicHeartDisease="
						+ indicationIschemicHeartDisease + "]";
			}

			
			
			}
			
			
			
	
			
				
	
		}

		
	}

