package com.cvshealth.dep.etlutils.securechat;

import java.util.List;

/*
 * patients data
 */

public class Patients {
	private String patientId = null;
	private String phone = null;
	private String email = null;
	private List<MessageList> messageList = null;

	public String getPatientId() {
		return patientId;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String Phone) {
		this.phone = Phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String Email) {
		this.email = Email;
	}

	public List<MessageList> getMessageList() {
		return messageList;
	}

	public void setMessageList(List<MessageList> messageList) {
		this.messageList = messageList;
	}

}
