package com.cvshealth.dep.etlutils.securechat;

import java.util.List;
import java.util.concurrent.BlockingQueue;

public class SecurechatProducer implements Runnable {

	private BlockingQueue<String> queue;
	private List<String> lines;

	public SecurechatProducer(BlockingQueue<String> q, List<String> lines) {
		this.queue = q;
		this.lines = lines;

	}

	public void run() {
		for (String line : lines) {
			try {
				System.out.println(line);
				queue.put(line);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		System.out.println("Producer STOPPED.");
	}
}