package com.cvshealth.dep.etlutils.securechat;

public class MessageList {
	private String messageCategory = null;
	private String messageId = null;
	private String messageText = null;
	private String secureMessageText = null;
	private String messageDateTimestamp = null;
	private String messageTopic = null;
	private String campaignId = null;
	private String channelType = null;

	private String leadMessageId = null;
	private String statusResponse = null;
	private String statusReason = null;

	public String getMessageCategory() {
		return messageCategory;
	}

	public void setMessageCategory(String messageCategory) {
		this.messageCategory = messageCategory;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageID) {
		this.messageId = messageID;
	}

	public String getMessageText() {
		return messageText;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public String getSecureMessageText() {
		return secureMessageText;
	}

	public void setSecureMessageText(String secureMessageText) {
		this.secureMessageText = secureMessageText;
	}

	public String getMessageDateTimestamp() {
		return messageDateTimestamp;
	}

	public void setMessageDateTimestamp(String messageDateTimestamp) {
		this.messageDateTimestamp = messageDateTimestamp;
	}

	public String getMessageTopic() {
		return messageTopic;
	}

	public void setMessageTopic(String messageTopic) {
		this.messageTopic = messageTopic;
	}

	public String getCampaignId() {
		return campaignId;
	}

	public void setCampaignId(String campaignId) {
		this.campaignId = campaignId;
	}

	public String getLeadMessageId() {
		return leadMessageId;

	}

	public void setLeadMessageId(String LeadMessageId) {
		this.leadMessageId = LeadMessageId;
	}

	public String getStatusResponse() {
		return statusResponse;
	}

	public void setStatusResponse(String StatusResponse) {
		this.statusResponse = StatusResponse;
	}

	public String getStatusReason() {
		return statusReason;
	}

	public void setStatusReason(String StatusReason) {
		this.statusReason = StatusReason;
	}

	public String getChannelType() {
		return channelType;
	}

	public void setChannelType(String ChannelType) {
		this.channelType = ChannelType;
	}

}
