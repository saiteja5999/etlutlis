package com.cvshealth.dep.etlutils.securechat;

import java.io.FileWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.cvshealth.dep.etlutils.utils.ServiceClient;
import com.cvshealth.dep.etlutils.utils.Utility;

public class SecurechatConsumer implements Runnable {
	private final static Logger infoLogger = Logger.getLogger("securechatinfo");
	private final Logger errorLogger = Logger.getLogger("securechaterror");
	private BlockingQueue<String> _Queue;
	private String finalProduct;
	protected SecurechatRequestBuilder _RequestBuilder;
	private String uri;
	private String logUri;
	private String fieldDelimiter;
	private static String FAILEDRECORDS;
	List<String> failRecords;
	static String SourceSystem;

	public SecurechatConsumer(BlockingQueue<String> q, String env)
			throws Exception {
		this._Queue = q;

		this.finalProduct = SecurechatMain.PRODUCT + "_" + env;
		this.uri = Utility.getProperty(SecurechatMain.PRODUCT, finalProduct,
				"dbpl.uri");
		SecurechatConsumer.SourceSystem = Utility.getProperty(
				SecurechatMain.PRODUCT, finalProduct, "SourceSystem");

		this.FAILEDRECORDS = Utility.getProperty(SecurechatMain.PRODUCT,
				finalProduct, "FAILEDRECORDS");
		this.logUri = Utility.getProperty(SecurechatMain.PRODUCT, finalProduct,
				"logger.uri");
		this.fieldDelimiter = Utility.getProperty(SecurechatMain.PRODUCT,
				finalProduct, "field.delimiter");
	}

	/*
	 * (non-Javadoc) Thread
	 * 
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		String record = "";
		try {
			String msg;

			while (true) {
				msg = _Queue.poll(5, TimeUnit.SECONDS);
				if (msg == null) {
					break;
				}
				record = msg;

				if (msg.startsWith(fieldDelimiter)) {
					msg = msg.substring(1);
				}
				if (msg.endsWith(fieldDelimiter)) {
					msg = msg.substring(0, msg.length() - 1);
				}
				/*
				 * We are buliding the request body and passing to the URL
				 */
				try {
					String[] reqParamArray = msg.split(fieldDelimiter, -1);

					_RequestBuilder = new SecurechatRequestBuilder();

					String reqString = _RequestBuilder
							.getRequest(reqParamArray, finalProduct,
									SecurechatMain.PRODUCT);
					System.out.println("SecurechatRequest=" + reqString);
					Map<String, Object> headers = new HashMap<String, Object>();
					headers.put("content-type", "application/json");
					headers.put("Accept", "application/json");

					String result = ServiceClient.postDataWithHeadersNodejs(
							uri, reqString, headers);

					infoLogger.debug(result);
					System.out.println("SecurechatResponse=" + result);
					JSONObject json = new JSONObject(result);
					String statuscode = json.getString("standardStatusCode");

					if (!(statuscode).equals("CODE_00_SUCCESS")) {
						appendToFile(record + "|" + statuscode);
						// appendToFile(result);
						infoLogger
								.info("please check the file for failed records ");
					}

				} catch (Exception e) {
					e.printStackTrace();
					infoLogger
							.info("SecurechatProcessor | service.execute() | Error while converting record into KafkaRequest"
									+ e.getMessage() + record);

					errorLogger.error(Utility.getStrackTrace(e) + record);
					appendToFile(record + "||" + e);

				}
			}
			System.out.println("Consumer STOPPED.");
		} catch (Exception e) {
			e.printStackTrace();

			infoLogger
					.info("SecurechatProcessor | processRecords() | Error in processing records | "
							+ record + e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e) + record);
			appendToFile(record + "||" + e);
		}
	}

	public static void appendToFile(String records) {

		try {
			String cDate = System.getProperty("current.date.time");
			String newLine = "\n";

			FileWriter file = new FileWriter(FAILEDRECORDS + "failedrecords"
					+ cDate + ".txt", true);

			file.write(records.toString() + newLine);
			// file.write(records.toString());
			file.close();

		} catch (Exception ie) {
			throw new RuntimeException("Could not write Exception to file", ie);
		}
	}
}
