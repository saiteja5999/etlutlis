package com.cvshealth.dep.etlutils.extracare.coupon.esp;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.cvshealth.dep.etlutils.extracare.coupon.esp.CouponRequest.ViewList;
import com.cvshealth.dep.etlutils.utils.Utility;

public class CouponRequestBuilder {
	private final String REFERRER_CD = "D";
	private final Logger infoLogger = Logger.getLogger("couponinfo");
	private final Logger errorLogger = Logger.getLogger("couponerror");

	@SuppressWarnings("null")
	public CouponRequest couponDBPLRequest(String[] reqParamArray,
			String finalProduct, String folder) {
		CouponRequest couponRequest = new CouponRequest();

		String timestamp = null;
		String[] couponParamArray = null;
		if (reqParamArray.length < 2) {
			errorLogger
					.error(" CouponRequestBuilder| couponDBPLRequest() | Service Request : "
							+ reqParamArray[0].toString()
							+ " | Error : "
							+ "Input record doesn't have mandatory parameters");
			return null;
		} else {
			timestamp = reqParamArray[0].trim();
			couponParamArray = reqParamArray[1].split(",");
			if (couponParamArray.length < 2) {
				errorLogger
						.error(" CouponRequestBuilder| couponDBPLRequest() | Service Request : "
								+ reqParamArray.toString()
								+ " | Error : "
								+ "Input record doesn't have mandatory parameters for coupons");

				return null;
			}
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		java.util.Date inputDate = null;
		String outputDate = null;
		try {
			inputDate = sdf.parse(timestamp);
			sdf.applyPattern("yyyyMMddHH:mm:ss-00:00");
			outputDate = sdf.format(inputDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			errorLogger
					.error(" CouponRequestBuilder| couponDBPLRequest() | Service Request : "
							+ reqParamArray.toString()
							+ " | Error : "
							+ Utility.getStrackTrace(e));

			return null;
		}

		// byte[] authBytes =
		// couponParamArray[0].getBytes(StandardCharsets.UTF_8);
		// String encodedECcard = Base64.getEncoder().encodeToString(authBytes);
		Base64 base64 = new Base64();
		String encodedString = couponParamArray[0];
		String encodedECcard = new String(base64.encode(encodedString
				.getBytes()));

		List<CouponRequest.ViewList> viewList = new ArrayList();
		for (int couponCounter = 1; couponCounter < couponParamArray.length; couponCounter++) {
			CouponRequest.ViewList viewCoupon = new CouponRequest.ViewList();
			viewCoupon.setTs(outputDate);
			viewCoupon.setCpnSeqNbr(couponParamArray[couponCounter]);
			viewList.add(viewCoupon);
		}

		couponRequest.setExtraCareCard(encodedECcard);
		couponRequest.setReferrer_cd(REFERRER_CD);
		couponRequest.setViewList(viewList);

		return couponRequest;
	}
}
