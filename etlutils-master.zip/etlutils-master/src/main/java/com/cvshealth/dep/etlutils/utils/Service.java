package com.cvshealth.dep.etlutils.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;

public class Service {

	private static final String USER_AGENT = "Mozilla/5.0";
	private static HttpClient client = HttpClientBuilder.create().build();

	/**
	 * Http POST
	 * 
	 * @param url
	 * @return
	 */
	public static void post(String uri, String app, String json)
			throws Exception {
		List<NameValuePair> urlParameters = null;
		BufferedReader rd = null;
		HttpPost post = null;
		HttpResponse response = null;

		try {
			urlParameters = new ArrayList<NameValuePair>();
			urlParameters.add(new BasicNameValuePair("app", app));
			urlParameters.add(new BasicNameValuePair("json", json));

			post = new HttpPost(uri);
			post.setEntity(new UrlEncodedFormEntity(urlParameters));
			post.setHeader("User-Agent", USER_AGENT);
			response = client.execute(post);

			rd = new BufferedReader(new InputStreamReader(response.getEntity()
					.getContent()));
			StringBuffer result = new StringBuffer();

			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
		} catch (Exception e) {
			throw e;
		} finally {
			post.releaseConnection();
			if (null != rd) {
				rd.close();
			}
		}
	}

	/**
	 * Http POST with headers
	 * 
	 * @param url
	 * @return
	 */
	public static String post(String uri, String app, String json,
			Map<String, String> headers) throws Exception {
		List<NameValuePair> urlParameters = null;
		BufferedReader rd = null;
		HttpPost post = null;
		HttpResponse response = null;
		StringBuffer result = new StringBuffer();
		try {
			urlParameters = new ArrayList<NameValuePair>();
			urlParameters.add(new BasicNameValuePair("app", app));
			urlParameters.add(new BasicNameValuePair("json", json));

			post = new HttpPost(uri);
			//System.out.println("uri=" + uri);
			post.setEntity(new UrlEncodedFormEntity(urlParameters));
			post.setHeader("User-Agent", USER_AGENT);

			// Add the list of headers
			if (null != headers) {
				for (String key : headers.keySet()) {
					post.setHeader(key, headers.get(key));
				}
			}

			response = client.execute(post);

			rd = new BufferedReader(new InputStreamReader(response.getEntity()
					.getContent()));

			String line = "";
			while ((line = rd.readLine()) != null) {
				result.append(line);
			}
			return result.toString();
		} catch (Exception e) {
			throw e;
		} finally {
			post.releaseConnection();
			if (null != rd) {
				rd.close();
			}
		}
	}

	public static class LogRequest implements Serializable {
		private static final long serialVersionUID = 1643157054338887034L;

		private RequestMetaData requestMetaData = null;
		private RequestPayloadData requestPayloadData = null;

		/**
		 * @return the requestMetaData
		 */
		public RequestMetaData getRequestMetaData() {
			return requestMetaData;
		}

		/**
		 * @param requestMetaData
		 *            the requestMetaData to set
		 */
		public void setRequestMetaData(RequestMetaData requestMetaData) {
			this.requestMetaData = requestMetaData;
		}

		/**
		 * @return the requestPayloadData
		 */
		public RequestPayloadData getRequestPayloadData() {
			return requestPayloadData;
		}

		/**
		 * @param requestPayloadData
		 *            the requestPayloadData to set
		 */
		public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
			this.requestPayloadData = requestPayloadData;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "Request [requestMetaData=" + requestMetaData
					+ ", requestPayloadData=" + requestPayloadData + "]";
		}
	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVS Health
	 */
	public static class RequestMetaData implements Serializable {
		private static final long serialVersionUID = 1510351663111949276L;
		private String conversationId = null;

		/**
		 * @return the conversationId
		 */
		public String getConversationId() {
			return conversationId;
		}

		/**
		 * @param conversationId
		 *            the conversationId to set
		 */
		public void setConversationId(String conversationId) {
			this.conversationId = conversationId;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestMetaData [conversationId=" + conversationId + "]";
		}
	}

	/**
	 * RequestPayloadData
	 * 
	 * @author CVS Health
	 */
	public static class RequestPayloadData implements Serializable {
		private static final long serialVersionUID = -5593951171357044297L;
		private String transactionID = null;
		private String service = null;
		private String operation = null;
		private String backendUrl = null;
		private String statusCode = null;
		private String statusDesc = null;
		private String httpStatusCode = null;
		private String responseTime = null;
		private String requestTimeStamp = null;
		private String request = null;
		private String response = null;
		private String responseTimeStamp = null;
		private Error error = null;
		private String fileName = null;

		/**
		 * @return the transactionID
		 */
		public String getTransactionID() {
			return transactionID;
		}

		/**
		 * @param transactionID
		 *            the transactionID to set
		 */
		public void setTransactionID(String transactionID) {
			this.transactionID = transactionID;
		}

		/**
		 * @return the service
		 */
		public String getService() {
			return service;
		}

		/**
		 * @param service
		 *            the service to set
		 */
		public void setService(String service) {
			this.service = service;
		}

		/**
		 * @return the operation
		 */
		public String getOperation() {
			return operation;
		}

		/**
		 * @param operation
		 *            the operation to set
		 */
		public void setOperation(String operation) {
			this.operation = operation;
		}

		/**
		 * @return the backendUrl
		 */
		public String getBackendUrl() {
			return backendUrl;
		}

		/**
		 * @param backendUrl
		 *            the backendUrl to set
		 */
		public void setBackendUrl(String backendUrl) {
			this.backendUrl = backendUrl;
		}

		/**
		 * @return the statusCode
		 */
		public String getStatusCode() {
			return statusCode;
		}

		/**
		 * @param statusCode
		 *            the statusCode to set
		 */
		public void setStatusCode(String statusCode) {
			this.statusCode = statusCode;
		}

		/**
		 * @return the statusDesc
		 */
		public String getStatusDesc() {
			return statusDesc;
		}

		/**
		 * @param statusDesc
		 *            the statusDesc to set
		 */
		public void setStatusDesc(String statusDesc) {
			this.statusDesc = statusDesc;
		}

		/**
		 * @return the httpStatusCode
		 */
		public String getHttpStatusCode() {
			return httpStatusCode;
		}

		/**
		 * @param httpStatusCode
		 *            the httpStatusCode to set
		 */
		public void setHttpStatusCode(String httpStatusCode) {
			this.httpStatusCode = httpStatusCode;
		}

		/**
		 * @return the responseTime
		 */
		public String getResponseTime() {
			return responseTime;
		}

		/**
		 * @param responseTime
		 *            the responseTime to set
		 */
		public void setResponseTime(String responseTime) {
			this.responseTime = responseTime;
		}

		/**
		 * @return the requestTimeStamp
		 */
		public String getRequestTimeStamp() {
			return requestTimeStamp;
		}

		/**
		 * @param requestTimeStamp
		 *            the requestTimeStamp to set
		 */
		public void setRequestTimeStamp(String requestTimeStamp) {
			this.requestTimeStamp = requestTimeStamp;
		}

		/**
		 * @return the request
		 */
		public String getRequest() {
			return request;
		}

		/**
		 * @param request
		 *            the request to set
		 */
		public void setRequest(String request) {
			this.request = request;
		}

		/**
		 * @return the response
		 */
		public String getResponse() {
			return response;
		}

		/**
		 * @param response
		 *            the response to set
		 */
		public void setResponse(String response) {
			this.response = response;
		}

		/**
		 * @return the responseTimeStamp
		 */
		public String getResponseTimeStamp() {
			return responseTimeStamp;
		}

		/**
		 * @param responseTimeStamp
		 *            the responseTimeStamp to set
		 */
		public void setResponseTimeStamp(String responseTimeStamp) {
			this.responseTimeStamp = responseTimeStamp;
		}

		/**
		 * @return the error
		 */
		public Error getError() {
			return error;
		}

		/**
		 * @param error
		 *            the error to set
		 */
		public void setError(Error error) {
			this.error = error;
		}

		/**
		 * @return the fileName
		 */
		public String getFileName() {
			return fileName;
		}

		/**
		 * @param fileName
		 *            the fileName to set
		 */
		public void setFileName(String fileName) {
			this.fileName = fileName;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestPayloadData [transactionID=" + transactionID
					+ ", service=" + service + ", operation=" + operation
					+ ", backendUrl=" + backendUrl + ", statusCode="
					+ statusCode + ", statusDesc=" + statusDesc
					+ ", httpStatusCode=" + httpStatusCode + ", responseTime="
					+ responseTime + ", requestTimeStamp=" + requestTimeStamp
					+ ", request=" + request + ", response=" + response
					+ ", responseTimeStamp=" + responseTimeStamp + ", error="
					+ error + ", fileName=" + fileName + "]";
		}
	}

	public static class Error implements Serializable {
		private static final long serialVersionUID = 1510351663111949276L;
		private String stack = null;

		public Error(String stack) {
			this.stack = stack;
		}

		public String getStack() {
			return stack;
		}

		public void setStack(String stack) {
			this.stack = stack;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "Error [stack=" + stack + "]";
		}
	}
}
