package com.cvshealth.dep.etlutils.medcost;

import java.util.ArrayList;
import java.util.List;


import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.medcost.Data;
import com.cvshealth.dep.etlutils.medcost.TrainRequest;
import com.cvshealth.dep.etlutils.medcost.TrainRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class TrainRequestBuilder implements RequestBuilder {
	private RequestMetaData requestMetaData;

	public TrainRequestBuilder(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	
	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		final int APPNAME_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "APPNAME_POSITION").trim());
		final int LINEOFBUSINESS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "LINEOFBUSINESS_POSITION").trim());

		 final int RXFILLNBR_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "RXFILLNBR_POSITION").trim());
		
		final int ANTREFILLDUEDT_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "ANTREFILLDUEDT_POSITION").trim());
		final int OPPURTUNITYID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "OPPURTUNITYID_POSITION").trim());
		final int OPPTACTIONID_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "OPPTACTIONID_POSITION").trim());
		final int FILLDT_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "FILLDT_POSITION").trim());
		final int CUSTFAMNBR_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "CUSTFAMNBR_POSITION").trim());
		final int CUSTMBRNBR_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "CUSTMBRNBR_POSITION").trim());
		final int RXCDRID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "RXCDRID_POSITION").trim());
		final int RXCPATIENTID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "RXCPATIENTID_POSITION").trim());
		final int RXCPRECID_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "RXCPRECID_POSITION").trim());
		final int CONTRACKTYPE_POSITION = Integer.parseInt(Utility.getProperty(folder,
				finalProduct, "CONTRACKTYPE_POSITION").trim());
		final int DISPNDC_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DISPNDC_POSITION").trim());
		final int DRUGGCNNBR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DRUGGCNNBR_POSITION").trim());
		final int DRUGGPIF_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DRUGGPIF_POSITION").trim());
		final int DRUGGPIE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DRUGGPIE_POSITION").trim());
		
		final int RXCHANNELTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXCHANNELTYPE_POSITION").trim());
		final int RXACTIONCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXACTIONCD_POSITION").trim());
		final int SRCCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SRCCD_POSITION").trim());
		final int PHONENBR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PHONENBR_POSITION").trim());
		final int PGMTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PGMTYPE_POSITION").trim());
		final int OPPTCHANNELTXT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "OPPTCHANNELTXT_POSITION").trim());
		
		final int VISITTCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "VISITTCD_POSITION").trim());
		final int DAYSUPPLYQTY_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DAYSUPPLYQTY_POSITION").trim());
		final int RXEXPDT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXEXPDT_POSITION").trim());
		final int ACTOPPTIND_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ACTOPPTIND_POSITION").trim());
		final int REGTGTDT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "REGTGTDT_POSITION").trim());
		final int TRAINRSNCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "TRAINRSNCD_POSITION").trim());
		final int DELIVERYSTARTTIME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DELIVERYSTARTTIME_POSITION").trim());
		final int DELIVERYPRIORITYNBR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DELIVERYPRIORITYNBR_POSITION").trim());
		final int VERBIAGECD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "VERBIAGECD_POSITION").trim());
		final int DELIVERYMETHOD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "DELIVERYMETHOD_POSITION").trim());
		final int MULTISCRIPTOPPTIND_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "MULTISCRIPTOPPTIND_POSITION").trim());
		
		final int PRECSCRIBERCRGSWAPIND_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PRECSCRIBERCRGSWAPIND_POSITION").trim());
		
		final int READYFILLENRCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "READYFILLENRCD_POSITION").trim());
		
		final int WILDCHAR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "WILDCHAR_POSITION").trim());
			
		final int SRCOPPTCRTDT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SRCOPPTCRTDT_POSITION").trim());
		final int SCRIPTSOPPT_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SCRIPTSOPPT_POSITION").trim());
			
		final int RXMSGSRCCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXMSGSRCCD_POSITION").trim());
		final int RXMSGCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXMSGCD_POSITION").trim());
		final int RXMSGTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXMSGTYPE_POSITION").trim());
		final int OPPTSRCMSGCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "OPPTSRCMSGCD_POSITION").trim());
		final int OPPTMSGCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "OPPTMSGCD_POSITION").trim());
		final int OPPTMSGTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "OPPTMSGTYPE_POSITION").trim());
		final int RXNBR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "RXNBR_POSITION").trim());
		final int STORENBR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "STORENBR_POSITION").trim());
		
		final int SUBPGMCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "SUBPGMCD_POSITION").trim());
		
		final int PGMCD_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "PGMCD_POSITION").trim());
		final int CONDEFSEQNBR_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CONDEFSEQNBR_POSITION").trim());
		
		final int CREATETS_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "CREATETS_POSITION").trim());
		final int EVENTNAME_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "EVENTNAME_POSITION").trim());
		final int ACTIVITYTEMPLATEID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ACTIVITYTEMPLATEID_POSITION").trim());
		final int REQUESTID_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "REQUESTID_POSITION").trim());
		final int ACTIONTYPE_POSITION = Integer.parseInt(Utility
				.getProperty(folder, finalProduct, "ACTIONTYPE_POSITION").trim());
		
		String reqString = null;
		
		
		
		ObjectMapper objectMapper = null;
		TrainRequest jsonRequest = new TrainRequest();

		TrainRequest.RequestPayloadData requestPayloadData = null;

		Data data = null;
	
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		requestPayloadData = new TrainRequest.RequestPayloadData();
		
		  requestMetaData = new TrainRequest.RequestMetaData();
		  requestMetaData.setAppName(reqParamArray[APPNAME_POSITION]);
		  requestMetaData.setLineOfBusiness(reqParamArray[
		  LINEOFBUSINESS_POSITION]);
		 
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		data = new Data();
		
		List<Rows> rows = new ArrayList<Rows>();

			Rows row= new Rows();	 		

		// Populate Data
		row.setRxFillNbr(reqParamArray[RXFILLNBR_POSITION].trim());
		row.setAntRefillDueDt(reqParamArray[ ANTREFILLDUEDT_POSITION].trim());
		row.setOppurtunityID(reqParamArray[OPPURTUNITYID_POSITION].trim());
		row.setOpptActionID(reqParamArray[OPPTACTIONID_POSITION].trim());
		row.setFillDt(reqParamArray[FILLDT_POSITION].trim());
		row.setCustFamNbr(reqParamArray[CUSTFAMNBR_POSITION].trim());
		row.setCustMbrNbr(reqParamArray[CUSTMBRNBR_POSITION].trim());
		row.setRxcDrID(reqParamArray[RXCDRID_POSITION].trim());
		row.setRxcPatientID(reqParamArray[ RXCPATIENTID_POSITION].trim());
		row.setRxcPrecID(reqParamArray[RXCPRECID_POSITION].trim());
		row.setConTrackType(reqParamArray[CONTRACKTYPE_POSITION].trim());
		row.setDispNdc(reqParamArray[DISPNDC_POSITION].trim());
		row.setDrugGcnNbr(reqParamArray[ DRUGGCNNBR_POSITION].trim());
		row.setDrugGpiF(reqParamArray[DRUGGPIF_POSITION].trim());
		row.setDrugGpiE(reqParamArray[DRUGGPIE_POSITION].trim());
		row.setRxchannelType(reqParamArray[RXCHANNELTYPE_POSITION].trim());
		row.setRxActionCD(reqParamArray[RXACTIONCD_POSITION].trim());
		row.setSrcCD(reqParamArray[SRCCD_POSITION].trim());
		row.setPhoneNbr(reqParamArray[PHONENBR_POSITION].trim());
		row.setPgmType(reqParamArray[PGMTYPE_POSITION].trim());
		row.setOpptChannelTxt(reqParamArray[OPPTCHANNELTXT_POSITION].trim());
		row.setVisittCD(reqParamArray[VISITTCD_POSITION].trim());
		row.setDaySupplyQty(reqParamArray[DAYSUPPLYQTY_POSITION].trim());
		row.setRxExpDt(reqParamArray[RXEXPDT_POSITION].trim());
		row.setActOpptInd(reqParamArray[ACTOPPTIND_POSITION].trim());
		row.setRegTgtDt(reqParamArray[REGTGTDT_POSITION].trim());
		row.setTrainRsnCd(reqParamArray[TRAINRSNCD_POSITION].trim());
		row.setDeliveryStartTime(reqParamArray[DELIVERYSTARTTIME_POSITION].trim());
		row.setDeliveryPriorityNbr(reqParamArray[DELIVERYPRIORITYNBR_POSITION].trim());
		row.setVerbiageCD(reqParamArray[VERBIAGECD_POSITION].trim());
		row.setDeliveryMethod(reqParamArray[DELIVERYMETHOD_POSITION].trim());
		row.setMultiScriptOpptInd(reqParamArray[MULTISCRIPTOPPTIND_POSITION].trim());
		row.setPrescriberCrgSwapInd(reqParamArray[PRECSCRIBERCRGSWAPIND_POSITION].trim());
		row.setReadyFillEnrCD(reqParamArray[READYFILLENRCD_POSITION].trim());
		row.setWildChar(reqParamArray[WILDCHAR_POSITION].trim());
		row.setSrcOpptCrtDt(reqParamArray[SRCOPPTCRTDT_POSITION].trim());
		row.setScriptsOppt(reqParamArray[SCRIPTSOPPT_POSITION].trim());
		row.setRxMsgSrcCD(reqParamArray[RXMSGSRCCD_POSITION].trim());
		row.setRxMsgCD(reqParamArray[RXMSGCD_POSITION].trim());
		row.setRxMsgType(reqParamArray[RXMSGTYPE_POSITION].trim());
		row.setOpptMsgSrcCD(reqParamArray[OPPTSRCMSGCD_POSITION].trim());
		row.setOpptMsgCD(reqParamArray[OPPTMSGCD_POSITION].trim());
		row.setOpptMsgType(reqParamArray[OPPTMSGTYPE_POSITION].trim());
		row.setRxNbr(reqParamArray[RXNBR_POSITION].trim());
		row.setStoreNbr(reqParamArray[STORENBR_POSITION].trim());
		row.setSubPgmCD(reqParamArray[SUBPGMCD_POSITION].trim());
		row.setPgmCD(reqParamArray[PGMCD_POSITION].trim());
		row.setCondefSeqNbr(reqParamArray[CONDEFSEQNBR_POSITION].trim());
		row.setCreateTs(reqParamArray[CREATETS_POSITION].trim());
		data.setEventName(reqParamArray[EVENTNAME_POSITION].trim());
		data.setActivityTemplateID(reqParamArray[ACTIVITYTEMPLATEID_POSITION].trim());
		row.setRequestID(reqParamArray[REQUESTID_POSITION].trim());
		data.setActionType(reqParamArray[ACTIONTYPE_POSITION].trim());
		
        
		if (row != null) {
			rows.add(row);
		} 
		if (rows != null && rows.size() > 0) {
			data.setRows(rows);
		}
	

		requestPayloadData.setData(data);
		jsonRequest.setRequestMetaData(requestMetaData);
		jsonRequest.setRequestPayloadData(requestPayloadData);

		reqString = objectMapper.writeValueAsString(jsonRequest);

	
		return reqString;
	}

}
