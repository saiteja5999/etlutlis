package com.cvshealth.dep.etlutils.medcost;

import java.io.Serializable;
import java.util.List;

import com.cvshealth.dep.etlutils.securechat.MessageList;






public class TrainRequest implements Serializable {

	private static final long serialVersionUID = -4187537354799171017L;

	

	private RequestMetaData requestMetaData = null;
	private RequestPayloadData requestPayloadData = null;

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TrainJSONRequest [requestMetaData=" + requestMetaData
				+ ", requestPayloadData=" + requestPayloadData + "]";
	}

	/**
	 * @return the requestMetaData
	 */
	public RequestMetaData getRequestMetaData() {
		return requestMetaData;
	}

	/**
	 * @param requestMetaData
	 *            the requestMetaData to set
	 */
	public void setRequestMetaData(RequestMetaData requestMetaData) {
		this.requestMetaData = requestMetaData;
	}

	/**
	 * @return the requestPayloadData
	 */
	public RequestPayloadData getRequestPayloadData() {
		return requestPayloadData;
	}

	/**
	 * @param requestPayloadData
	 *            the requestPayloadData to set
	 */
	public void setRequestPayloadData(RequestPayloadData requestPayloadData) {
		this.requestPayloadData = requestPayloadData;
	}

	/**
	 * RequestMetaData
	 * 
	 * @author CVSHealth
	 */
	public static class RequestMetaData {
		private String appName = "";
		private String lineOfBusiness = "ECCM";
		private String conversationID = "";
	

		

		/**
		 * @return the appName
		 */
		public String getAppName() {
			return appName;
		}

		/**
		 * @param appName
		 *            the appName to set
		 */
		public void setAppName(String appName) {
			this.appName = appName;
		}

		/**
		 * @return the lineOfBusiness
		 */
		public String getLineOfBusiness() {
			return lineOfBusiness;
		}

		/**
		 * @param lineOfBusiness
		 *            the lineOfBusiness to set
		 */
		public void setLineOfBusiness(String lineOfBusiness) {
			this.lineOfBusiness = lineOfBusiness;
		}

		/**
		 * @return the conversationID
		 */
		public String getConversationID() {
			return conversationID;
		}

		/**
		 * @param conversationID
		 *            the conversationID to set
		 */
		public void setConversationID(String conversationID) {
			this.conversationID = conversationID;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Object#toString()
		 */
		@Override
		public String toString() {
			return "RequestMetaData [appName=" + appName + ", lineOfBusiness="
					+ lineOfBusiness + ", conversationID=" + conversationID
					+ "]";
		}
	}

	public static class RequestPayloadData {
		
		

		private Data data = null;
		private List<Rows> rows = null;
		
		
		public Data getData() {
			return data;
		}
		
		public void setData(Data data) {
			this.data = data;
		}
		

		public List<Rows> getRows() {
			return rows;
		}

		public void setRows(List<Rows> rows) {
			this.rows = rows;
		}

		

@Override
		public String toString() {
			return "RequestPayloadData [data=" + data + ", rows=" + rows + "]";
		}
	}



		
				
	
		

		
	}


