package com.cvshealth.dep.etlutils.core;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.cvshealth.dep.etlutils.common.Processor;
import com.cvshealth.dep.etlutils.utils.Service;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * CoreRequest processes the file entries and marshalls each entry in a
 * valid JSON request
 * 
 * @author CVS Health
 */
public class CoreProcessor implements Processor{
	private static final String JSON_INT = "integer";
	private static final String JSON_STRING = "string";
	private static final String JSON_OBJECT = "object";
	private static final String JSON_DOUBLE = "double";
	private static final String JSON_NEW_UUID = "new_uuid";
	private static final String JSON_CONSTANT = "constant";
	
	private final Logger infoLogger = Logger.getLogger("coreinfo");
	private final Logger errorLogger = Logger.getLogger("coreerror");
	private Config config = null;

	protected CoreProcessor(Config conf) {
		this.config = conf;
	}

	@Override
	public void processRecords(List<String> records) throws Exception{
		String delimiter = config.getDelimiter();
		List<ConfigNode> configNodeList = config.getConfigNodeList();
		final String[] kafkaServers = config.getKafkaServers().split("\\|");
		final String kafkaURI = config.getKafkaUri();
		String kafkaAuthkey = config.getKafkaAuthkey();
		String appName = config.getAppName();
		int recordsPerBatch = config.getRecordsPerBatch();

		int recCount = 0;
		
		int availCores = Utility.getAvailableCores();

		infoLogger.info("CoreProcessor | processRecords() | Avail CPU Cores:" + availCores
						+ ", spawing threads as available cores for parallel execution");

		ExecutorService execService = Executors.newFixedThreadPool(availCores);
		
		try{
			// iterate for each record and process
			for (final String record : records) {
				// Spawn thread and process it async
				recCount = recCount + 1;
				if (recCount > recordsPerBatch) {
					recCount = 0;
					Thread.sleep(1000);
				}
				execService.execute(new Runnable() {
					@Override
					public void run() {
						String[] elements = record.split(delimiter, -1);
						try{
							JSONObject jSONObject = buildJSONObject(configNodeList, elements);
							String reqString = jSONObject.toString();
							System.out.println("Request="+reqString);
	
							// Invoke the Service to push the message into Kafka
	
							infoLogger.info("PayLoadRequest to Kafka:" + reqString);
							String URL = "http://" + kafkaServers[ThreadLocalRandom.current().nextInt(0, kafkaServers.length)]
									+ ":4104" + kafkaURI;
							//System.out.println("URL=" + URL);
							// Build the header
							Map<String, String> headers = new HashMap<String, String>();
							headers.put("AuthKey", kafkaAuthkey);
				
							String response = Service.post(URL, appName, reqString, headers);
							System.out.println("Response=" + response);
						}catch (Exception e){
							errorLogger.error("CoreProcessor | execService.execute() | Error while converting record into KafkaRequest"
									+ Utility.getError(e));
							e.printStackTrace();
						}
					}
				});
			}
		}catch (Exception e) {
			infoLogger
			.info("CoreProcessor | processRecords() | Error in processing records | "
					+ e.getMessage());
			errorLogger.error(Utility.getStrackTrace(e));
		} finally {
			if (null != execService) {
				execService.shutdown();
				try {
					execService.awaitTermination(30, TimeUnit.MINUTES);
				} catch (Exception e) {
					errorLogger.error(Utility.getError(e));
				}
			}
		}
	}
	
	public static JSONObject buildJSONObject(List<ConfigNode> configNodeList, String[] elements) throws Exception{
		JSONObject jsonObj = new JSONObject();
		
		for (int i = 0; i < configNodeList.size(); i++){
			ConfigNode configNode = configNodeList.get(i);
			int colNumber = configNode.getColNumber();
			String colName = configNode.getColName();
			String type = configNode.getType();

			if (JSON_INT.equalsIgnoreCase(type)){
				String element = elements[colNumber].trim();
				int intValue = 0;
				if (null != element && element.length() > 0){
					intValue = Integer.parseInt(element);
				}
				jsonObj.put(colName, intValue);
			}else if (JSON_DOUBLE.equalsIgnoreCase(type)){
				String element = elements[colNumber].trim();
				double doubleValue = 0.0;
				if (null != element && element.length() > 0){
					doubleValue = Double.parseDouble(element);
				}
				jsonObj.put(colName, doubleValue);
			}else if (JSON_NEW_UUID.equalsIgnoreCase(type)){
				UUID uuid = UUID.randomUUID();
				jsonObj.put(colName, uuid);
			}else if (JSON_CONSTANT.equalsIgnoreCase(type)){
				String deftValue = configNode.getDefaultValue();
				jsonObj.put(colName, deftValue);
			}else if (JSON_OBJECT.equalsIgnoreCase(type)){
				String element = elements[colNumber];
				JsonNode jsonNode = configNode.getConfigNodeList();
				ObjectMapper mapper = new ObjectMapper();
				List<ConfigNode> configNodeList2 = mapper.readValue(jsonNode.toString(), new TypeReference<List<ConfigNode>>(){});
				JSONObject jSonObject2 = buildJSONObject(configNodeList2, elements);
				jsonObj.put(colName, jSonObject2);
			}else {
				String element = elements[colNumber];
				//System.out.println("element=" + element);
				jsonObj.put(colName, element);
			}
		}
		
		return jsonObj;
	}
}
