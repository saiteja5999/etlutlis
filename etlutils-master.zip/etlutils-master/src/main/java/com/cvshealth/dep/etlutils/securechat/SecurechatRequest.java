package com.cvshealth.dep.etlutils.securechat;

import java.io.Serializable;
import java.util.List;

import com.cvshealth.dep.etlutils.utils.Utility;

public class SecurechatRequest implements Serializable {
	private static final long serialVersionUID = -4187537354799171017L;
	private List<Patients> patients = null;

	public String toString() {
		return "SecurechatRequest ["
				// + "appMsgId=" + appMsgId
				+ ",sourceSystem=" + sourceSystem + ",psrUserId=" + psrUserId
				+ ",patients=" + patients + "]";
	}

	private String appMsgId = "15282220889497";
	private String sourceSystem = SecurechatConsumer.SourceSystem;
	private String psrUserId = "";

	public String getSourceSystem() {
		return sourceSystem;
	}

	public void setSourceSystem(String sourceSystem) {
		this.sourceSystem = sourceSystem;
	}

	public String getAppMsgId() {
		return appMsgId;
	}

	public void setAppMsgId(String appMsgId) {
		this.appMsgId = appMsgId;
	}

	public String getPsrUserId() {
		return psrUserId;
	}

	public void setPsrUserId(String psrUserId) {
		this.psrUserId = psrUserId;
	}

	public List<Patients> getPatients() {
		return patients;
	}

	public void setPatients(List<Patients> patients) {
		this.patients = patients;
	}

}