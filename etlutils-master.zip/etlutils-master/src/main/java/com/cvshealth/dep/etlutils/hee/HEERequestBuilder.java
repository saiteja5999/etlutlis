package com.cvshealth.dep.etlutils.hee;

import java.util.ArrayList;
import java.util.List;


import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;






import org.json.*;
import org.apache.commons.logging.Log;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.FieldNamingPolicy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

public class HEERequestBuilder implements RequestBuilder {
	

	
	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		

		 final int HEEREQUESTDATA_POSITION = Integer.parseInt(Utility.getProperty(
				folder, finalProduct, "HEEREQUESTDATA_POSITION").trim());

		String reqString = null;
		String recordType = null;

		ObjectMapper objectMapper = null;
		HeeRequestData jsonRequest = new HeeRequestData();

		

		
		/*
		 * if (null != recordType && recordType.equalsIgnoreCase("T")) {
		 * reqString = "EOF"; } else {
		 */
		objectMapper = new ObjectMapper();
		objectMapper.setSerializationInclusion(Include.NON_NULL);
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		
		
	

		// Populate Data
		jsonRequest.setHeeRequestData(reqParamArray[HEEREQUESTDATA_POSITION].trim());
		
		
		
		
		reqString= objectMapper.writeValueAsString(jsonRequest);
		
		String jsonFormattedString = reqString.replaceAll("\\\\", "").replace("\"{", "{").replace("}\"", "}");
	
reqString	=	jsonFormattedString;
	
		return reqString;
	}

}
