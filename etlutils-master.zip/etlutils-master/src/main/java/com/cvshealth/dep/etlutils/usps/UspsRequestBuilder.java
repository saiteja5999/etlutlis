package com.cvshealth.dep.etlutils.usps;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;

import com.cvshealth.dep.etlutils.common.RequestBuilder;
import com.cvshealth.dep.etlutils.usps.UspsRequest.AdditionalData;
import com.cvshealth.dep.etlutils.usps.UspsRequest.Data;
import com.cvshealth.dep.etlutils.usps.UspsRequest.RequestMetaData;
import com.cvshealth.dep.etlutils.usps.UspsRequest.RequestPayloadData;
import com.cvshealth.dep.etlutils.utils.Utility;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Notification JSON Builder - Build the JSON request payload for the
 * XID/Notification service
 * 
 * @author CVSHealth
 */
public class UspsRequestBuilder implements RequestBuilder {
	private static String env;

	private ZipcodeUtil _ZipcodeUtil;

	public UspsRequestBuilder(ZipcodeUtil utils) {
		this._ZipcodeUtil = utils;
	}

	String eventMap;

	@Override
	public String getRequest(String[] reqParamArray, String finalProduct,
			String folder) throws Exception {
		final int VERSION_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "VERSION_POSITION");
		final int TRACK_NUMBER_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "TRACK_NUMBER_POSITION");
		final int FILE_NUMBER_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "FILE_NUMBER_POSITION");
		final int MAILER_ID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "MAILER_ID_POSITION");
		final int MAILER_NAME_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "MAILER_NAME_POSITION");

		final int DEST_ZIP_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "DEST_ZIP_POSITION");
		final int DEST_ZIP4_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "DEST_ZIP4_POSITION");
		final int SCAN_FACILITY_ZIP_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "SCAN_FACILITY_ZIP_POSITION");
		final int SCAN_FACILITY_NAME_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "SCAN_FACILITY_NAME_POSITION");
		final int EVENT_CODE_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "EVENT_CODE_POSITION");

		final int EVENT_NAME_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "EVENT_NAME_POSITION");
		final int EVENT_DATE_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "EVENT_DATE_POSITION");
		final int EVENT_TIME_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "EVENT_TIME_POSITION");
		final int OWNER_MAILER_ID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "OWNER_MAILER_ID_POSITION");
		final int CUST_REF_NUMBER_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "CUST_REF_NUMBER_POSITION");

		final int DEST_COUNTRY_CODE_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "DEST_COUNTRY_CODE_POSITION");
		final int RECIPIENT_NAME_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "RECIPIENT_NAME_POSITION");
		final int ORIGINAL_LABEL_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "ORIGINAL_LABEL_POSITION");
		final int UNIT_MEASURE_CODE_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "UNIT_MEASURE_CODE_POSITION");
		final int WEIGHT_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "WEIGHT_POSITION");

		final int GUAR_DELIVERY_DATE_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "GUAR_DELIVERY_DATE_POSITION");
		final int GUAR_DELIVERY_TIME_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "GUAR_DELIVERY_TIME_POSITION");
		final int MANAGER_MAILER_ID_POSITION = Utility.getPropertyInt(folder,
				finalProduct, "MANAGER_MAILER_ID_POSITION");
		final int SCHEDULED_DELIVERY_DATE_POSITION = Utility.getPropertyInt(
				folder, finalProduct, "SCHEDULED_DELIVERY_DATE_POSITION");

		final String APP_NAME = Utility.getProperty(folder, finalProduct,
				"APP_NAME");
		final String LINE_OF_BUSINESS = Utility.getProperty(folder,
				finalProduct, "LINE_OF_BUSINESS");

		// Populate AdditionalData model
		AdditionalData additionalData = new AdditionalData();
		additionalData.setVersion(reqParamArray[VERSION_POSITION].trim());
		additionalData.setTrackNumber(reqParamArray[TRACK_NUMBER_POSITION]
				.trim());
		additionalData
				.setFileNumber(reqParamArray[FILE_NUMBER_POSITION].trim());
		additionalData.setMailerID(reqParamArray[MAILER_ID_POSITION].trim());
		additionalData
				.setMailerName(reqParamArray[MAILER_NAME_POSITION].trim());

		additionalData.setDestinationZip(reqParamArray[DEST_ZIP_POSITION]
				.trim());
		additionalData.setDestinationZip4(reqParamArray[DEST_ZIP4_POSITION]
				.trim());
		additionalData
				.setScanFacilityZip(reqParamArray[SCAN_FACILITY_ZIP_POSITION]
						.trim());
		additionalData
				.setScanFacilityName(reqParamArray[SCAN_FACILITY_NAME_POSITION]
						.trim());
		String eventCode = reqParamArray[EVENT_CODE_POSITION].trim();
		additionalData.setEventCode(eventCode);

		additionalData.setEventName(reqParamArray[EVENT_NAME_POSITION].trim());
		additionalData.setEventDate(reqParamArray[EVENT_DATE_POSITION].trim());
		additionalData.setEventTime(reqParamArray[EVENT_TIME_POSITION].trim());
		additionalData.setOwnerMailerID(reqParamArray[OWNER_MAILER_ID_POSITION]
				.trim());
		additionalData
				.setCustReferenceNumber(reqParamArray[CUST_REF_NUMBER_POSITION]
						.trim());

		additionalData
				.setDestCountryCode(reqParamArray[DEST_COUNTRY_CODE_POSITION]
						.trim());
		additionalData.setRecipientName(reqParamArray[RECIPIENT_NAME_POSITION]
				.trim());
		additionalData.setOriginalLabel(reqParamArray[ORIGINAL_LABEL_POSITION]
				.trim());
		additionalData
				.setUnitMeasureCode(reqParamArray[UNIT_MEASURE_CODE_POSITION]
						.trim());
		additionalData.setWeight(reqParamArray[WEIGHT_POSITION].trim());

		additionalData
				.setGuarDeliveryDate(reqParamArray[GUAR_DELIVERY_DATE_POSITION]
						.trim());
		additionalData
				.setGuarDeliveryTime(reqParamArray[GUAR_DELIVERY_TIME_POSITION]
						.trim());
		additionalData
				.setManagerMailerID(reqParamArray[MANAGER_MAILER_ID_POSITION]
						.trim());
		additionalData
				.setScheduledDeliveryDate(reqParamArray[SCHEDULED_DELIVERY_DATE_POSITION]
						.trim());

		String offset = this._ZipcodeUtil.getOffsetbyZip(additionalData
				.getScanFacilityZip());
		additionalData.setActivityTimeStamp(additionalData.getEventDate(),
				additionalData.getEventTime(), offset);

		// Populate Data model
		Data data = new Data();
		data.setEventName(getRxEventName(eventCode));

		// Populate RequestPayloadData
		RequestPayloadData requestPayloadData = new RequestPayloadData();
		requestPayloadData.setData(data);

		requestPayloadData.setAdditionalData(additionalData);

		// Populate RequestMetaData
		RequestMetaData requestMetaData = new RequestMetaData();
		requestMetaData.setAppName(APP_NAME);
		requestMetaData.setLineOfBusiness(LINE_OF_BUSINESS);
		requestMetaData.setConversationID(UUID.randomUUID().toString());

		// Populate UspsRequest
		UspsRequest uspsRequest = new UspsRequest();
		uspsRequest.setRequestMetaData(requestMetaData);
		uspsRequest.setRequestPayloadData(requestPayloadData);

		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		return objectMapper.writeValueAsString(uspsRequest);
	}

	public String getRxEventName(String eventCode) throws IOException {

		eventMap = this._ZipcodeUtil.loadCode().put(eventCode, eventMap)
				.toString();

		eventCode = eventMap;

		return eventCode;
		/*
		 * switch (eventCode) {
		 * 
		 * case "03": case "OA": return "RxExpress_NDDDriverPickedUp"; case
		 * "01": case "43": case "60": case "63": return
		 * "RxExpress_NDDDriverDelivered"; case "04": case "05": case "09": case
		 * "21": case "22": case "23": case "24": case "25": case "26": case
		 * "27": case "28": case "29": case "31": return
		 * "RxExpress_NDDDriverReturnedToSender"; case "02": case "30": case
		 * "32": case "33": case "52": case "53": case "54": case "55": case
		 * "56": return "RxExpress_NDDDriverDeliveryAttempt";
		 * 
		 * default: return "Not Mapped";}
		 */

	}

}
