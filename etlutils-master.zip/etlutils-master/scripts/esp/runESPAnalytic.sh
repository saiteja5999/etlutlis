#!/bin/bash
nohup /opt/digital/java/jdk8/bin/java -cp "/opt/digital/javaapps/etlutils.jar" com.cvshealth.dep.etlutils.extracare.analytic.esp.AnalyticMain $1 $2 >> log.file 2>&1 &
echo $! > /dev/null
