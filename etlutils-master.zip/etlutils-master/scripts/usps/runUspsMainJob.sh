#!/bin/bash
nohup /opt/digital/java/jdk8/bin/java -cp "/opt/digital/javaapps/etlutils.jar" com.cvshealth.dep.etlutils.usps.UspsMain $1 $2 >> usps_log.file 2>&1 &
echo $! > /dev/null
